from dataclasses import dataclass
from functools import lru_cache
from langchain.text_splitter import (
    CharacterTextSplitter,
    SpacyTextSplitter,
    NLTKTextSplitter,
    RecursiveCharacterTextSplitter,
)
from langchain_experimental.text_splitter import SemanticChunker
from langchain.schema import Document
from typing import List, Literal, Any
import concurrent.futures
import math
import multiprocessing
from tqdm import tqdm

import subprocess
import sys

# Data: Type definitions and allowed values
MatricsTypes = Literal[
    "charactor_split", "semantic_split", "spacy_split", "nltk_split", "recursive_split"
]
ALLOWED_MATRICS: list[str] = [
    "charactor_split",
    "semantic_split",
    "spacy_split",
    "nltk_split",
    "recursive_split",
]


@lru_cache(maxsize=5)
def get_spacy_splitter(chunk_size: int, chunk_overlap: int):
    import spacy

    return SpacyTextSplitter(
        separator="\n",
        pipeline="en_core_web_lg",
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )


@dataclass(slots=True)
class DocumentChunker:
    """
    A class to split documents into smaller chunks using different strategies.

    Attributes:
        chunk_size (int): Maximum size of each chunk.
        chunk_overlap (int): Number of characters to overlap between chunks.
        batch_percentage (float): Placeholder for batch sizing in percentage (not used directly).
        breakpoint_threshold_type (str): Default method for semantic split threshold calculation.
    """

    chunk_size: int = 1000
    chunk_overlap: int = 200
    batch_percentage: float = 0.12
    breakpoint_threshold_type: str = "percentile"

    def text_splitter(
        self,
        docs: List[Document],
        matrics: MatricsTypes,
        embedding: Any = None,
        breakpoint_threshold_type: str = None,
    ) -> List[Document]:
        """
        Routes the document splitting to the appropriate method based on the selected strategy.

        Args:
            docs (List[Document]): List of documents to split.
            matrics (MatricsTypes): The strategy to use for chunking. Options: "charactor_split",
                "spacy_split", "nltk_split", "recursive_split", "semantic_split".
            embedding (Any, optional): Embedding model for semantic split.
            breakpoint_threshold_type (str, optional): Threshold strategy for semantic split.

        Returns:
            List[Document]: A list of chunked Document instances.

        Raises:
            ValueError: If an unsupported strategy is provided or if semantic split is chosen without embedding.
        """
        match matrics:
            case "charactor_split":
                return self.charactor_split(docs)

            case "spacy_split":
                return self.spacy_split(docs)

            case "nltk_split":
                return self.nltk_split(docs)

            case "recursive_split":
                return self.recursive_split(docs)

            case "semantic_split":
                return self.semantic_split(docs, embedding, breakpoint_threshold_type)

            case _:
                raise ValueError(f"Unsupported matrics type: {matrics}")

    def charactor_split(self, docs: List[Document]) -> List[Document]:
        """
        Splits documents using character count based strategy.

        Args:
            docs (List[Document]): List of documents.

        Returns:
            List[Document]: Chunked documents.
        """
        char_splitter = CharacterTextSplitter(
            separator="\n",
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            length_function=len,
        )
        return char_splitter.split_documents(docs)

    def spacy_split(self, docs: List[Document]) -> List[Document]:
        """
        Uses spaCy-based NLP sentence segmentation for splitting.

        Args:
            docs (List[Document]): List of documents.

        Returns:
            List[Document]: Chunked documents with sentence boundaries.
        """
        spacy_splitter = get_spacy_splitter(self.chunk_size, self.chunk_overlap)
        return [
            Document(page_content=chunk, metadata=doc.metadata)
            for doc in docs
            for chunk in spacy_splitter.split_text(doc.page_content)
        ]

    def nltk_split(self, docs: List[Document]) -> List[Document]:
        """
        Uses NLTK sentence tokenizer to split documents into chunks.

        Args:
            docs (List[Document]): List of documents.

        Returns:
            List[Document]: Chunked documents.
        """
        nltk_splitter = NLTKTextSplitter(
            separator="\n",
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
        )
        return [
            Document(page_content=chunk, metadata=doc.metadata)
            for doc in docs
            for chunk in nltk_splitter.split_text(doc.page_content)
        ]

    def recursive_split(self, docs: List[Document]) -> List[Document]:
        """
        Applies a recursive strategy to find appropriate split points based on multiple separators.

        Args:
            docs (List[Document]): List of documents.

        Returns:
            List[Document]: Chunked documents.
        """
        recursive_splitter = RecursiveCharacterTextSplitter(
            separators=["\n"],
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
        )
        return [
            Document(page_content=chunk, metadata=doc.metadata)
            for doc in docs
            for chunk in recursive_splitter.split_text(doc.page_content)
        ]

    def semantic_split(
        self,
        docs: List[Document],
        embedding: Any,
        breakpoint_threshold_type: str = "percentile",
    ) -> List[Document]:
        """
        Splits documents semantically using embedding similarity and breakpoint detection.

        Args:
            docs (List[Document]): List of documents to split.
            embedding (Any): Embedding model instance used for semantic similarity.
            breakpoint_threshold_type (str): Strategy to detect chunk breakpoints.

        Returns:
            List[Document]: Semantically split documents.

        Raises:
            ValueError: If embedding model is not provided.
        """
        if embedding is None:
            raise ValueError(
                "Embedding model not found please pass embedding model instance."
            )

        semantic_splitter = SemanticChunker(
            embedding,
            breakpoint_threshold_type=breakpoint_threshold_type
            or self.breakpoint_threshold_type
            or "standard_deviation",
        )

        return semantic_splitter.split_documents(docs)

    def _process_chunk(
        self,
        batch,
        matrics,
        embedding,
        breakpoint_threshold_type,
    ):
        """
        Internal helper to route batch processing through the appropriate splitter.

        Args:
            batch (List[Document]): A batch of documents to process.
            matrics (MatricsTypes): Chunking strategy to use.
            embedding (Any): Embedding model for semantic splits.
            breakpoint_threshold_type (str): Threshold type for semantic splits.

        Returns:
            List[Document]: Chunked documents.
        """
        return self.text_splitter(
            batch,
            matrics,
            embedding,
            breakpoint_threshold_type,
        )

    def chunk_docs(
        self,
        docs,
        matrics: MatricsTypes = "charactor_split",
        embedding: Any = None,
        breakpoint_threshold_type: str = "percentile",
    ) -> List[Document]:
        """
        Splits the input documents into chunks using the specified strategy,
        potentially using parallel processing for efficiency.

        Args:
            docs (List[Document]): List of input documents to chunk.
            matrics (MatricsTypes): Chunking method to apply.
            embedding (Any, optional): Embedding model required for semantic split.
            breakpoint_threshold_type (str): Threshold type for semantic splits.

        Returns:
            List[Document]: List of chunked documents.

        Raises:
            ValueError: If documents are empty or matrics type is invalid.
        """
        if not docs:
            raise ValueError("documents are empty.")
        if matrics not in ALLOWED_MATRICS:
            raise ValueError(f"Invalid matrics type: {matrics}")
        if matrics == "spacy_split":
            self.load_spacy_model()

        # Determine how many batches based on configured batch percentage
        num_batches = int(1 / self.batch_percentage)
        batch_size = math.ceil(len(docs) / num_batches)

        print(f"Batch size: {batch_size}, Total batches: {num_batches}")

        # Create document batches
        batches = [docs[i : i + batch_size] for i in range(0, len(docs), batch_size)]
        all_chunks = []

        # Limit parallel workers to CPU count or 12 max
        max_workers = min(12, multiprocessing.cpu_count())

        # Parallel chunk processing
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(
                    self._process_chunk,
                    batch,
                    matrics,
                    embedding,
                    breakpoint_threshold_type,
                )
                for batch in batches
            ]

            # Collect chunks as each batch finishes
            for future in tqdm(
                concurrent.futures.as_completed(futures),
                total=len(futures),
                desc="Chunking",
            ):
                chunks = future.result()
                all_chunks.extend(chunks)

        return all_chunks

    def load_spacy_model(self, model_name: str = "en_core_web_lg"):
        """
        Ensures the spaCy model is downloaded and loaded for use in splitting.

        Args:
            model_name (str): Name of the spaCy model to load. Defaults to "en_core_web_lg".

        Returns:
            None

        Raises:
            subprocess.CalledProcessError: If the download subprocess fails.
        """
        try:
            import spacy

            spacy.load(model_name)
        except OSError:
            # Automatically download the model if not already available
            subprocess.check_call(
                [sys.executable, "-m", "spacy", "download", model_name]
            )
