from abc import ABC


class Preprocessor(ABC): ...
