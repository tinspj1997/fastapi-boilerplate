# src/utils/document_cleaner.py
from typing import List, Optional, Any
from langchain.schema import Document


def _filter_metadata(metadata: dict, include: List[str], exclude: List[str]) -> dict:
    """
    Filters a metadata dictionary by either including or excluding specific keys.

    Args:
        metadata (dict[str, Any]): The original metadata dictionary to filter.
        include (list[str]): List of keys to retain in the metadata. If provided, only these keys are kept.
        exclude (list[str]): List of keys to remove from the metadata. Ignored if `include` is provided.

    Returns:
        dict[str, Any]: A new metadata dictionary with keys filtered based on `include` or `exclude`.

    Example:
        >>> _filter_metadata({"a": 1, "b": 2}, include=["a"], exclude=[])
        {'a': 1}

        >>> _filter_metadata({"a": 1, "b": 2}, include=[], exclude=["b"])
        {'a': 1}
    """
    # Convert metadata to a set of keys for efficient operations
    keys = set(metadata.keys())

    # If 'include' is provided, only retain keys that are in the include list
    if include:
        keys = keys.intersection(set(include))
    # If 'include' is not provided but 'exclude' is, remove those keys
    elif exclude:
        keys = keys.difference(set(exclude))

    # Return metadata containing only the desired keys
    return {k: metadata[k] for k in keys}


def clean_and_format_documents(
    docs: List[Document],
    prefix: str = "",
    suffix: str = "",
    include_metadata: Optional[List[str]] = None,
    exclude_metadata: Optional[List[str]] = None,
    min_char: Optional[int] = 0,
    **custom_metadata: Any,
) -> List[Document]:
    """
    Clean and format a list of Document objects by:
      - Stripping and filtering content
      - Adding prefix/suffix to content
      - Filtering metadata by include/exclude lists
      - Adding/updating metadata with custom parameters
      - Skipping docs with content shorter than min_char
    """
    # Validate input types
    if not isinstance(docs, list) or not all(isinstance(d, Document) for d in docs):
        raise TypeError("docs must be a list of Document objects.")
    if not isinstance(prefix, str) or not isinstance(suffix, str):
        raise TypeError("prefix and suffix must be strings.")
    if include_metadata and exclude_metadata:
        raise ValueError(
            "include_metadata and exclude_metadata cannot be used together."
        )

    # Normalize None to empty list for processing
    include_metadata = include_metadata or []
    exclude_metadata = exclude_metadata or []

    cleaned_documents = []

    for doc in docs:
        # Extract content and metadata from each document
        content = getattr(doc, "page_content", "")
        metadata = getattr(doc, "metadata", {})

        # Skip documents with empty or too-short content
        if not isinstance(content, str) or len(content.strip()) < (min_char or 0):
            continue
        # Skip documents with invalid metadata
        if not isinstance(metadata, dict):
            continue

        # Apply metadata filtering
        filtered_metadata = _filter_metadata(
            metadata, include_metadata, exclude_metadata
        )

        # Add 1 to page number if "page" key exists, and merge custom metadata
        updated_metadata = {
            **filtered_metadata,
            **(
                {"page": filtered_metadata["page"] + 1}
                if "page" in filtered_metadata
                else {}
            ),
            **custom_metadata,
        }

        # Ensure that updated metadata is not empty
        if not updated_metadata:
            raise ValueError(
                "Updated metadata is empty. Document metadata must contain at least one entry."
            )

        # Create new cleaned Document with formatted content and updated metadata
        cleaned_documents.append(
            Document(
                page_content=f"{prefix}{content.strip()}{suffix}",
                metadata=updated_metadata,
            )
        )

    return cleaned_documents
