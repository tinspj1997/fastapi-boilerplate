from functools import singledispatch
import pandas as pd


@singledispatch
def table_to_markdown(table):
    raise NotImplementedError(f"Unsupported type: {type(table)}")


@table_to_markdown.register
def _(table: pd.DataFrame):
    table_md = table.to_markdown(index=False)
    return f"\n\nTable 1:\n{table_md}\n"


@table_to_markdown.register
def _(table: list):
    markdown_tables = []
    for i, df in enumerate(table):
        if isinstance(df, pd.DataFrame):
            table_md = df.to_markdown(index=False)
            markdown_tables.append(f"Table {i + 1}:\n{table_md}\n")
        else:
            raise ValueError(f"Item {i} in list is not a DataFrame.")
    return "\n\n".join(markdown_tables)
