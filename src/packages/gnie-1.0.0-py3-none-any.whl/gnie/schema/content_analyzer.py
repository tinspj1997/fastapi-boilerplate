from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional, Type


@dataclass
class ImageByPage:
    page_number: int
    number_of_image: int


@dataclass
class ImageResult:
    has_image: bool = False
    images_by_page: List[ImageByPage] = field(default_factory=list)
    error: Optional[Any] = None

    @property
    def total_images(self) -> int:
        return sum(page.number_of_image for page in self.images_by_page)

    @property
    def pages_with_images(self) -> List[int]:
        return [page.page_number for page in self.images_by_page]


@dataclass
class TableByPage:
    page_number: int
    number_of_tables: int


@dataclass
class TableResult:
    has_table: bool = False
    tables_by_page: List[TableByPage] = field(default_factory=list)
    error: Optional[Any] = None

    @property
    def total_tables(self) -> int:
        return sum(page.number_of_tables for page in self.tables_by_page)

    @property
    def pages_with_tables(self) -> List[int]:
        return [page.page_number for page in self.tables_by_page]


class DocumentHandler(ABC):
    """
    Abstract base for handlers that process different document types.

    Subclasses register themselves for specific file extensions.
    """

    registry: ClassVar[Dict[str, Type["DocumentHandler"]]] = {}

    def __init_subclass__(cls):
        super().__init_subclass__()
        for ext in cls.supported_extensions():
            DocumentHandler.registry[ext] = cls

    @classmethod
    @abstractmethod
    def supported_extensions(cls) -> List[str]:
        """
        Return a list of file extensions (including the dot) that this handler supports.

        Returns:
            List[str]: Supported extensions, e.g. [".pdf"].
        """
        ...

    @abstractmethod
    def find_images(self, file_path: Path, timeout_seconds: float) -> ImageResult:
        """
        Scan the document at file_path for all images within the given timeout.

        Args:
            file_path (Path): Path to the document file.
            timeout_seconds (float): Maximum time allowed for the scan.

        Returns:
            ImageResult: Object containing image details by page.
        """
        ...

    @abstractmethod
    def find_tables(self, file_path: Path, timeout_seconds: float) -> TableResult:
        """
        Scan the document at file_path for all tables within the given timeout.

        Args:
            file_path (Path): Path to the document file.
            timeout_seconds (float): Maximum time allowed for the scan.

        Returns:
            TableResult: Object containing table details by page.
        """
        ...

    @abstractmethod
    def has_image(self, file_path: Path, timeout_seconds: float) -> bool:
        """
        Check if the document at file_path contains at least one image.

        Args:
            file_path (Path): Path to the document file.
            timeout_seconds (float): Maximum time allowed for the check.

        Returns:
            bool: True if an image is found before timeout, False otherwise.
        """
        ...

    @abstractmethod
    def has_table(self, file_path: Path, timeout_seconds: float) -> bool:
        """
        Check if the document at file_path contains at least one table.

        Args:
            file_path (Path): Path to the document file.
            timeout_seconds (float): Maximum time allowed for the check.

        Returns:
            bool: True if a table is found before timeout, False otherwise.
        """
        ...
