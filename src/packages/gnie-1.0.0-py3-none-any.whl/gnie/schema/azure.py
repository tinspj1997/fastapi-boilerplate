from dataclasses import dataclass
from typing import List, Union, IO


@dataclass
class BlobUploadEntity:
    """
    Data class to represent a single file to upload to Azure Blob Storage.

    Attributes:
        file (str or IO[bytes]):
            The file to upload. Can be a path to a file or a readable binary stream.
        blob_name (str):
            The name of the blob in Azure Blob Storage.

    Raises:
        ValueError: If required fields are missing or invalid.
    """

    file: Union[str, IO[bytes]]
    blob_name: str


@dataclass
class UploadSuccess:
    blob_name: str
    url: str


@dataclass
class UploadError:
    blob_name: str
    error: str


@dataclass
class UploadResult:
    success: Union[UploadSuccess, List[UploadSuccess]]
    errors: Union[UploadError, List[UploadError]]
