from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field


class SegmentationConfig(BaseModel):
    """
    Configuration for how the media file is segmented before transcription.

    This class controls the intelligent segmentation of large media files into smaller,
    manageable chunks that can be processed by the Whisper API. The segmentation process
    uses speech detection to avoid cutting through spoken words and includes overlap
    between segments to maintain context continuity.

    Understanding File Size Relationships:
    The segment_duration directly impacts the output file size when combined with bitrate.
    At 12 kbps (default bitrate), approximate file sizes are:
    - 6915 seconds (~115 minutes) = ~10 MB
    - 10373 seconds (~173 minutes) = ~15 MB
    - 13830 seconds (~230 minutes) = ~20 MB

    Parameters:
        segment_duration (int): The target duration for each audio segment in seconds.
            This is the maximum length each segment will attempt to reach before being
            split. The actual segments may be shorter if speech boundaries are detected.
            Longer segments mean fewer API calls but larger file sizes. Shorter segments
            provide more granular processing but increase API overhead.
            Default: 10400 seconds (~173 minutes, resulting in ~15MB files at 12kbps).
            Range: 60 to 15904 seconds (1 minute to ~4.4 hours).

        overlap_duration (int): The number of seconds of audio content that overlaps
            between consecutive segments. This overlap ensures that words or phrases
            that might be split between segments are captured in both, preventing
            loss of context at segment boundaries. Higher overlap provides better
            context continuity but increases processing time and storage requirements.
            Default: 30 seconds.
            Range: 0 to 300 seconds (0 to 5 minutes).

        bitrate (int): The audio bitrate for output segments in kilobits per second (kbps).
            This directly controls the quality-to-file-size tradeoff. Lower bitrates
            produce smaller files that process faster but with reduced audio quality.
            Since this is for speech transcription, very high bitrates are unnecessary.
            The system uses Opus codec optimized for voice transmission.
            Default: 12 kbps (suitable for clear speech transcription).
            Minimum: 12 kbps (lower values may impair transcription accuracy).

        silence_threshold (float): The amplitude threshold below which audio is
            considered silence. This value determines how sensitive the silence
            detection is. Lower values detect quieter sections as silence, while
            higher values only detect complete silence. The value corresponds to
            audio amplitude (0.0 to 1.0), where ~0.001 equals approximately -60dB.
            Default: 0.0009 (roughly -60dB, good for most recordings).
            Range: 0.0 to 1.0.

        silence_duration (float): The minimum duration in seconds that silence must
            persist to be considered a natural break point for segmentation. This
            prevents the system from breaking segments at brief pauses in speech
            like natural breathing or thinking pauses. Longer durations ensure
            segments only break at meaningful pauses but may result in longer segments.
            Default: 10.0 seconds.
            Range: 0.0 seconds and up.

        min_speech_duration (float): The minimum duration in seconds that a detected
            speech segment must contain to be considered worth processing. Very short
            speech segments (like brief interjections or noise) are filtered out to
            avoid wasting API calls on non-meaningful audio. This helps focus
            processing on substantial speech content.
            Default: 10.0 seconds.
            Range: 0.0 seconds and up.

    Usage Guidelines:
        - For long lectures or meetings, use longer segment_duration (8000-15000 seconds)
          to minimize API calls while staying under file size limits.
        - For conversational content with frequent pauses, reduce silence_duration
          (2-5 seconds) to allow more natural break points.
        - For noisy environments, increase silence_threshold (0.002-0.005) to avoid
          treating background noise as speech.
        - For high-quality source material, you can increase bitrate (16-24 kbps)
          without significantly impacting processing time.
        - Always ensure segment_duration * bitrate results in files under 25MB
          (Whisper API limit), with 15-20MB being a safe target.

    Common Pitfalls to Avoid:
        - Setting segment_duration too high may exceed API file size limits
        - Setting silence_threshold too low may prevent proper silence detection
        - Setting min_speech_duration too high may skip important short utterances
        - Zero overlap_duration may cause transcription gaps at segment boundaries
    """

    segment_duration: int = Field(
        default=10400,  # ~173 minutes for a ~15MB file
        description="Duration of each segment in seconds. Default is ~173 minutes for a ~15MB file.",
        ge=60,  # Greater than or equal to 60 seconds
        le=15904,  # Less than or equal to 4 hours 25 minutes ~~ 22-24mb
    )
    overlap_duration: int = Field(
        default=30,
        description="Overlap between segments in seconds to maintain context.",
        ge=0,
        le=300,
    )
    bitrate: int = Field(
        default=12,
        description="Audio bitrate for output segments in kbps. Lower bitrate means smaller files.",
        ge=12,  # Greater than or equal to 12 kbps
    )
    silence_threshold: float = Field(
        default=0.0009,
        description="Silence detection threshold (e.g., -60dB is ~0.001).",
        ge=0.0,
        le=1.0,
    )
    silence_duration: float = Field(
        default=10.0,
        description="Minimum silence duration in seconds to be considered a gap.",
        ge=0.0,
    )
    min_speech_duration: float = Field(
        default=10.0,
        description="Minimum speech duration in seconds to be considered valid.",
        ge=0.0,
    )


class WhisperModel(str, Enum):
    """
    Enumeration of supported Whisper model variants for transcription.

    This enum ensures type safety when specifying which Whisper model to use
    for transcription. Currently supports OpenAI's Whisper-1 model through
    the Azure OpenAI API.

    Values:
        WHISPER_1: The standard Whisper-1 model, optimized for general speech
            recognition across multiple languages with good accuracy and speed.
    """

    WHISPER_1 = "whisper-1"


class TranscriptionConfig(BaseModel):
    """
    Configuration for the Whisper transcription API calls.

    This class controls how each audio segment is sent to the Whisper API for
    transcription. The settings here affect transcription accuracy, output format,
    and API behavior. These parameters are applied to every segment during processing.

    Parameters:
        model_name (WhisperModel): The specific Whisper model variant to use for
            transcription. Currently supports WHISPER_1. Different models may have
            varying accuracy, speed, and language support characteristics.
            Default: WhisperModel.WHISPER_1.

        timestamp_granularities (List[str]): Controls the level of detail for
            timestamp information in the transcription output. Determines whether
            timestamps are provided at the segment level (larger chunks of text)
            or word level (individual words). Word-level timestamps provide more
            precise timing but may increase processing time and output size.
            Default: ["segment"] (timestamps for text segments).
            Options: ["segment"], ["word"], or ["segment", "word"] for both.

        temperature (float): Controls the randomness of the transcription output.
            Lower values (closer to 0.0) make the model more deterministic and
            consistent, which is typically preferred for transcription accuracy.
            Higher values increase creativity but may introduce inconsistencies
            or hallucinations in the transcribed text.
            Default: 0.0 (most deterministic output).
            Range: 0.0 to 1.0.

        timeout (int): The maximum time in seconds to wait for each API call to
            complete before timing out. Longer segments or network issues may
            require longer timeouts. Too short timeouts may cause failures for
            legitimate long segments, while too long timeouts may cause the
            system to hang on failed requests.
            Default: 600 seconds (10 minutes).
            Range: 30 to 3600 seconds (30 seconds to 1 hour).

        response_format (str): The format in which the transcription should be
            returned from the API. Different formats provide different levels
            of information and structure:
            - "srt": SubRip subtitle format with numbered segments and timestamps
            - "vtt": WebVTT format, similar to SRT but with different syntax
            - "verbose_json": Detailed JSON with extensive metadata and timing
            Default: "srt" (widely compatible subtitle format).
            Allowed: "srt", "vtt", "verbose_json".

    Usage Guidelines:
        - Use temperature=0.0 for consistent, reliable transcriptions
        - Choose "srt" or "vtt" format when timestamp adjustment is needed
        - Use "verbose_json" when you need detailed metadata about the transcription
        - Set timeout based on your segment_duration: longer segments need more time
        - Word-level timestamps are useful for precise synchronization but increase cost

    Important Considerations:
        - Only "srt" and "vtt" formats support timestamp adjustment for streaming
        - Lower temperature values provide more consistent results across segments
        - Timeout should account for both transcription time and network latency
        - Different response formats may have varying processing overhead
    """

    model_name: WhisperModel = WhisperModel.WHISPER_1
    timestamp_granularities: List[str] = Field(default_factory=lambda: ["segment"])
    temperature: float = Field(default=0.0, ge=0.0, le=1.0)
    timeout: int = Field(
        default=600, description="API timeout in seconds", ge=30, le=3600
    )
    response_format: str = Field(
        default="srt", pattern="^(srt|vtt|verbose_json)$"  # Ensures only allowed values
    )


class ProcessingConfig(BaseModel):
    """
    Configuration for the overall processing workflow and resource management.

    This class controls system-level aspects of the media processing pipeline,
    including temporary file handling, cleanup behavior, token estimation, and
    timestamp adjustment. These settings affect system resources, storage usage,
    and output format rather than the core transcription quality.

    Parameters:
        temp_dir (Optional[str]): The directory path where temporary audio segments
            will be stored during processing. If None, the system automatically
            creates a temporary directory that will be cleaned up after processing.
            Specifying a custom directory gives you control over where temporary
            files are stored, which can be useful for systems with specific storage
            requirements or when debugging processing issues.
            Default: None (automatic temporary directory creation).

        cleanup_segments (bool): Controls whether temporary audio segment files
            are deleted after each segment is processed. Setting to True saves
            disk space and prevents accumulation of temporary files, but setting
            to False allows you to inspect or reuse the generated segments for
            debugging or alternative processing approaches.
            Default: True (clean up temporary files automatically).

        return_tokens (bool): Determines whether token count estimates are included
            in the processing results. Token counts help estimate API costs and
            understand the volume of text generated. The estimation uses tiktoken
            to approximate the number of tokens that would be consumed if the
            transcribed text were processed by language models.
            Default: False (don't include token estimates).

        adjust_segment_timestamps (bool): Controls whether timestamps in the
            transcription output are adjusted to reflect their position in the
            original media file rather than starting from zero for each segment.
            When True, timestamps are shifted so they represent the actual time
            in the source media. This is essential for creating accurate subtitles
            or synchronized content but only works with "srt" and "vtt" formats.
            Default: False (timestamps start from zero for each segment).

    Usage Guidelines:
        - Set cleanup_segments=False when debugging segmentation issues
        - Use return_tokens=True when monitoring API costs or text volume
        - Enable adjust_segment_timestamps for subtitle generation or media sync
        - Specify temp_dir when you need control over temporary file locations
        - Consider disk space when disabling cleanup for large media files

    Important Constraints:
        - adjust_segment_timestamps only works with response_format="srt" or "vtt"
        - Disabling cleanup_segments can consume significant disk space for long media
        - Token estimation is approximate and may not exactly match actual API usage
        - Custom temp_dir directories are not automatically cleaned up
    """

    temp_dir: Optional[str] = None
    cleanup_segments: bool = True
    return_tokens: bool = False
    adjust_segment_timestamps: bool = Field(
        default=False,
        description="Adjust timestamps to account for segment offsets",
    )


# Combine them into a single, top-level config object
class MediaProcessingConfig(BaseModel):
    """
    Comprehensive configuration container for the entire media processing pipeline.

    This is the top-level configuration class that combines all aspects of media
    processing into a single, cohesive configuration object. It provides a
    convenient way to manage and pass all processing parameters while maintaining
    clear separation of concerns between segmentation, transcription, and workflow
    management.

    The configuration is designed to provide sensible defaults that work well for
    most use cases while allowing fine-tuned control over every aspect of the
    processing pipeline when needed. The default configuration targets processing
    long-form audio content (like lectures, meetings, or interviews) with good
    quality transcription while staying within API limits and managing resources
    efficiently.

    Parameters:
        segmentation (SegmentationConfig): Configuration for how the input media
            file is broken down into processable segments. This includes timing,
            quality, and speech detection parameters that determine how the audio
            is divided for transcription.
            Default: SegmentationConfig() with standard defaults.

        transcription (TranscriptionConfig): Configuration for the Whisper API
            calls that perform the actual speech-to-text conversion. This controls
            model selection, output format, and API behavior for each segment.
            Default: TranscriptionConfig() with standard defaults.

        processing (ProcessingConfig): Configuration for workflow management,
            temporary file handling, and output formatting. This controls system
            resources and how results are prepared and delivered.
            Default: ProcessingConfig() with standard defaults.

    Usage Patterns:

        Basic Usage (with defaults):
            config = MediaProcessingConfig()

        Customizing specific aspects:
            config = MediaProcessingConfig(
                segmentation=SegmentationConfig(segment_duration=7200),  # 2 hours
                transcription=TranscriptionConfig(response_format="vtt"),
                processing=ProcessingConfig(adjust_segment_timestamps=True)
            )

        Optimizing for different media types:
            # For long lectures with clear speech
            lecture_config = MediaProcessingConfig(
                segmentation=SegmentationConfig(
                    segment_duration=12000,  # Longer segments
                    silence_duration=5.0     # Allow shorter pauses
                )
            )

            # For conversational content with background noise
            conversation_config = MediaProcessingConfig(
                segmentation=SegmentationConfig(
                    segment_duration=6000,    # Shorter segments
                    silence_threshold=0.003,  # Higher noise tolerance
                    bitrate=16               # Better quality for noisy audio
                )
            )

    Integration Notes:
        - This configuration object is passed to process_media_streaming() function
        - All parameters are validated using Pydantic models for type safety
        - Default values are optimized for general-purpose media transcription
        - The configuration can be serialized to/from JSON for persistence
        - Parameter validation occurs at configuration creation time, not runtime
    """

    segmentation: SegmentationConfig = Field(default_factory=SegmentationConfig)
    transcription: TranscriptionConfig = Field(default_factory=TranscriptionConfig)
    processing: ProcessingConfig = Field(default_factory=ProcessingConfig)
