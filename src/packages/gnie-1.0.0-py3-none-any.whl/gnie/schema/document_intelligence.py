from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import List, Optional, Union

from azure.ai.documentintelligence.models import AnalyzeResult


class OutputFormat(str, Enum):
    """Supported output formats."""

    TEXT = "text"
    MARKDOWN = "markdown"


class ContentType(str, Enum):
    """Common content types."""

    OCTET_STREAM = "application/octet-stream"
    PDF = "application/pdf"
    IMAGE_JPEG = "image/jpeg"
    IMAGE_PNG = "image/png"
    IMAGE_TIFF = "image/tiff"
    DOC = "application/msword"
    DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    PPT = "application/vnd.ms-powerpoint"
    PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation"


@dataclass(frozen=True)
class AnalysisConfig:
    """Configuration for document analysis."""

    model_id: str = "prebuilt-layout"
    output_format: OutputFormat = OutputFormat.MARKDOWN
    content_type: ContentType = ContentType.OCTET_STREAM
    max_retries: int = 3
    timeout_seconds: int = 300
    exponential_backoff_base: float = 2.0
    max_backoff_seconds: float = 60.0


@dataclass
class DocumentInput:
    """Input specification for a single document."""

    file_path: Union[str, Path]
    pages: Optional[Union[int, str, List[int]]] = None
    config_override: Optional[AnalysisConfig] = None

    def __post_init__(self):
        """Convert file_path to Path if string."""
        if isinstance(self.file_path, str):
            self.file_path = Path(self.file_path)


@dataclass
class AnalysisResult:
    """Result of document analysis."""

    file_path: str
    result: Optional[AnalyzeResult] = None
    error: Optional[Exception] = None
    processing_time: float = 0.0
    retry_count: int = 0
    index: Optional[int] = None  # For tracking order in batch
    pages_analyzed: Optional[str] = None  # Track which pages were analyzed

    @property
    def success(self) -> bool:
        return self.error is None and self.result is not None
