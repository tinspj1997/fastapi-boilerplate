from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Dict, List

from langchain.schema import Document
from typing_extensions import TypedDict


class ContentType(Enum):
    SUMMARY = "summary"
    OUTLINE = "outline"
    TITLE = "title"
    BULLET_POINTS = "bullet_points"
    EXECUTIVE_OVERVIEW = "executive_overview"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value

    def to_json(self):
        return self.value


class ProcessingState(Enum):
    CHUNKING = "chunking"
    PROCESSING_CHUNKS = "processing_chunks"
    HIERARCHICAL_PROCESSING = "hierarchical_processing"
    FINAL_GENERATION = "final_generation"
    COMPLETED = "completed"
    FAILED = "failed"
    RATE_LIMITED = "rate_limited"


@dataclass
class GenerationConfig:
    content_type: ContentType = ContentType.SUMMARY
    max_chunk_size: int = 4000
    chunk_overlap: int = 200
    max_final_tokens: int = 3000
    compression_ratio: float = 0.1
    parallel_processing: bool = True
    max_workers: int = 4
    use_cache: bool = True
    streaming: bool = False
    temperature: float = 0.3
    model_name: str = "gpt-4o"
    max_retries: int = 3
    retry_delay: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        config_dict = asdict(self)
        config_dict["content_type"] = self.content_type.value
        return config_dict

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GenerationConfig":
        if "content_type" in data:
            data["content_type"] = ContentType(data["content_type"])
        return cls(**data)


class ContentGraphState(TypedDict):
    document: str
    chunks: List[Document]
    initial_token_count: int
    chunk_outputs: List[str]
    intermediate_outputs: List[str]
    final_output: str
    token_usage: Dict[str, int]
    metadata: Dict[str, Any]
    processing_state: str
    failed_chunks: List[int]  # Track failed chunk indices
    processed_chunks: List[int]  # Track successfully processed chunk indices
    current_chunk_index: int
    current_hierarchical_level: int
    rate_limited: bool
    error_message: str
    session_id: str
    llm_config: Dict[str, Any]  # Store LLM configuration
