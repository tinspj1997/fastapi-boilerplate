from pydantic import BaseModel,ConfigDict
from typing import Optional, Dict

class LLMModel(BaseModel):
    id:int
    model_name: str
    name: str  # Corresponds to SQLAlchemy's name field
    model_id: str
    api_key: Optional[str] = None  # Encrypted or obfuscated
    endpoint: Optional[str] = None  # API endpoint URL
    version: Optional[str] = None
    model_type: str  # e.g., LLM, EMBEDDING
    provider: Optional[str] = None  # e.g., Azure, OpenAI
    max_tokens: Optional[int] = None
    temperature: Optional[float] = 0.7
    description: Optional[str] = None
    is_active: bool = True
    environment: Optional[str] = None
    model_config = ConfigDict(from_attributes=True)