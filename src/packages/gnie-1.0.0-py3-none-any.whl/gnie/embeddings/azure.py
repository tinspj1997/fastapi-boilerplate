from langchain_openai import AzureOpenAIEmbeddings as AzureOpenAIEmbeddingWrapper

"""
deployment=cfg.model.name,
azure_endpoint=cfg.endpoint,
api_key=cfg.api_key,
api_version=cfg.api_version,
dimensions=cfg.model.dimensions,
"""


class AzureOpenAI:
    def __new__(
        cls,
        model_name: str = "text-embedding-3-large",
        azure_endpoint: str | None = None,
        api_key: str | None = None,
        api_version: str | None = None,
        dimensions: int | None = None,
    ):
        return AzureOpenAIEmbeddingWrapper(
            azure_deployment=model_name,
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=api_version,
            dimensions=dimensions,
        )
