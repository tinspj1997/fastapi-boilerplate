from langchain.embeddings.base import Embeddings
from sentence_transformers import SentenceTransformer
from typing import List


class Matryoshka(Embeddings):
    def __init__(self):
        # model_name="tomaarsen/mpnet-base-nli-matryoshka"
        # encode_kwargs={"batch_size": 32, "normalize_embeddings": True},
        model_name = "mixedbread-ai/mxbai-embed-large-v1"
        self.model = SentenceTransformer(model_name, device="cpu")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        return [self.model.encode(text).tolist() for text in texts]

    def embed_query(self, query: str) -> List[float]:
        return self.model.encode(query).tolist()
