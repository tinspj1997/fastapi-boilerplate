from abc import ABC
from typing import List, Union
from langchain.prompts.chat import ChatPromptTemplate


class Prompt(ABC):
    def create_prompt(
        self,
        system: str,
        question: str,
        history: List[dict],
        prompt_values: Union[dict, None] = dict(),
    ):
        """Create a prompt for the LLM.

        Args:
            system: The system message
            question: The question to ask
            history: A list of dictionaries containing historical context

        Returns:
            str: The created prompt
        """
        templates = []
        if system:
            templates.append(("system", system))

        if history:
            for item in history:
                templates.append(("human", item["question"]))
                templates.append(("ai", item["answer"]))

        if question:
            templates.append(question)
        chat_template = ChatPromptTemplate(templates)
        return chat_template.invoke(prompt_values)
