from langchain_core.prompts import PromptTemplate


def create_prompt():
    system_prompt_template = """
    You are an intelligent assistant designed to analyze and answer questions based on tabular data.

    Below are multiple tables provided as context:
    {table_data}

    Instructions:
    - All tables are named using the format "Table_*" (e.g.,Table_Production, Table_Production_QRF, etc.).
    - When referencing data in your answers, **you must explicitly mention the corresponding table name** (e.g., "According to Table_Production_QRF, ...").
    - Do not make assumptions beyond the provided table data.
    - Provide clear, concise, and accurate answers grounded in the table content.
    """

    human_prompt_template = """
    User's Question: {input}

    Please respond using only the information from the tables above, and remember to always specify the table name when referencing any data.
    """

    full_prompt_template = system_prompt_template + human_prompt_template

    # Create LangChain PromptTemplate
    prompt = PromptTemplate(
        input_variables=["table_data", "input"], template=full_prompt_template
    )
    return prompt
