from dataclasses import dataclass, field
from typing import Optional, List, Union, Tuple
from multiprocessing import Pool, cpu_count
import tiktoken
from langchain_core.documents import Document


@dataclass
class Tiktoken:
    encoding_name: Optional[str] = None
    model_name: Optional[str] = None
    encoding: tiktoken.Encoding = field(init=False)

    def __post_init__(self):
        """
        Initialize the encoding after dataclass initialization.
        If both encoding_name and model_name are provided, model_name takes precedence.
        """
        if self.model_name:
            self.encoding = tiktoken.encoding_for_model(self.model_name)
        elif self.encoding_name:
            self.encoding = tiktoken.get_encoding(self.encoding_name)
        else:
            raise ValueError("You must provide either encoding_name or model_name.")

    def encode(self, text: str) -> List[int]:
        """Encode text into tokens (list of integers)."""
        return self.encoding.encode(text, disallowed_special=())

    def decode(self, tokens: List[int]) -> str:
        """Decode a list of tokens back into text."""
        return self.encoding.decode(tokens)

    def count_tokens(self, text: str) -> int:
        """Count the number of tokens in a text string."""
        return len(self.encode(text))

    def decode_single_token_bytes(self, token: int) -> bytes:
        """Decode a single token into its byte representation."""
        return self.encoding.decode_single_token_bytes(token)

    def _process_document(self, doc: Document):
        token_count = self.count_tokens(doc.page_content)
        doc.metadata["token_count"] = token_count
        return doc

    def count_documents_tokens(
        self,
        documents: List[Document],
        max_workers: int = None,
        aggregate_token_count: bool = False,
    ) -> Union[List[Document], Tuple[List[Document], int]]:
        """
        Count tokens for each Document's 'page_content' using multiprocessing.
        The token count will be stored in document.metadata['page_count'].

        Args:
        documents (List[Document]): List of Langchain Document objects.
        processes (int, optional): Number of processes to use. Defaults to CPU count.

        Returns:
        List[Document]: The list of documents with updated 'token_count' in metadata.
        """
        worker_count = max_workers or cpu_count()
        with Pool(processes=worker_count) as pool:
            updated_documents = pool.map(self._process_document, documents)

        if aggregate_token_count:
            total_token_count = sum(
                doc.metadata.get("token_count", 0) for doc in updated_documents
            )
            return updated_documents, total_token_count

        return updated_documents

    def limit_tokens(self, documents, max_tokens: int = 10000):
        """
        Limit the number of tokens in the provided documents.

        Args:
            documents (list): List of documents, each with metadata including 'token_count'.
            max_tokens (int): The maximum number of tokens allowed across all documents.

        Returns:
            list: A list of documents not exceeding the token limit.
        """
        if not documents or not isinstance(documents, list):
            raise ValueError("No documents provided for token limiting.")

        if not isinstance(max_tokens, int) or max_tokens < 1:
            raise ValueError("max_tokens must be a positive integer and more than 0")

        total_tokens = 0
        final_docs = []

        for doc in documents:
            doc_tokens = int(doc.get("metadata").get("token_count", 0))

            if doc_tokens <= 0:
                continue

            if total_tokens + doc_tokens > max_tokens:
                break

            final_docs.append(doc)
            total_tokens += doc_tokens

        return final_docs
