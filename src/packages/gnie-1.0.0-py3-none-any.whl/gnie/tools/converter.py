import subprocess
from pathlib import Path
from typing import Optional, Union


class OfficeToPdfConverter:
    SUPPORTED_EXTENSIONS = {".docx", ".pptx"}

    def __init__(self): ...

    def libreoffice_converter(
        self,
        input_path: Union[str, Path],
        output_dir: Optional[Union[str, Path]] = None,
        libreoffice_cmd: str = "soffice",
    ) -> str:
        """
        Converts a supported document file to PDF using LibreOffice in headless mode.
        Args:
            input_path (Union[str, Path]): Path to the input file to be converted.
            output_dir (Optional[Union[str, Path]], optional): Directory where the output PDF will be saved.
                If None, the PDF will be saved in the same directory as the input file. Defaults to None.
            libreoffice_cmd (str, optional): Command or path to the LibreOffice executable. Defaults to "soffice".
        Returns:
            str: Path to the generated PDF file.
        Raises:
            FileNotFoundError: If the input file does not exist or the PDF was not created.
            ValueError: If the input file extension is not supported or the output path is not a directory.
            RuntimeError: If the LibreOffice conversion fails, times out, or the generated PDF is empty.
        """
        # Validate input file
        input_file = Path(input_path).resolve()

        if not input_file.exists():
            raise FileNotFoundError(f"Input file not found: {input_file}")

        if input_file.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
            supported = ", ".join(self.SUPPORTED_EXTENSIONS)
            raise ValueError(
                f"Unsupported file extension: {input_file.suffix}. Supported: {supported}"
            )

        # Setup output directory
        if output_dir is None:
            output_directory = input_file.parent
        else:
            output_directory = Path(output_dir).resolve()

            # Create directory if it doesn't exist
            if not output_directory.exists():
                output_directory.mkdir(parents=True, exist_ok=True)
                print(f"Created output directory: {output_directory}")

            if not output_directory.is_dir():
                raise ValueError(f"Output path is not a directory: {output_directory}")

        # Generate output PDF path
        pdf_filename = input_file.stem + ".pdf"
        output_pdf_path = output_directory / pdf_filename

        # Run LibreOffice conversion
        command = [
            libreoffice_cmd,
            "--headless",
            "--convert-to",
            "pdf",
            "--outdir",
            str(output_directory),
            str(input_file),
        ]

        try:
            result = subprocess.run(
                command, check=True, capture_output=True, text=True, timeout=60
            )

            if result.stdout:
                print("STDOUT:", result.stdout.strip())
            if result.stderr:
                print("STDERR:", result.stderr.strip())

        except subprocess.TimeoutExpired:
            raise RuntimeError("LibreOffice conversion timed out after 60 seconds")
        except subprocess.CalledProcessError as e:
            error_msg = e.stderr.strip() if e.stderr else str(e)
            raise RuntimeError(f"LibreOffice conversion failed: {error_msg}") from e

        # Verify PDF was created
        if not output_pdf_path.exists():
            raise FileNotFoundError(f"PDF not created: {output_pdf_path}")

        if output_pdf_path.stat().st_size == 0:
            raise RuntimeError(f"PDF file is empty: {output_pdf_path}")

        return str(output_pdf_path)
