# from api.core.logger.logger import ApplicationLogger
# from api.core.exceptions import TranslateServiceError
# from api.utils.response_handler import ResponseHandler
# from api.core.config import settings
# from datetime import datetime
# from azure.core.exceptions import HttpResponseError
# from azure.core.credentials import AzureKeyCredential
# from azure.ai.translation.text.aio import TextTranslationClient
# from azure.ai.translation.document.aio import DocumentTranslationClient
# from azure.storage.blob import BlobServiceClient, ContentSettings
# import time
# import os
# from api.core.logger.logger import ApplicationLogger
# from api.core.logger.logger import MeteringLogger


# app_logger = ApplicationLogger()
# metering_logger = MeteringLogger()


# class TranslateService:
#     def __init__(self):
#         try:
#             start_time = datetime.now()
#             app_logger.log_message(
#                 "INFO",
#                 "",
#                 "GBB",
#                 "SYSTEM",
#                 "COMMON",
#                 "TranslateService",
#                 "__init__",
#                 "Started __init__ Translate Service",
#             )
#             end_time = datetime.now()
#             time_taken = int((end_time - start_time).total_seconds() * 1000)
#             metering_logger.log_message(
#                 "",
#                 "GBB",
#                 "SYSTEM",
#                 "TRANSLATE",
#                 "TranslateService",
#                 "__init__",
#                 start_time,
#                 end_time,
#                 time_taken,
#             )
#         except Exception as e:
#             app_logger.log_message(
#                 "ERROR",
#                 "",
#                 "GBB",
#                 "SYSTEM",
#                 "COMMON",
#                 "TranslateService",
#                 "__init__",
#                 f"Failed to initialize TranslateService: {str(e)}",
#             )
#             raise TranslateServiceError(f"Service initialization failed: {str(e)}")

#     async def translate_text(self, user, payload, req_id: str = ""):
#         app_logger.log_message(
#             "DEBUG",
#             req_id,
#             payload.tenant_name,
#             user,
#             "Translate",
#             "translate_service",
#             "translate_text",
#             f"function called initiated.",
#         )
#         try:
#             start_time = datetime.now()
#             detected_language = None
#             trans_sent_length = []
#             key = settings.services.text_translator.key
#             region = settings.services.text_translator.region
#             credential = AzureKeyCredential(key)
#             text_translator_client = TextTranslationClient(
#                 credential=credential, region=region
#             )
#             translated_text_list = []
#             async with text_translator_client:
#                 response = await text_translator_client.translate(
#                     body=[payload.input_text],
#                     to_language=payload.to_language,
#                     include_sentence_length=True,
#                 )
#                 translation = response[0] if response else None
#                 if translation:
#                     detected_language = translation.detected_language
#                     for translated_text in translation.translations:
#                         translated_text_list.append(translated_text.text)
#                         trans_sent_length += translated_text.sent_len.trans_sent_len
#                     return ResponseHandler.success(
#                         "Successfully translated text",
#                         [
#                             {
#                                 "translated_text": translated_text_list,
#                                 "trans_sent_length": trans_sent_length,
#                                 "detected_language": detected_language,
#                             }
#                         ],
#                     )
#                 else:
#                     return ResponseHandler.error(
#                         "Failed to translated text", "500", None
#                     )

#             end_time = datetime.now()
#             time_taken = int((end_time - start_time).total_seconds() * 1000)
#             metering_logger.log_message(
#                 req_id,
#                 "GBB",
#                 user,
#                 "TRANSLATE",
#                 "TranslateService",
#                 "translate_text",
#                 start_time,
#                 end_time,
#                 time_taken,
#             )
#         except HttpResponseError as exception:
#             if exception.error is not None:
#                 app_logger.log_message(
#                     "ERROR",
#                     req_id,
#                     payload.tenant_name,
#                     user,
#                     "Translate",
#                     "translate_service",
#                     "translate_text",
#                     f"Failed to  translated text Error:{exception.error.message}",
#                 )
#                 return ResponseHandler.error(
#                     f"Failed to  translate text Error:{exception.error.message}",
#                     "500",
#                     None,
#                 )
#             else:
#                 app_logger.log_message(
#                     "ERROR",
#                     req_id,
#                     payload.tenant_name,
#                     user,
#                     "Translate",
#                     "translate_service",
#                     "translate_text",
#                     "Failed to translated text duo HttpResponseError",
#                 )
#                 return ResponseHandler.error(
#                     "Failed to  translate text due to HttpResponseError", "500", None
#                 )

#         except Exception as e:
#             app_logger.log_message(
#                 "ERROR",
#                 req_id,
#                 payload.tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "translate_text",
#                 f"Error while executing function and the error is {e}",
#             )
#             return ResponseHandler.error(
#                 f"Error while executing translate_text and the error is :{exception.error.message}",
#                 "500",
#                 None,
#             )

#     async def translate_documents(
#         self,
#         tenant_name: str,
#         user: str,
#         source_sas_url: str,
#         target_language: str,
#         target_full_language: str,
#         req_id: str = "",
#     ):
#         """
#         Start the document translation process.

#         :param source_sas_url: SAS URL for the source container.
#         :param target_language: The language code to translate the document into.
#         :return: The result of the translation operation.
#         """
#         try:
#             start_time = datetime.now()
#             app_logger.log_message(
#                 "DEBUG",
#                 req_id,
#                 tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "translate_documents",
#                 f"function called with parameters blob_url: {source_sas_url}, target_language: {target_language}",
#             )
#             parts = source_sas_url.split("/")
#             # The filename is the last part of the URL before the query parameters
#             filename_with_params = parts[-1]
#             # Split the filename from the query parameters
#             filename, params = filename_with_params.split("?", 1)
#             filename_without_extension, extension = os.path.splitext(
#                 os.path.basename(filename)
#             )
#             self.timestamp = datetime.now()
#             formatted_timestamp = self.timestamp.strftime("%Y%m%d%H%M%S")
#             new_filename = (
#                 target_full_language + "-" + filename_without_extension + extension
#             )
#             app_logger.log_message(
#                 "DEBUG",
#                 req_id,
#                 tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "translate_documents",
#                 f"new file name for the target file is set to {new_filename}",
#             )

#             # Replace the filename with the new filename
#             new_filename_with_params = new_filename + "?" + params
#             # Reconstruct the URL with the new filename
#             parts[-1] = new_filename_with_params
#             target_sas_url = "/".join(parts)
#             time.sleep(2)
#             endpoint = settings.services.document_translator.end_point
#             key = settings.services.document_translator.api_key
#             client = DocumentTranslationClient(endpoint, AzureKeyCredential(key))
#             async with client:
#                 poller = await client.begin_translation(
#                     source_url=source_sas_url,
#                     target_url=target_sas_url,
#                     target_language=target_language,
#                     storage_type="File",
#                 )
#                 result = await poller.result()
#                 total_characters_charged = poller.details.total_characters_charged
#                 async for document in result:
#                     if document.status == "Succeeded":
#                         app_logger.log_message(
#                             "DEBUG",
#                             req_id,
#                             tenant_name,
#                             user,
#                             "Translate",
#                             "translate_service",
#                             "translate_documents",
#                             f"document translation succeeded for Document ID: {document.id}, Translated document location: {document.translated_document_url}, Translated to language: {document.translated_to}",
#                         )
#                         if extension in [".pdf"]:
#                             app_logger.log_message(
#                                 "DEBUG",
#                                 req_id,
#                                 tenant_name,
#                                 user,
#                                 "Translate",
#                                 "translate_service",
#                                 "translate_documents",
#                                 "Translated file is a pdf setting http headers",
#                             )
#                             set_http_headers = await self.set_pdf_http_headers(
#                                 tenant_name, user, target_sas_url, new_filename, req_id
#                             )
#                             if set_http_headers:
#                                 app_logger.log_message(
#                                     "DEBUG",
#                                     req_id,
#                                     tenant_name,
#                                     user,
#                                     "Translate",
#                                     "translate_service",
#                                     "translate_documents",
#                                     f"successfully set http headers application/pdf for the translated pdf {new_filename}",
#                                 )
#                             else:
#                                 app_logger.log_message(
#                                     "DEBUG",
#                                     req_id,
#                                     tenant_name,
#                                     user,
#                                     "Translate",
#                                     "translate_service",
#                                     "translate_documents",
#                                     f"failed to set http headers application/pdf for the translated pdf {new_filename}",
#                                 )
#                         return ResponseHandler.success(
#                             f"Successfully translated {filename}",
#                             [
#                                 {
#                                     "url": document.translated_document_url
#                                     + "?"
#                                     + params,
#                                     "transFileName": new_filename,
#                                     "total_characters_charged": total_characters_charged,
#                                 }
#                             ],
#                         )

#                     else:
#                         return ResponseHandler.error(
#                             {document.error.message},
#                             {document.error.code},
#                             document.error.message,
#                         )
#             end_time = datetime.now()
#             time_taken = int((end_time - start_time).total_seconds() * 1000)
#             metering_logger.log_message(
#                 req_id,
#                 "GBB",
#                 user,
#                 "TRANSLATE",
#                 "TranslateService",
#                 "translate_documents",
#                 start_time,
#                 end_time,
#                 time_taken,
#             )
#         except Exception as e:
#             app_logger.log_message(
#                 "ERROR",
#                 req_id,
#                 tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "translate_documents",
#                 f"Error while executing function and the error is {e}",
#             )
#             return ResponseHandler.error(
#                 f"Error while executing translate_documents and the error is :{e}",
#                 "500",
#                 None,
#             )

#     async def _process_blob_url(
#         self, blob_URL: str, user: str, tenant_name: str, req_id: str = ""
#     ) -> str:
#         """Process the blob URL to extract container and blob names, then download the blob."""
#         try:
#             start_time = datetime.now()
#             url_parts = blob_URL.split("/")
#             self.container = "/".join(url_parts[3:-1])
#             end_time = datetime.now()
#             time_taken = int((end_time - start_time).total_seconds() * 1000)
#             metering_logger.log_message(
#                 req_id,
#                 "GBB",
#                 user,
#                 "TRANSLATE",
#                 "TranslateService",
#                 "translate_documents",
#                 start_time,
#                 end_time,
#                 time_taken,
#             )
#             return self.container
#         except Exception as e:
#             app_logger.log_message(
#                 "ERROR",
#                 req_id,
#                 tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "_process_blob_url",
#                 f"Error while executing function and the error is {e}",
#             )

#     async def set_pdf_http_headers(
#         self, tenant_name, user, source_sas_url, new_filename, req_id: str = ""
#     ):
#         try:
#             start_time = datetime.now()
#             app_logger.log_message(
#                 "DEBUG",
#                 req_id,
#                 tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "set_pdf_http_headers",
#                 f"function called with parameters source_sas_url: {source_sas_url}",
#             )
#             account_name = settings.services.upload_config.blob_account_name
#             account_key = settings.services.upload_config.blob_account_key
#             container_name = await self._process_blob_url(
#                 source_sas_url, user, tenant_name, req_id
#             )
#             # Set up the BlobServiceClient
#             blob_service_client = BlobServiceClient(
#                 account_url=f"https://{account_name}.blob.core.windows.net",
#                 credential=account_key,
#             )
#             container_client = blob_service_client.get_container_client(container_name)
#             blob_client = container_client.get_blob_client(new_filename)

#             # Set the correct content type for the blob (e.g., application/pdf for PDFs)
#             content_settings = ContentSettings(
#                 content_type="application/pdf"
#             )  # Change this to the appropriate MIME type for your file

#             # Update the blob's content settings
#             set_headers = blob_client.set_http_headers(
#                 content_settings=content_settings
#             )
#             if set_headers:
#                 app_logger.log_message(
#                     "DEBUG",
#                     req_id,
#                     tenant_name,
#                     user,
#                     "Translate",
#                     "translate_service",
#                     "set_pdf_http_headers",
#                     f"Content type set to {content_settings.content_type} for blob '{new_filename}' in container '{container_name}'",
#                 )
#                 return f"Content type set to {content_settings.content_type} for blob '{new_filename}' in container '{container_name}'"
#             end_time = datetime.now()
#             time_taken = int((end_time - start_time).total_seconds() * 1000)
#             metering_logger.log_message(
#                 req_id,
#                 "GBB",
#                 user,
#                 "TRANSLATE",
#                 "TranslateService",
#                 "set_pdf_http_headers",
#                 start_time,
#                 end_time,
#                 time_taken,
#             )
#         except Exception as e:
#             app_logger.log_message(
#                 "ERROR",
#                 req_id,
#                 tenant_name,
#                 user,
#                 "Translate",
#                 "translate_service",
#                 "set_pdf_http_headers",
#                 f"Error while executing function and the error is {e}",
#             )
