from typing import List, NewType
from azure.core.credentials import AzureKeyCredential
from azure.ai.translation.text import TextTranslationClient
from azure.ai.translation.text.aio import (
    TextTranslationClient as AsyncTextTranslationClient,
)
from azure.ai.translation.document.aio import (
    DocumentTranslationClient as AsyncDocumentTranslationClient,
)
from azure.ai.translation.document import DocumentStatus

HttpsUrl = NewType("HttpsUrl", str)


class AzureTextTranslate:
    def __init__(self, api_key: str, region: str = "EastUS") -> None:
        self.api_key = api_key
        self.region = region
        self.credential = AzureKeyCredential(self.api_key)
        self.client = TextTranslationClient(
            credential=self.credential, region=self.region
        )

    def get_supported_languages(self) -> dict:
        """Return supported languages from the text translation service."""
        return self.client.get_supported_languages()

    def translate(self, content: str, to_language: List[str]) -> str:
        """Translate the given content to the target languages (sync).

        Args:
            content (str): Text to translate.
            to_language (List[str]): List of target language codes.

        Returns:
            str: Translated text from the first target language or empty string.

        Raises:
            ValueError: If input types are invalid.
        """
        if not isinstance(content, str):
            raise ValueError(f"content should be str, but got {type(content)}")
        if not isinstance(to_language, list):
            raise ValueError(f"to_language should be list, but got {type(to_language)}")

        response = self.client.translate(
            body=[content], to_language=to_language, include_sentence_length=True
        )
        translation = response[0] if response else None
        # return translation.translations[0].text if translation else ""
        return translation

    async def atranslate(self, content: str, to_language: List[str]) -> str:
        """Translate the given content to the target languages (async).

        Args:
            content (str): Text to translate.
            to_language (List[str]): List of target language codes.

        Returns:
            str: Translated text from the first target language or empty string.

        Raises:
            ValueError: If input types are invalid.
        """
        if not isinstance(content, str):
            raise ValueError(f"content should be str, but got {type(content)}")
        if not isinstance(to_language, list):
            raise ValueError(f"to_language should be list, but got {type(to_language)}")

        async with AsyncTextTranslationClient(
            credential=self.credential, region=self.region
        ) as client:
            response = await client.translate(
                body=[content], to_language=to_language, include_sentence_length=True
            )
            translation = response[0] if response else None
            # return translation.translations[0].text if translation else ""
            return translation


# class AzureDocumentTranslate:
#     def __init__(self, endpoint: HttpsUrl, api_key: str) -> None:
#         self.client = AsyncDocumentTranslationClient(
#             endpoint, AzureKeyCredential(api_key)
#         )

#     async def atranslate(
#         self, source_sas_url: HttpsUrl, target_sas_url: HttpsUrl, to_language: str
#     ) -> DocumentStatus:
#         """
#         Asynchronously translates documents from a source SAS URL to a target SAS URL using Azure Translator.

#         Args:
#             source_sas_url (HttpsUrl): The SAS URL of the source Azure Blob container containing the documents to translate.
#             target_sas_url (HttpsUrl): The SAS URL of the target Azure Blob container where the translated documents will be saved.
#             to_language (str): The language code to translate the documents into (e.g., 'es' for Spanish).

#         Returns:
#             DocumentStatus: An object representing the status of the translation operation.
#                 - `DocumentStatus.translated_document_url` (str): The URL of the translated document, if available.
#                 - `DocumentStatus.characters_charged` (int): The number of characters that were translated (used for billing purposes).
#         """

#         async with self.client:
#             poller = await self.client.begin_translation(
#                 source_url=source_sas_url,
#                 target_url=target_sas_url,
#                 target_language=to_language,
#                 storage_type="File",
#             )
#             result = await poller.result()
#             async for document in result:
#                 return document

class AzureDocumentTranslate:
    def __init__(self, endpoint: HttpsUrl, api_key: str) -> None:
        self.endpoint = endpoint
        self.api_key = api_key
 
    async def atranslate(
        self, source_sas_url: HttpsUrl, target_sas_url: HttpsUrl, to_language: str
    ) -> DocumentStatus:
        async with AsyncDocumentTranslationClient(
            self.endpoint, AzureKeyCredential(self.api_key)
        ) as client:
            poller = await client.begin_translation(
                source_url=source_sas_url,
                target_url=target_sas_url,
                target_language=to_language,
                storage_type="File",
            )
            result = await poller.result()
            documents=[]
            async for document in result:
                documents.append(document)
            if documents:
                return documents[0]
            return documents