import redis
import random
from typing import List, Optional, Dict
from gnie.llm.azure import AzureChatOpenAI


class SubscriptionSwitch:
    __slots__ = [
        "_redis",
        "config",
        "instance_type",
        "redis_url",
        "username",
        "password",
        "core_clients",
    ]

    def __init__(
        self,
        config: Dict[str, Dict[str, Dict]],
        instance_type: str,
        redis_url: str = "redis://localhost:6379/0",
        username: Optional[str] = None,
        password: Optional[str] = None,
    ):
        self.config = config
        self.instance_type = instance_type
        self.redis_url = redis_url
        self.username = username
        self.password = password
        self._redis = None  # Lazy initialization
        # self.core_clients = {"llm": {"azure": AzureChatOpenAI}}
        self.core_clients = {
            instance_type: {"azure": AzureChatOpenAI}
            for instance_type in config.keys()
        }

    @property
    def redis(self) -> redis.Redis:
        if self._redis is None:
            self._redis = redis.Redis.from_url(
                self.redis_url,
                username=self.username,
                password=self.password,
                decode_responses=True,
            )
        return self._redis

    def _get_key(self, instance_type: str, client: str) -> str:
        """Generate the Redis key for a given client."""
        return f"subscription_{instance_type}_{client}"

    def _get_client_from_key(self, key: str) -> str:
        """Extract client name from a Redis key."""
        parts = key.split("_")
        if len(parts) >= 3:
            return parts[2]
        return None

    def _get_client(self, instance_type: str, key: str) -> List[str]:
        """Generate the Redis key for a given client."""
        client_name = self._get_client_from_key(key)
        if client_name is None:
            return None

        client_config = self.config[instance_type][client_name]
        if client_config is None:
            return None
        payload = client_config.copy()
        payload.pop("provider", None)
        return self.core_clients[instance_type][client_config["provider"]](**payload)

    def get_least_used_client(self) -> str:
        """
        Retrieves the least used client.
        Returns:
        str: The name of the least used client.
        """
        if self.instance_type not in self.config.keys():
            raise ValueError(
                f"Unsupported instance_type: {self.instance_type}. Choose from {list(self.config.keys())}"
            )

        clients = self.config[self.instance_type].keys()
        usage_map = {}

        for client in clients:
            key = self._get_key(self.instance_type, client)
            usage = self.redis.get(key)

            if usage is None:
                self.redis.set(key, 0)
                usage = 0

            usage_map[key] = int(usage)

        min_usage = min(usage_map.values())
        least_used_keys = list(
            filter(lambda item: item[1] == min_usage, usage_map.items())
        )

        chosen_key, _ = random.choice(least_used_keys)
        self.increment_usage(chosen_key)

        return self._get_client(self.instance_type, chosen_key)

    def increment_usage(self, key_or_client: str):
        """
        Increments the usage count for a given client or Redis key.
        Args:
        key_or_client (str): Either a full Redis key or a client name.
        """
        key = key_or_client
        if not key.startswith("subscription_"):
            key = self._get_key(key)
        self.redis.incr(key)
