import gc
import hashlib
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import tiktoken
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.prompts import PromptTemplate
from langchain.schema import Document
from langchain.schema.runnable import RunnableConfig
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import AzureChatOpenAI
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph
from openai import RateLimitError

from gnie.schema.content_generator import (
    ContentGraphState,
    ContentType,
    GenerationConfig,
    ProcessingState,
)


class RateLimitException(Exception):
    """Custom exception for rate limit handling"""

    def __init__(self, message: str, chunk_index: int = None):
        self.message = message
        self.chunk_index = chunk_index
        super().__init__(self.message)


class ContentEngine:
    def __init__(
        self,
        config: GenerationConfig = None,
        llm_config: Optional[Dict[str, Any]] = None,
    ):
        self.config = config or GenerationConfig()
        self.tokenizer = tiktoken.encoding_for_model(self.config.model_name)
        self.cache = {}
        self.checkpointer = MemorySaver()
        self.graph = self._build_graph()
        self._llm_switch_callback: Optional[Callable] = None
        self._lock = threading.Lock()
        self._test_count = 1
        self.llm = self._initialize_llm(llm_config)

    def set_llm_switch_callback(self, callback: Callable[[str], Dict[str, Any]]):
        """Set callback function to handle LLM switching"""
        self._llm_switch_callback = callback

    def _initialize_llm(self, custom_config: Dict[str, Any] = None) -> AzureChatOpenAI:
        """Initialize LLM with custom configuration if provided"""
        callbacks = [StreamingStdOutCallbackHandler()] if self.config.streaming else []

        if custom_config:
            return AzureChatOpenAI(
                model=custom_config.get("model", os.getenv("AZURE_CHAT_OPENAI_MODEL")),
                azure_endpoint=custom_config.get(
                    "endpoint", os.getenv("AZURE_CHAT_OPENAI_ENDPOINT")
                ),
                api_key=custom_config.get(
                    "api_key", os.getenv("AZURE_CHAT_OPENAI_KEY")
                ),
                api_version=custom_config.get(
                    "api_version",
                    os.getenv("AZURE_CHAT_OPENAI_VERSION", "2024-08-01-preview"),
                ),
                temperature=self.config.temperature,
                max_tokens=self.config.max_final_tokens,
                streaming=self.config.streaming,
                callbacks=callbacks,
                request_timeout=60,
                max_retries=self.config.max_retries,
            )

        return AzureChatOpenAI(
            model=os.getenv("AZURE_CHAT_OPENAI_MODEL"),
            azure_endpoint=os.getenv("AZURE_CHAT_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_CHAT_OPENAI_KEY"),
            api_version=os.getenv("AZURE_CHAT_OPENAI_VERSION", "2024-08-01-preview"),
            temperature=self.config.temperature,
            max_tokens=self.config.max_final_tokens,
            streaming=self.config.streaming,
            callbacks=callbacks,
            request_timeout=60,
            max_retries=self.config.max_retries,
        )

    def switch_llm(self, new_llm_config: Dict[str, Any]):
        """Switch to a new LLM configuration"""
        with self._lock:
            self.llm = self._initialize_llm(new_llm_config)

    def _get_cache_key(
        self, text: str, content_type: str, custom_prompt: str = None
    ) -> str:
        """Generate cache key including custom prompt if provided"""
        cache_input = f"{text}{content_type}"
        if custom_prompt:
            cache_input += f"{custom_prompt}"
        return hashlib.md5(cache_input.encode()).hexdigest()

    def _count_tokens(self, text: str) -> int:
        return len(self.tokenizer.encode(text))

    def _get_prompt_template(
        self, content_type: ContentType, custom_prompt: str = None
    ) -> str:
        """Get prompt template with support for custom prompts"""
        if custom_prompt:
            # Validate that custom prompt has {text} placeholder
            if "{text}" not in custom_prompt:
                raise ValueError("Custom prompt must contain '{text}' placeholder")
            return custom_prompt

        # Default templates
        templates = {
            ContentType.SUMMARY: "Produce a concise overview of the following text while preserving key information:\n\nText: {text}\n\nOverview:",
            ContentType.OUTLINE: "Create a structured outline from the following text:\n\nText: {text}\n\nOutline:",
            ContentType.TITLE: "Generate a concise, descriptive title for the following text:\n\nText: {text}\n\nTitle:",
            ContentType.BULLET_POINTS: "Extract key points from the following text as bullet points:\n\nText: {text}\n\nKey Points:",
            ContentType.EXECUTIVE_OVERVIEW: "Create an executive overview of the following text:\n\nText: {text}\n\nExecutive Overview:",
        }
        return templates.get(content_type, templates[ContentType.SUMMARY])

    def _chunk_document(
        self, state: ContentGraphState, config: RunnableConfig
    ) -> Dict[str, Any]:
        """Chunk the document if not already done"""
        if state.get("chunks"):
            return {"processing_state": ProcessingState.PROCESSING_CHUNKS.value}

        c_config = config.get("configurable", {}).get("content_config", {})
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=c_config.get("max_chunk_size", 4000),
            chunk_overlap=c_config.get("chunk_overlap", 200),
            length_function=len,
        )
        chunks = splitter.split_documents([Document(page_content=state["document"])])
        initial_tokens = sum(self._count_tokens(c.page_content) for c in chunks)

        return {
            "chunks": chunks,
            "initial_token_count": initial_tokens,
            "processing_state": ProcessingState.PROCESSING_CHUNKS.value,
            "processed_chunks": [],
            "failed_chunks": [],
            "current_chunk_index": 0,
            "rate_limited": False,
        }

    def _process_chunk_with_retry(
        self,
        chunk: Document,
        content_type: ContentType,
        use_cache: bool,
        chunk_index: int,
        custom_prompt: str = None,
        session_id: str = None,
    ) -> Tuple[str, Dict[str, int]]:
        """Process a single chunk with retry logic and rate limit handling"""
        key = self._get_cache_key(chunk.page_content, content_type.value, custom_prompt)
        if use_cache and key in self.cache:
            return self.cache[key], {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
            }

        prompt_template = self._get_prompt_template(content_type, custom_prompt)
        prompt = PromptTemplate.from_template(prompt_template)
        self._test_count += 1

        for attempt in range(self.config.max_retries + 1):
            try:
                with self._lock:
                    response = self.llm.invoke(prompt.format(text=chunk.page_content))

                content = response.content.strip()
                usage = response.response_metadata.get("token_usage", {})
                token_usage = {
                    k: usage.get(k, 0)
                    for k in ("prompt_tokens", "completion_tokens", "total_tokens")
                }

                if use_cache:
                    self.cache[key] = content

                return content, token_usage

            except RateLimitException as e:
                if attempt < self.config.max_retries:
                    if self._llm_switch_callback:
                        new_config = self._llm_switch_callback(session_id)
                        if new_config:
                            self.switch_llm(new_config)
                        else:
                            time.sleep(
                                self.config.retry_delay * (2**attempt)
                            )  # Exponential backoff

                    else:
                        time.sleep(
                            self.config.retry_delay * (2**attempt)
                        )  # Exponential backoff
                else:
                    raise RateLimitException(
                        f"Rate limit exceeded for chunk {chunk_index}", chunk_index
                    )
            except Exception as e:
                return f"Error processing chunk: {str(e)[:100]}... ", {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                }

    def _parallel_process_chunks(
        self, state: ContentGraphState, config: RunnableConfig
    ) -> Dict[str, Any]:
        """Process chunks in parallel with resumable capability"""
        c_config = config.get("configurable", {}).get("content_config", {})
        content_type = ContentType(c_config.get("content_type", "summary"))
        use_cache = c_config.get("use_cache", True)
        custom_prompt = c_config.get("custom_prompt")
        chunks = state.get("chunks", [])
        session_id = state.get("session_id", "")

        # Resume from where we left off
        processed_chunks = state.get("processed_chunks", [])
        failed_chunks = state.get("failed_chunks", [])
        current_outputs = state.get("chunk_outputs", [])

        # Initialize outputs list if empty
        if not current_outputs:
            current_outputs = [""] * len(chunks)

        # Determine which chunks need to be processed
        chunks_to_process = []
        for i, chunk in enumerate(chunks):
            if i not in processed_chunks and i not in failed_chunks:
                chunks_to_process.append((i, chunk))

        if not chunks_to_process:
            return {
                "processing_state": ProcessingState.HIERARCHICAL_PROCESSING.value,
                "chunk_outputs": current_outputs,
            }

        total_usage = state.get(
            "token_usage",
            {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        ).copy()

        try:
            if not c_config.get("parallel_processing") or len(chunks_to_process) <= 1:
                # Sequential processing
                for chunk_index, chunk in chunks_to_process:
                    try:
                        output, usage = self._process_chunk_with_retry(
                            chunk,
                            content_type,
                            use_cache,
                            chunk_index,
                            custom_prompt,
                            session_id,
                        )
                        current_outputs[chunk_index] = output
                        processed_chunks.append(chunk_index)

                        for k in total_usage:
                            total_usage[k] += usage.get(k, 0)

                    except RateLimitException as e:
                        failed_chunks.append(chunk_index)

                        return {
                            "processing_state": ProcessingState.RATE_LIMITED.value,
                            "chunk_outputs": current_outputs,
                            "processed_chunks": processed_chunks,
                            "failed_chunks": failed_chunks,
                            "current_chunk_index": chunk_index,
                            "rate_limited": True,
                            "error_message": e.message,
                            "token_usage": total_usage,
                        }
            else:
                # Parallel processing
                with ThreadPoolExecutor(
                    max_workers=c_config.get("max_workers", 4)
                ) as executor:
                    future_to_index = {
                        executor.submit(
                            self._process_chunk_with_retry,
                            chunk,
                            content_type,
                            use_cache,
                            chunk_index,
                            custom_prompt,
                            session_id,
                        ): chunk_index
                        for chunk_index, chunk in chunks_to_process
                    }

                    for future in as_completed(future_to_index):
                        chunk_index = future_to_index[future]
                        try:
                            output, usage = future.result()
                            current_outputs[chunk_index] = output
                            processed_chunks.append(chunk_index)

                            for k in total_usage:
                                total_usage[k] += usage.get(k, 0)

                        except RateLimitException as e:
                            failed_chunks.append(chunk_index)

                            # Cancel remaining futures
                            for remaining_future in future_to_index:
                                remaining_future.cancel()

                            # Trigger LLM switch callback
                            if self._llm_switch_callback:
                                new_config = self._llm_switch_callback(
                                    state.get("session_id", "")
                                )
                                if new_config:
                                    self.switch_llm(new_config)

                            return {
                                "processing_state": ProcessingState.RATE_LIMITED.value,
                                "chunk_outputs": current_outputs,
                                "processed_chunks": processed_chunks,
                                "failed_chunks": failed_chunks,
                                "current_chunk_index": chunk_index,
                                "rate_limited": True,
                                "error_message": e.message,
                                "token_usage": total_usage,
                            }

        except Exception as e:
            return {
                "processing_state": ProcessingState.FAILED.value,
                "error_message": str(e),
                "token_usage": total_usage,
            }

        gc.collect()
        return {
            "chunk_outputs": current_outputs,
            "processed_chunks": processed_chunks,
            "failed_chunks": failed_chunks,
            "processing_state": ProcessingState.HIERARCHICAL_PROCESSING.value,
            "token_usage": total_usage,
            "rate_limited": False,
        }

    def _hierarchical_process(
        self, state: ContentGraphState, config: RunnableConfig
    ) -> Dict[str, Any]:
        """Hierarchical processing with resumable capability"""
        c_config = config.get("configurable", {}).get("content_config", {})
        content_type = ContentType(c_config.get("content_type", "summary"))
        use_cache = c_config.get("use_cache", True)
        custom_prompt = c_config.get("custom_prompt")

        summaries = state.get("chunk_outputs", []).copy()
        # Remove empty summaries from failed chunks
        summaries = [s for s in summaries if s and not s.startswith("Error")]

        total_usage = state.get(
            "token_usage",
            {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        ).copy()
        current_level = state.get("current_hierarchical_level", 0)

        try:
            while len(summaries) > 10:
                next_level = []
                grouped = [summaries[i : i + 5] for i in range(0, len(summaries), 5)]

                for group_index, group in enumerate(grouped):
                    try:
                        doc = Document(page_content="\n\n".join(group))
                        output, usage = self._process_chunk_with_retry(
                            doc, content_type, use_cache, group_index, custom_prompt
                        )
                        next_level.append(output)

                        for k in total_usage:
                            total_usage[k] += usage.get(k, 0)

                    except RateLimitException as e:
                        if self._llm_switch_callback:
                            new_config = self._llm_switch_callback(
                                state.get("session_id", "")
                            )
                            if new_config:
                                self.switch_llm(new_config)

                        return {
                            "processing_state": ProcessingState.RATE_LIMITED.value,
                            "current_hierarchical_level": current_level,
                            "intermediate_outputs": summaries,
                            "rate_limited": True,
                            "error_message": e.message,
                            "token_usage": total_usage,
                        }

                summaries = next_level
                current_level += 1
                gc.collect()

        except Exception as e:
            return {
                "processing_state": ProcessingState.FAILED.value,
                "error_message": str(e),
                "token_usage": total_usage,
            }

        return {
            "intermediate_outputs": summaries,
            "current_hierarchical_level": current_level,
            "processing_state": ProcessingState.FINAL_GENERATION.value,
            "token_usage": total_usage,
            "rate_limited": False,
        }

    def _generate_final_content(
        self, state: ContentGraphState, config: RunnableConfig
    ) -> Dict[str, Any]:
        """Generate final content with retry capability"""
        c_config = config.get("configurable", {}).get("content_config", {})
        content_type = ContentType(c_config.get("content_type", "summary"))
        use_cache = c_config.get("use_cache", True)
        custom_prompt = c_config.get("custom_prompt")

        combined = "\n\n".join(state.get("intermediate_outputs", []))
        final_doc = Document(page_content=combined)

        total_usage = state.get(
            "token_usage",
            {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        ).copy()

        try:
            final_output, usage = self._process_chunk_with_retry(
                final_doc, content_type, use_cache, -1, custom_prompt
            )

            for k in total_usage:
                total_usage[k] += usage.get(k, 0)

            init_tokens = state.get("initial_token_count", 0)
            final_tokens = self._count_tokens(final_output)

            metadata = {
                "total_chunks": len(state.get("chunks", [])),
                "original_token_count": init_tokens,
                "final_token_count": final_tokens,
                "compression_ratio": (final_tokens / init_tokens if init_tokens else 0),
                "content_type": content_type.value,
                "processed_chunks": len(state.get("processed_chunks", [])),
                "failed_chunks": len(state.get("failed_chunks", [])),
                "custom_prompt_used": custom_prompt is not None,
            }

            return {
                "final_output": final_output,
                "metadata": metadata,
                "token_usage": total_usage,
                "processing_state": ProcessingState.COMPLETED.value,
                "rate_limited": False,
            }

        except RateLimitException as e:
            if self._llm_switch_callback:
                new_config = self._llm_switch_callback(state.get("session_id", ""))
                if new_config:
                    self.switch_llm(new_config)

            return {
                "processing_state": ProcessingState.RATE_LIMITED.value,
                "rate_limited": True,
                "error_message": e.message,
                "token_usage": total_usage,
            }

        except Exception as e:
            return {
                "processing_state": ProcessingState.FAILED.value,
                "error_message": str(e),
                "token_usage": total_usage,
            }

    def _should_retry(self, state: ContentGraphState, config: RunnableConfig) -> str:
        """Determine if we should retry processing after rate limit"""
        if (
            state.get("rate_limited")
            and state.get("processing_state") == ProcessingState.RATE_LIMITED.value
        ):
            # Check which stage we were in and route accordingly
            if state.get("current_chunk_index") is not None:
                return "parallel_process_chunk"
            elif state.get("current_hierarchical_level") is not None:
                return "hierarchical_process_chunks"
            else:
                return "generate_final_content"
        return END

    def _build_graph(self) -> StateGraph:
        """Build the processing graph with retry capabilities"""
        workflow = StateGraph(ContentGraphState)

        # Add nodes
        workflow.add_node("chunk_document", self._chunk_document)
        workflow.add_node("parallel_process_chunk", self._parallel_process_chunks)
        workflow.add_node("hierarchical_process_chunks", self._hierarchical_process)
        workflow.add_node("generate_final_content", self._generate_final_content)

        # Set entry point
        workflow.set_entry_point("chunk_document")

        # Add edges
        workflow.add_edge("chunk_document", "parallel_process_chunk")

        # Add conditional edges for retry logic
        workflow.add_conditional_edges(
            "parallel_process_chunk",
            lambda state: (
                "hierarchical_process_chunks"
                if state.get("processing_state")
                == ProcessingState.HIERARCHICAL_PROCESSING.value
                else END
            ),
            {"hierarchical_process_chunks": "hierarchical_process_chunks", END: END},
        )

        workflow.add_conditional_edges(
            "hierarchical_process_chunks",
            lambda state: (
                "generate_final_content"
                if state.get("processing_state")
                == ProcessingState.FINAL_GENERATION.value
                else END
            ),
            {"generate_final_content": "generate_final_content", END: END},
        )

        workflow.add_edge("generate_final_content", END)

        return workflow.compile(checkpointer=self.checkpointer)

    def run(
        self,
        document: str,
        content_type: ContentType = ContentType.SUMMARY,
        custom_config: Optional[GenerationConfig] = None,
        session_id: str = None,
        custom_prompt: str = None,
    ) -> Dict[str, Any]:
        """Run the content generation with resumable capability and custom prompt support"""
        start = time.time()
        session_id = session_id or f"session_{int(time.time())}"

        # Initial state
        initial_state = {
            "document": document,
            "token_usage": {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
            },
            "processing_state": ProcessingState.CHUNKING.value,
            "session_id": session_id,
            "rate_limited": False,
            "llm_config": {},
        }

        cfg = custom_config or self.config
        cfg.content_type = content_type

        # Convert config to dict and add custom prompt
        config_dict = cfg.to_dict()
        if custom_prompt:
            config_dict["custom_prompt"] = custom_prompt

        run_cfg = RunnableConfig(
            configurable={"content_config": config_dict}, thread_id=session_id
        )

        try:
            final_state = self.graph.invoke(initial_state, config=run_cfg)
            elapsed = time.time() - start

            if final_state.get("metadata"):
                final_state["metadata"]["processing_time"] = elapsed

            return {
                "content": final_state.get("final_output", ""),
                "metadata": final_state.get("metadata", {}),
                "token_usage": final_state.get("token_usage", {}),
                "processing_time": elapsed,
                "success": final_state.get("processing_state")
                == ProcessingState.COMPLETED.value,
                "session_id": session_id,
                "processing_state": final_state.get("processing_state"),
                "rate_limited": final_state.get("rate_limited", False),
                "error": final_state.get("error_message", ""),
            }

        except Exception as e:
            return {
                "content": "",
                "metadata": {},
                "token_usage": {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                },
                "processing_time": time.time() - start,
                "success": False,
                "session_id": session_id,
                "processing_state": ProcessingState.FAILED.value,
                "rate_limited": False,
                "error": str(e),
            }

    def resume(
        self, session_id: str, new_llm_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Resume processing from a rate-limited state"""
        start = time.time()

        # Switch LLM if new config provided
        if new_llm_config:
            self.switch_llm(new_llm_config)

        try:
            # Create a dummy initial state to get the saved state
            dummy_state = {
                "document": "",
                "token_usage": {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                },
                "session_id": session_id,
                "rate_limited": False,
            }

            run_cfg = RunnableConfig(thread_id=session_id)

            # Resume from saved state
            final_state = self.graph.invoke(dummy_state, config=run_cfg)
            elapsed = time.time() - start

            if final_state.get("metadata"):
                final_state["metadata"]["processing_time"] = elapsed

            return {
                "content": final_state.get("final_output", ""),
                "metadata": final_state.get("metadata", {}),
                "token_usage": final_state.get("token_usage", {}),
                "processing_time": elapsed,
                "success": final_state.get("processing_state")
                == ProcessingState.COMPLETED.value,
                "session_id": session_id,
                "processing_state": final_state.get("processing_state"),
                "rate_limited": final_state.get("rate_limited", False),
                "error": final_state.get("error_message", ""),
            }

        except Exception as e:
            return {
                "content": "",
                "metadata": {},
                "token_usage": {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                },
                "processing_time": time.time() - start,
                "success": False,
                "session_id": session_id,
                "processing_state": ProcessingState.FAILED.value,
                "rate_limited": False,
                "error": str(e),
            }

    def get_session_state(self, session_id: str) -> Dict[str, Any]:
        """Get the current state of a session"""
        try:
            config = {"configurable": {"thread_id": session_id}}
            retrieved_state = self.graph.get_state(config)
            return retrieved_state
        except Exception as e:
            return {"session_id": session_id, "exists": False, "error": str(e)}

    def batch_generate(
        self,
        documents: List[str],
        content_type: ContentType = ContentType.SUMMARY,
        custom_prompt: str = None,
    ) -> List[Dict[str, Any]]:
        """Batch generation with individual session tracking and custom prompt support"""
        results = []

        if self.config.parallel_processing:
            with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
                futures = [
                    executor.submit(
                        self.run,
                        doc,
                        content_type,
                        None,
                        f"batch_{i}_{int(time.time())}",
                        custom_prompt,
                    )
                    for i, doc in enumerate(documents)
                ]
                results = [f.result() for f in futures]
        else:
            for i, doc in enumerate(documents):
                result = self.run(
                    doc,
                    content_type,
                    None,
                    f"batch_{i}_{int(time.time())}",
                    custom_prompt,
                )
                results.append(result)

        return results

    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        return {
            "cache_size": len(self.cache),
            "config": self.config.to_dict(),
            "model_name": self.config.model_name,
            "checkpointer_type": type(self.checkpointer).__name__,
        }

    def clear_cache(self):
        """Clear cache and force garbage collection"""
        self.cache.clear()
        gc.collect()

    def clear_session(self, session_id: str):
        """Clear a specific session from checkpointer"""
        # self.checkpointer.put(config={"configurable": {"thread_id": session_id}},
        #    checkpoint=empty_checkpoint(),
        #    metadata={})
        pass


class ContentGenerator:
    """Backward-compatible wrapper for the enhanced ContentEngine"""

    def __init__(
        self,
        config: GenerationConfig = None,
        llm_config: Optional[Dict[str, Any]] = None,
    ):
        self.engine = ContentEngine(config, llm_config)

    def set_llm_switch_callback(self, callback: Callable[[str], Dict[str, Any]]):
        """Set callback function to handle LLM switching from FastAPI"""
        self.engine.set_llm_switch_callback(callback)

    def switch_llm(self, new_llm_config: Dict[str, Any]):
        """Switch to a new LLM configuration"""
        self.engine.switch_llm(new_llm_config)

    def _run(
        self,
        data: Union[str, Document, list[Document]],
        ctype: ContentType,
        custom_prompt: str = None,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """Internal run method with enhanced error handling and custom prompt support"""
        custom = kwargs.get("custom_config")
        session_id = kwargs.get("session_id")
        return_full_result = kwargs.get("return_full_result", False)

        if isinstance(data, list) and all(isinstance(doc, Document) for doc in data):
            text = " ".join(doc.page_content for doc in data)
        elif isinstance(data, Document):
            text = data.page_content
        else:
            text = data

        result = self.engine.run(text, ctype, custom, session_id, custom_prompt)

        if return_full_result:
            return result

        if not result["success"]:
            if result.get("rate_limited"):
                return {
                    "error": "Rate limit exceeded",
                    "session_id": result["session_id"],
                    "can_resume": True,
                    "processing_state": result["processing_state"],
                }
            return f"Error: {result.get('error', 'Unknown error')}"

        return result["content"]

    def get_session_state(self, session_id: str) -> Dict[str, Any]:
        """Get the current state of a session"""
        return self.engine.get_session_state(session_id)

    def create_summary(
        self,
        data: Union[str, Document, list[Document]],
        custom_prompt: str = None,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """Create summary with enhanced error handling"""
        return self._run(data, ContentType.SUMMARY, custom_prompt, **kwargs)

    def create_outline(
        self,
        data: Union[str, Document, list[Document]],
        custom_prompt: str = None,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """Create outline with enhanced error handling"""
        return self._run(data, ContentType.OUTLINE, custom_prompt, **kwargs)

    def create_title(
        self,
        data: Union[str, Document, list[Document]],
        custom_prompt: str = None,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """Create title with enhanced error handling"""
        return self._run(data, ContentType.TITLE, custom_prompt, **kwargs)

    def create_bullet_points(
        self,
        data: Union[str, Document, list[Document]],
        custom_prompt: str = None,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """Create bullet points with enhanced error handling"""
        return self._run(data, ContentType.BULLET_POINTS, custom_prompt, **kwargs)

    def create_executive_overview(
        self,
        data: Union[str, Document, list[Document]],
        custom_prompt: str = None,
        **kwargs,
    ) -> Union[str, Dict[str, Any]]:
        """Create executive overview with enhanced error handling"""
        return self._run(data, ContentType.EXECUTIVE_OVERVIEW, custom_prompt, **kwargs)

    def start_generation(
        self,
        data: Union[str, Document, list[Document]],
        content_type: ContentType,
        session_id: str,
        custom_prompt: str = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Start content generation based on content type and session ID."""

        if content_type not in ContentType:
            return {
                "error": f"Unsupported content type: {content_type}",
                "session_id": session_id,
            }

        return self._run(
            data, content_type, custom_prompt, session_id=session_id, **kwargs
        )

    def resume_generation(
        self, session_id: str, new_llm_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Resume a rate-limited generation"""
        return self.engine.resume(session_id, new_llm_config)

    def clear_cache(self):
        """Clear cache"""
        self.engine.clear_cache()

    def clear_session(self, session_id: str):
        """Clear a specific session"""
        self.engine.clear_session(session_id)

    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        return self.engine.get_performance_stats()
