import asyncio
from typing import List, Optional

import numpy as np
from langchain.prompts import PromptTemplate
from langchain.schema import Document
from langchain_openai import AzureChatOpenAI
from sklearn.cluster import KMeans


class KMeansClustering:
    def fit_cluster(self, docs: List[Document]):
        # Extract vectors from documents
        only_vectors = np.array([doc.metadata.get("vector") for doc in docs])

        closest_indices = []

        if len(only_vectors) >= 2:
            # TODO : Change the hard coded `11` to use silhouette score to find the optimal number of clusters
            num_clusters = min(len(only_vectors), 11)
            kmeans = KMeans(n_clusters=num_clusters, random_state=42).fit(only_vectors)

        for i in range(num_clusters):
            # Calculate distances from all documents to this cluster center
            distances = np.linalg.norm(
                only_vectors - kmeans.cluster_centers_[i], axis=1
            )

            # Find the closest document
            closest_index = np.argmin(distances)
            closest_indices.append(closest_index)

            # print(f"Cluster {i}: Closest document is index {closest_index} (distance: {distances[closest_index]:.4f})")

        selected_indices = sorted(closest_indices)
        selected_docs = [docs[doc] for doc in selected_indices]

        return selected_docs

    async def kmeans_summarize(
        self,
        docs: List[Document],
        llm_instance: AzureChatOpenAI,
        custom_map_prompt: Optional[str] = None,
        custom_reduce_prompt: Optional[str] = None,
        map_batch_size: int = 5,
    ):
        # Map Phase

        # TODO : change the empty string to get the prompt from config files

        map_prompt = (
            custom_map_prompt
            if custom_map_prompt
            else "Summarize the following text:\n\n{text}\n\nSUMMARY:"
        )
        map_prompt_template = PromptTemplate(
            template=map_prompt, input_variables=["text"]
        )

        # Make an empty list to hold summaries
        summary_list = []
        token_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

        # Create async tasks for each batch
        async def summarize_batch(batch_docs):
            # Join all docs in this batch
            batch_text = "\n".join(doc.page_content for doc in batch_docs)

            # Format prompt
            formatted_prompt = map_prompt_template.format(text=batch_text)

            # Call LLM directly
            result = await llm_instance.ainvoke(formatted_prompt)

            output_text = result.content
            usage = result.response_metadata.get("token_usage", {})

            # Update token usage
            token_usage["prompt_tokens"] += usage.get("prompt_tokens", 0)
            token_usage["completion_tokens"] += usage.get("completion_tokens", 0)
            token_usage["total_tokens"] += usage.get("total_tokens", 0)

            return output_text

        tasks = []
        for i in range(0, len(docs), map_batch_size):
            batch_docs = docs[i : i + map_batch_size]
            tasks.append(summarize_batch(batch_docs))

        # Run all map batches concurrently
        batch_summaries = await asyncio.gather(*tasks)
        summary_list.extend(batch_summaries)

        # --- Reduce Phase ---
        combined_summaries = "\n".join(summary_list)

        reduce_prompt_template = PromptTemplate(
            template=custom_reduce_prompt
            if custom_reduce_prompt
            else "Summarize the following text:\n\n{text}\n\nSUMMARY:",
            input_variables=["text"],
        )

        formatted_reduce_prompt = reduce_prompt_template.format(text=combined_summaries)
        reduce_result = await llm_instance.ainvoke(formatted_reduce_prompt)

        final_summary = reduce_result.content
        reduce_usage = reduce_result.response_metadata.get("token_usage", {})

        token_usage["prompt_tokens"] += reduce_usage.get("prompt_tokens", 0)
        token_usage["completion_tokens"] += reduce_usage.get("completion_tokens", 0)
        token_usage["total_tokens"] += reduce_usage.get("total_tokens", 0)

        return final_summary, token_usage

    # --- cluster then summarize ---
    async def cluster_and_summarize(
        self,
        docs: List[Document],
        llm_instance: AzureChatOpenAI,
        custom_map_prompt: Optional[str] = None,
        custom_reduce_prompt: Optional[str] = None,
        map_batch_size: int = 5,
    ):
        """
        1️⃣ Cluster documents
        2️⃣ Summarize selected cluster representatives
        """
        selected_docs = self.fit_cluster(docs)

        if not selected_docs:
            raise ValueError("No documents selected from clustering.")

        final_summary = await self.kmeans_summarize(
            docs=selected_docs,
            llm_instance=llm_instance,
            custom_map_prompt=custom_map_prompt,
            custom_reduce_prompt=custom_reduce_prompt,
            map_batch_size=map_batch_size,
        )

        return final_summary
