import msal


def acquire_app_token(client_id, authority, client_secret, scopes):
    """
    Acquire an Azure AD access token using client credentials flow.
    Raises RuntimeError if token acquisition fails.
    """
    app = msal.ConfidentialClientApplication(
        client_id, authority=authority, client_credential=client_secret
    )

    result = app.acquire_token_for_client(scopes=scopes)
    access_token = result.get("access_token")

    if not access_token:
        raise RuntimeError(
            f"Token acquisition failed: {result.get('error_description', 'Unknown error.')}"
        )

    return access_token
