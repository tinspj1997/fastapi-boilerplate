import time
from functools import lru_cache
from pathlib import Path
from typing import List, Type

from gnie.schema.content_analyzer import (
    DocumentHandler,
    ImageByPage,
    ImageResult,
    TableByPage,
    TableResult,
)


class PDFHandler(DocumentHandler):
    """
    Handler implementation for PDF files.
    """

    @classmethod
    def supported_extensions(cls) -> List[str]:
        """
        Return PDF file extension.

        Returns:
            List[str]: [".pdf"]
        """
        return [".pdf"]

    def _validate_file(self, file_path: Path) -> None:
        """
        Ensure the given file_path points to an existing file.

        Args:
            file_path (Path): Path to check.

        Raises:
            FileNotFoundError: If the path is not a file.
        """
        if not file_path.is_file():
            raise FileNotFoundError(f"Invalid file: {file_path}")

    def find_images(self, file_path: Path, timeout_seconds: float) -> ImageResult:
        """
        Extract all images from a PDF.

        Args:
            file_path (Path): Path to the PDF file.
            timeout_seconds (float): Maximum time allowed for extraction.

        Returns:
            ImageResult: Contains a flag and list of images by page.
        """
        start = time.time()
        self._validate_file(file_path)
        result = ImageResult()

        import fitz  # PyMuPDF

        with fitz.open(str(file_path)) as doc:
            if doc.needs_pass:
                raise PermissionError("PDF is password protected")

            for page_number, page in enumerate(doc, start=1):
                if time.time() - start > timeout_seconds:
                    raise TimeoutError(f"Timeout after {timeout_seconds} seconds")

                images = page.get_images(full=True)
                count = len(images)
                if count:
                    result.has_image = True
                    result.images_by_page.append(
                        ImageByPage(page_number=page_number, number_of_image=count)
                    )

            result.has_image = bool(result.images_by_page)
        return result

    def find_tables(self, file_path: Path, timeout_seconds: float) -> TableResult:
        """
        Extract all tables from a PDF.

        Args:
            file_path (Path): Path to the PDF file.
            timeout_seconds (float): Maximum time allowed for extraction.

        Returns:
            TableResult: Contains a flag and list of tables by page.
        """
        start = time.time()
        self._validate_file(file_path)
        result = TableResult()
        
        table_settings = {
            "vertical_strategy": "lines",
            "horizontal_strategy": "text",
        }
        
        table_settings_2 = {
            "vertical_strategy": "text",
            "horizontal_strategy": "lines",
        }

        import pdfplumber

        with pdfplumber.open(str(file_path)) as pdf:
            for page_number, page in enumerate(pdf.pages, start=1):
                if time.time() - start > timeout_seconds:
                    raise TimeoutError(f"Timeout after {timeout_seconds} seconds")
                
                tables = page.extract_tables() 

                if not tables:
                    tables = page.extract_tables(table_settings)
                    
                if not tables:
                    tables = page.extract_tables(table_settings_2)


                count = len(tables)
                if count:
                    result.has_table = True
                    result.tables_by_page.append(
                        TableByPage(page_number=page_number, number_of_tables=count)
                    )

            result.has_table = bool(result.tables_by_page)
        return result

    def has_image(self, file_path: Path, timeout_seconds: float) -> bool:
        """
        Quickly check if a PDF contains any image.

        Args:
            file_path (Path): Path to the PDF file.
            timeout_seconds (float): Maximum time allowed for the check.

        Returns:
            bool: True if at least one image is found before timeout, False otherwise.
        """
        start = time.time()
        self._validate_file(file_path)

        import fitz  # PyMuPDF

        with fitz.open(str(file_path)) as doc:
            if doc.needs_pass:
                raise PermissionError("PDF is password protected")

            for page in doc:
                if time.time() - start > timeout_seconds:
                    raise TimeoutError(f"Timeout after {timeout_seconds} seconds")

                if page.get_images(full=True):
                    return True

        return False

    def has_table(self, file_path: Path, timeout_seconds: float) -> bool:
        """
        Quickly check if a PDF contains any table.

        Args:
            file_path (Path): Path to the PDF file.
            timeout_seconds (float): Maximum time allowed for the check.

        Returns:
            bool: True if at least one table is found before timeout, False otherwise.
        """
        self._validate_file(file_path)
        table_settings = {
            "vertical_strategy": "lines",
            "horizontal_strategy": "text",
        }
        
        table_settings_2 = {
            "vertical_strategy": "text",
            "horizontal_strategy": "lines",
        }

        import pdfplumber

        with pdfplumber.open(str(file_path)) as pdf:
            return any(
                (page.extract_tables() or page.extract_tables(table_settings) or page.extract_tables(table_settings_2))
                for page in pdf.pages
            )

        return False


class DocumentContentAnalyzer:
    """
    Coordinator that selects the correct handler based on file extension.

    Provides methods to find or check for images and tables in documents.
    """

    def __init__(self, timeout_seconds: float = 60):
        """
        Initialize with a timeout for document scanning operations.

        Args:
            timeout_seconds (float): Time limit for scanning each document.
        """
        self.timeout = timeout_seconds

    @lru_cache(maxsize=None)
    def _get_handler_class(self, extension: str) -> Type[DocumentHandler]:
        """
        Retrieve the handler class for a given file extension.

        Args:
            extension (str): File extension (including the dot), e.g. ".pdf".

        Returns:
            Type[DocumentHandler]: The handler class to use.

        Raises:
            ValueError: If no handler is registered for the extension.
        """
        HandlerClass = DocumentHandler.registry.get(extension)
        if not HandlerClass:
            raise ValueError(
                f"Unsupported format: {extension}. Supported: {sorted(DocumentHandler.registry.keys())}"
            )
        return HandlerClass

    def _get_handler(self, file_path: Path) -> DocumentHandler:
        """
        Instantiate the handler for a given file path based on its extension.

        Args:
            file_path (Path): Path to the document file.

        Returns:
            DocumentHandler: An instance of the appropriate handler.
        """
        ext = file_path.suffix.lower()
        HandlerClass = self._get_handler_class(ext)
        return HandlerClass()

    def find_images(self, document_path: str) -> ImageResult:
        """
        Scan the specified document for all images.

        Args:
            document_path (str): Path to the document file.

        Returns:
            ImageResult: Contains details of images found.
        """
        path = Path(document_path)
        handler = self._get_handler(path)
        return handler.find_images(path, self.timeout)

    def find_tables(self, document_path: str) -> TableResult:
        """
        Scan the specified document for all tables.

        Args:
            document_path (str): Path to the document file.

        Returns:
            TableResult: Contains details of tables found.
        """
        path = Path(document_path)
        handler = self._get_handler(path)
        return handler.find_tables(path, self.timeout)

    def has_image(self, document_path: str) -> bool:
        """
        Check if the specified document has at least one image.

        Args:
            document_path (str): Path to the document file.

        Returns:
            bool: True if an image is present, False otherwise.
        """
        path = Path(document_path)
        handler = self._get_handler(path)
        return handler.has_image(path, self.timeout)

    def has_table(self, document_path: str) -> bool:
        """
        Check if the specified document has at least one table.

        Args:
            document_path (str): Path to the document file.

        Returns:
            bool: True if a table is present, False otherwise.
        """
        path = Path(document_path)
        handler = self._get_handler(path)
        return handler.has_table(path, self.timeout)
