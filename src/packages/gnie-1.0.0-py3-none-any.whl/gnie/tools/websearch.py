from googlesearch import search as google_search
from typing import List, Optional, Literal
from tavily import TavilyClient
from multiprocessing import Pool

search_engine = Literal["google", "tavily"]


def _extract_content(args):
    tavily_client, url = args
    try:
        return tavily_client.extract(url)
    except Exception as e:
        return None


def search(
    query: str,
    num_results: int = 10,
    lang: str = "en",
    api_key: str = None,
    search_engine: Literal = "google",
) -> List[str]:
    """
    Perform a Google search and return results.

    Args:
        query: Search query string
        num_results: Number of results to return (default: 10)
        lang: Language code for results (default: 'en')

    Returns:
        List of result URLs
    """
    if not isinstance(query, str):
        raise TypeError("query must be a string")
    if not isinstance(num_results, int):
        raise TypeError("num_results must be an integer")
    if not isinstance(lang, str):
        raise TypeError("lang must be a string")
    tavily_client = TavilyClient(api_key=api_key)
    try:
        if search_engine == "tavily":
            return tavily_client.search(query)
        else:
            web_links = list(google_search(query, num_results=num_results, lang=lang))
            # Create a process pool and extract content from all URLs
            with Pool() as pool:
                responses = pool.map(
                    _extract_content, [(tavily_client, url) for url in web_links]
                )

            # Filter out None responses from failed extractions
            responses = [r for r in responses if r is not None]
            return responses

    except Exception as e:
        return []
