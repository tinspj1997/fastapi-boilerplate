from elasticsearch.exceptions import (
    ConnectionError,
    ConnectionTimeout,
    NotFoundError,
    RequestError,
    ConflictError,
    AuthenticationException,
    AuthorizationException,
    SerializationError,
    TransportError,
    BulkIndexError,
)

from langchain_elasticsearch.exceptions import (
    ElasticsearchAPIError,
    ElasticsearchError,
    ElasticTransientError,
    ElasticWarning,
    ElasticsearchHttpError,
    ElasticTransientHttpError,
    ElasticsearchWarning,
    ElasticTransientWarning,
)

__all__ = [
    "ConnectionError",
    "ConnectionTimeout",
    "NotFoundError",
    "RequestError",
    "ConflictError",
    "AuthenticationException",
    "AuthorizationException",
    "SerializationError",
    "TransportError",
    "BulkIndexError",
    "ElasticsearchAPIError",
    "ElasticsearchError",
    "ElasticTransientError",
    "ElasticWarning",
    "ElasticsearchWarning",
    "ElasticsearchHttpError",
    "ElasticTransientHttpError",
    "ElasticTransientWarning",
]
