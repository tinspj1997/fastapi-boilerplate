import os
from typing import Optional, Dict, Callable, Any
import json
import base64
import yaml
from dotenv import load_dotenv
from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient
from typing import Literal
import tomllib



FileType = Literal["yaml", "env", "json", "toml"]


def load_yaml_config(path: str, override: bool = False) -> dict:
    """
    Load configuration from a YAML file.

    Args:
        path (str): Path to the YAML configuration file.

    Returns:
        dict: Parsed YAML content as a dictionary.
    """
    with open(path, "r") as f:
        return yaml.safe_load(f)


def load_env_config(path: Optional[str] = None, override: bool = False) -> dict:
    """
    Load environment variables from a .env file.

    Args:
        path (Optional[str]): Path to the .env file. If None, defaults to '.env' in the current directory.

    Returns:
        dict: Dictionary of environment variables loaded (from os.environ).
    """
    (
        load_dotenv(dotenv_path=path, override=override)
        if path
        else load_dotenv(override=override)
    )
    return dict(os.environ)


def load_json_config(path: str, override: bool = False) -> dict:
    """
    Load configuration from a JSON file.
    """
    with open(path, "r") as f:
        return json.load(f)


def load_toml_config(path: str, override: bool = False) -> dict:
    """
    Load configuration from a TOML file.
    """
    with open(path, "rb") as f:
        return tomllib.load(f)


def load_config(
    path: str, file_type: FileType = "yaml", override: bool = False
) -> dict:
    """
    Load configuration based on the file type (yaml or env).

    Args:
        path (Optional[str]): Path to the config file (YAML or .env).
        file_type (str): Type of config file - 'yaml' or 'env'.

    Returns:
        dict: Loaded configuration as a dictionary.

    Raises:
        ValueError: If an unsupported file_type is provided.
    """
    if not isinstance(path, str):
        raise ValueError("Path must be a string")
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file not found: {path}")

    CONFIG_LOADERS: Dict[str, Callable[[Optional[str]], dict]] = {
        "yaml": load_yaml_config,
        "env": load_env_config,
        "json": load_json_config,
        "toml": load_toml_config,
    }
    if file_type not in CONFIG_LOADERS:
        raise ValueError(f"Unsupported config file type: {file_type}")

    loader_func = CONFIG_LOADERS[file_type]
    return loader_func(path, override=override)


def load_azure_key_vault(
    tenant_id: str, client_id: str, client_secret: str, vault_url: str
):
    credential = ClientSecretCredential(tenant_id, client_id, client_secret)
    client = SecretClient(vault_url=vault_url, credential=credential)
    secrets = client.list_properties_of_secrets()
    keys = {}
    for secret_properties in secrets:
        secret = client.get_secret(secret_properties.name)
        key_name = secret.name.replace("-", "_")  # Replace hyphens with underscores
        keys[key_name] = secret.value
    return keys


def set_environment_variables(key_value_pair: dict):
    """
    Sets environment variables from a dictionary.
    Keys are converted to uppercase.
    """
    for key, value in key_value_pair.items():
        os.environ[key.upper()] = str(value)


def _stringify_value(value: Any) -> str:
    """
    Convert any value to a string suitable for Azure Key Vault.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, bool):
        return str(value).lower()
    if value is None:
        return ""
    return str(value)


def set_azure_key_vault_secrets(
    key_value_pairs: Dict[str, Any],
    tenant_id: str,
    client_id: str,
    client_secret: str,
    vault_url: str,
) -> bool:
    """
    Set multiple key-value pairs in Azure Key Vault, always overwriting existing secrets.

    Args:
        key_value_pairs: Dictionary of key-value pairs to store.
        tenant_id: Azure tenant ID.
        client_id: Azure client ID.
        client_secret: Azure client secret.
        vault_url: Azure Key Vault URL.

    Returns:
        True if all secrets are set successfully.

    Raises:
        ValueError: If required parameters are missing.
        Any exception raised by Azure SDK if setting a secret fails.
    """
    if not key_value_pairs:
        raise ValueError("key_value_pairs cannot be empty")

    if not all([tenant_id, client_id, client_secret, vault_url]):
        raise ValueError("All Azure credentials and vault URL must be provided")

    credential = ClientSecretCredential(tenant_id, client_id, client_secret)
    client = SecretClient(vault_url=vault_url, credential=credential)

    for key, value in key_value_pairs.items():
        string_value = _stringify_value(value)
        key = key.replace("_", "-")  # Replace underscores with hyphens in key
        client.set_secret(key, string_value)  # Raise if fails

    return True


def delete_azure_key_vault_secrets(
    keys: list[str], tenant_id: str, client_id: str, client_secret: str, vault_url: str
) -> bool:
    """
    Delete multiple secrets from Azure Key Vault.

    Args:
        keys: List of secret names to delete.
        tenant_id: Azure tenant ID.
        client_id: Azure client ID.
        client_secret: Azure client secret.
        vault_url: Azure Key Vault URL.

    Returns:
        True if all secrets are deleted successfully.

    Raises:
        ValueError: If required parameters are missing.
        Any exception raised by Azure SDK if deleting a secret fails.
    """
    if not keys:
        raise ValueError("keys cannot be empty")

    if not all([tenant_id, client_id, client_secret, vault_url]):
        raise ValueError("All Azure credentials and vault URL must be provided")

    credential = ClientSecretCredential(tenant_id, client_id, client_secret)
    client = SecretClient(vault_url=vault_url, credential=credential)
    for key in keys:
        key = key.replace("_", "-")
        client.begin_delete_secret(key).wait()  # Raise if fails
        client.purge_deleted_secret(key)
    return True


#-----------
#OCI Vault
#-----------


def load_oci_vault(
    vault_id: str,
    vault_endpoint: str,
    compartment_id: str,
    config_file_path: Optional[str] = None,
    profile: str = "DEFAULT"
):
    """
    Load all secrets from an OCI Vault.

    Args:
        vault_id: OCID of the vault.
        vault_endpoint: Vault management endpoint URL.
        compartment_id: OCID of the compartment containing the vault.
        config_file_path: Path to OCI config file. If None, uses default ~/.oci/config.
        profile: Profile name in the config file.

    Returns:
        dict: Dictionary of secret names and values.
    """
    from oci.config import from_file
    from oci.vault import VaultsClient
    from oci.secrets import SecretsClient
    config = from_file(config_file_path, profile) if config_file_path else from_file(profile_name=profile)
    
    vault_client = VaultsClient(config, service_endpoint=vault_endpoint)
    secrets_client = SecretsClient(config)
    
    # List all active secrets in the vault
    list_secrets_response = vault_client.list_secrets(
        compartment_id=compartment_id,
        vault_id=vault_id,
        lifecycle_state="ACTIVE"
    )
    
    keys = {}
    for secret_properties in list_secrets_response.data:
        try:
            # Get the secret bundle (actual secret value)
            secret_bundle = secrets_client.get_secret_bundle(secret_properties.id)
            
            if hasattr(secret_bundle.data.secret_bundle_content, 'content'):
                content = secret_bundle.data.secret_bundle_content.content
                # Base64 decode the content
                decoded_content = base64.b64decode(content).decode('utf-8')
                
                # Replace hyphens with underscores for consistency
                key_name = secret_properties.secret_name.replace("-", "_")
                keys[key_name] = decoded_content
        except Exception:
            # Skip secrets that can't be retrieved
            continue
    
    return keys


def _stringify_value(value: Any) -> str:
    """
    Convert any value to a string suitable for OCI Vault.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, bool):
        return str(value).lower()
    if value is None:
        return ""
    return str(value)


def set_oci_vault_secrets(
    key_value_pairs: Dict[str, Any],
    vault_id: str,
    vault_endpoint: str,
    compartment_id: str,
    kms_key_id: str,
    config_file_path: Optional[str] = None,
    profile: str = "DEFAULT"
) -> bool:
    """
    Set multiple key-value pairs in OCI Vault, always overwriting existing secrets.

    Args:
        key_value_pairs: Dictionary of key-value pairs to store.
        vault_id: OCID of the vault.
        vault_endpoint: Vault management endpoint URL.
        compartment_id: OCID of the compartment containing the vault.
        kms_key_id: OCID of the KMS key for encryption.
        config_file_path: Path to OCI config file. If None, uses default ~/.oci/config.
        profile: Profile name in the config file.

    Returns:
        True if all secrets are set successfully.

    Raises:
        ValueError: If required parameters are missing.
        Any exception raised by OCI SDK if setting a secret fails.
    """
    from oci.config import from_file
    from oci.vault import VaultsClient, models

    if not key_value_pairs:
        raise ValueError("key_value_pairs cannot be empty")

    if not all([vault_id, vault_endpoint, compartment_id, kms_key_id]):
        raise ValueError("All OCI credentials and vault details must be provided")

    config = from_file(config_file_path, profile) if config_file_path else from_file(profile_name=profile)
    vault_client = VaultsClient(config, service_endpoint=vault_endpoint)
    
    # Get existing secrets to determine create vs update
    list_secrets_response = vault_client.list_secrets(
        compartment_id=compartment_id,
        vault_id=vault_id
    )
    
    existing_secrets = {secret.secret_name: secret.id for secret in list_secrets_response.data}

    for key, value in key_value_pairs.items():
        string_value = _stringify_value(value)
        key = key.replace("_", "-")  # Replace underscores with hyphens in key
        
        # Base64 encode the secret content
        encoded_content = base64.b64encode(string_value.encode('utf-8')).decode('utf-8')
        
        secret_content = models.Base64SecretContentDetails(
            content_type=models.Base64SecretContentDetails.CONTENT_TYPE_BASE64,
            content=encoded_content
        )
        
        if key in existing_secrets:
            # Update existing secret
            update_secret_details = models.UpdateSecretDetails(
                secret_content=secret_content
            )
            vault_client.update_secret(existing_secrets[key], update_secret_details)
        else:
            # Create new secret
            create_secret_details = models.CreateSecretDetails(
                compartment_id=compartment_id,
                vault_id=vault_id,
                key_id=kms_key_id,
                secret_name=key,
                secret_content=secret_content
            )
            vault_client.create_secret(create_secret_details)  # Raise if fails

    return True


def delete_oci_vault_secrets(
    keys: list[str],
    vault_id: str,
    vault_endpoint: str,
    compartment_id: str,
    config_file_path: Optional[str] = None,
    profile: str = "DEFAULT"
) -> bool:
    """
    Delete multiple secrets from OCI Vault.

    Args:
        keys: List of secret names to delete.
        vault_id: OCID of the vault.
        vault_endpoint: Vault management endpoint URL.
        compartment_id: OCID of the compartment containing the vault.
        config_file_path: Path to OCI config file. If None, uses default ~/.oci/config.
        profile: Profile name in the config file.

    Returns:
        True if all secrets are deleted successfully.

    Raises:
        ValueError: If required parameters are missing.
        Any exception raised by OCI SDK if deleting a secret fails.
    """
    from oci.config import from_file
    from oci.vault import VaultsClient, models
 
    if not keys:
        raise ValueError("keys cannot be empty")

    if not all([vault_id, vault_endpoint, compartment_id]):
        raise ValueError("All OCI credentials and vault details must be provided")

    config = from_file(config_file_path, profile) if config_file_path else from_file(profile_name=profile)
    vault_client = VaultsClient(config, service_endpoint=vault_endpoint)
    
    # Get existing secrets to find their OCIDs
    list_secrets_response = vault_client.list_secrets(
        compartment_id=compartment_id,
        vault_id=vault_id
    )
    
    existing_secrets = {secret.secret_name: secret.id for secret in list_secrets_response.data}
    
    for key in keys:
        key = key.replace("_", "-")  # Replace underscores with hyphens
        if key in existing_secrets:
            # Schedule secret for deletion (OCI soft delete)
            schedule_deletion_details = models.ScheduleSecretDeletionDetails()
            vault_client.schedule_secret_deletion(existing_secrets[key], schedule_deletion_details)  # Raise if fails
        
    return True


#-----------