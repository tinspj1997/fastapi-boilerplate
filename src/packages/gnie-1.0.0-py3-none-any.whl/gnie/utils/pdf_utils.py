import fitz  # PyMuPDF
import json
import re
from datetime import datetime
from dataclasses import dataclass
from typing import Any, Tuple, List, Optional
import keyword
import tokenize
import io

@dataclass
class PDFConfig:
    """Configuration class for PDF generation"""
    # Page settings
    page_size: str = "A4"  # A4, A3, A2, Letter, Legal, etc.
    orientation: str = "portrait"  # portrait or landscape
    
    # Margins
    margin: int = 50  # in points
    content_indent: int = 20  # indentation for message content
    
    # Colors
    primary_color: Tuple[float, float, float] = (0.52, 0.29, 0.89)  # #8449e4
    text_dark: Tuple[float, float, float] = (0.22, 0.25, 0.32)  # #374151
    text_medium: Tuple[float, float, float] = (0.42, 0.45, 0.50)  # #6b7280
    code_bg_color: Tuple[float, float, float] = (0.95, 0.95, 0.95)  # Light gray for code blocks
    code_text_color: Tuple[float, float, float] = (0.2, 0.2, 0.2)  # Dark gray for code text
    table_border_color: Tuple[float, float, float] = (0.8, 0.8, 0.8)  # Light gray for table borders
    
    # Fonts
    title_font: str = "helvetica-bold"
    text_font: str = "helvetica"
    small_font: str = "helvetica"
    code_font: str = "courier"  # Monospace font for code
    
    # Font sizes
    title_size: int = 18
    header_size: int = 11
    text_size: int = 10
    small_size: int = 9
    code_size: int = 9
    
    # Spacing
    line_spacing: int = 15
    message_spacing: int = 25
    section_spacing: int = 40
    code_padding: int = 8  # Padding around code blocks
    table_cell_padding: int = 6  # Padding in table cells
    
    # Icons
    user_icon: str = "👤"
    assistant_icon: str = "🤖"
    
    # Export info
    show_export_info: bool = True
    export_date_format: str = "%Y-%m-%d %H:%M:%S"
    timestamp_format: str = "%I:%M:%S %p"
    
    # Page break threshold
    page_break_threshold: int = 150  # points from bottom to trigger new page

class ChatToPDF:
    """Class to convert chat data to PDF with configurable settings"""
    
    def __init__(self, config: Optional[PDFConfig] = None):
        self.config = config or PDFConfig()
        self.doc = None
        self.page = None
        self.y_pos = 0
    
    def _get_page_size(self) -> Tuple[float, float]:
        """Get page dimensions based on config"""
        page_sizes = {
            "A0": (2384, 3370),
            "A1": (1684, 2384),
            "A2": (1191, 1684),
            "A3": (842, 1191),
            "A4": (595, 842),
            "A5": (420, 595),
            "Letter": (612, 792),
            "Legal": (612, 1008)
        }
        
        width, height = page_sizes.get(self.config.page_size.upper(), (595, 842))
        
        if self.config.orientation == "landscape":
            width, height = height, width
            
        return width, height
    
    def _create_page(self):
        """Create a new page with configured size"""
        width, height = self._get_page_size()
        rect = fitz.Rect(0, 0, width, height)
        self.page = self.doc.new_page(width=width, height=height)
        self.y_pos = 70  # Reset Y position for new page
    
    def _draw_header(self, chat_data: dict):
        """Draw the header section"""
        title = chat_data.get("conversation_title", "Chat Export")
        
        # Title
        self.page.insert_text(
            (self.config.margin, self.y_pos), 
            title, 
            fontsize=self.config.title_size, 
            color=self.config.text_dark, 
            fontname=self.config.title_font
        )
        self.y_pos += 30
        
        # Border line
        page_width = self.page.rect.width
        line_start = (self.config.margin, self.y_pos)
        line_end = (page_width - self.config.margin, self.y_pos)
        self.page.draw_line(line_start, line_end, color=self.config.primary_color, width=2)
        self.y_pos += 20
        
        # Export info
        if self.config.show_export_info:
            message_count = len(chat_data.get("messages", []))
            export_info = (
                f"Exported on {datetime.now().strftime(self.config.export_date_format)} • "
                f"{message_count} messages"
            )
            self.page.insert_text(
                (self.config.margin, self.y_pos), 
                export_info, 
                fontsize=self.config.small_size, 
                color=self.config.text_medium, 
                fontname=self.config.small_font
            )
            self.y_pos += self.config.section_spacing
    
    def _wrap_text(self, text: str, max_width: float, font: str, font_size: int) -> List[str]:
        """Wrap text to fit within max width"""
        words = text.split()
        lines = []
        current_line = ""
        
        for word in words:
            test_line = current_line + (" " if current_line else "") + word
            text_width = fitz.get_text_length(test_line, fontname=font, fontsize=font_size)
            
            if text_width <= max_width:
                current_line = test_line
            else:
                if current_line:
                    lines.append(current_line)
                current_line = word
        
        if current_line:
            lines.append(current_line)
        
        return lines
    
    def _get_token_color(self, ttype: int, string: str) -> Tuple[float, float, float]:
        """Get color based on token type"""
        if ttype == tokenize.COMMENT:
            return (0.5, 0.5, 0.5)  # gray
        if ttype == tokenize.STRING:
            return (0, 0.5, 0)  # green
        if ttype == tokenize.NUMBER:
            return (1, 0, 0)  # red

        if ttype == tokenize.NAME and string in keyword.kwlist:
            return (0, 0, 1)  # blue
        return self.config.code_text_color
    
    def _draw_code_block(self, code: str, content_x: float, max_width: float, language: str = 'text'):
        """Draw a code block with background and monospace font, with syntax highlighting if applicable"""
        code_lines = code.split('\n')
        
        # Prepare for highlighting if python or html
        lang = language.lower()
        mono_width = fitz.get_text_length(" ", fontname=self.config.code_font, fontsize=self.config.code_size)
        
        line_tokens = {}
        if lang == 'python':
            try:
                tokens = list(tokenize.tokenize(io.BytesIO(code.encode('utf-8')).readline))
                for tok in tokens:
                    if tok.type in (tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE, tokenize.NL):
                        continue
                    (srow, scol), (erow, ecol) = tok.start, tok.end
                    if srow not in line_tokens:
                        line_tokens[srow] = []
                    line_tokens[srow].append((scol, tok.string, tok.type))
            except:
                lang = 'text'
        elif lang in ['html', 'css', 'javascript', 'js', 'jsx', 'typescript', 'ts']:
            # Will handle in the loop
            pass
        else:
            lang = 'text'
        
        # Process code block in chunks that fit on each page
        i = 0
        while i < len(code_lines):
            # Calculate how many lines fit on current page
            available_height = self.page.rect.height - self.config.page_break_threshold - self.y_pos
            lines_that_fit = max(1, int((available_height - 2 * self.config.code_padding) / self.config.line_spacing))
            
            # Get the chunk of lines for this page
            chunk_lines = code_lines[i:i + lines_that_fit]
            chunk_height = len(chunk_lines) * self.config.line_spacing + 2 * self.config.code_padding
            
            # Draw code block background for this chunk
            code_rect = fitz.Rect(
                content_x - self.config.code_padding,
                self.y_pos - self.config.code_padding,
                content_x + max_width + self.config.code_padding,
                self.y_pos + chunk_height - self.config.code_padding
            )
            self.page.draw_rect(code_rect, color=self.config.code_bg_color, fill=self.config.code_bg_color)
            
            # Draw code lines for this chunk
            for line_idx, line in enumerate(chunk_lines):
                actual_line_num = i + line_idx
                
                if lang == 'text':
                    if line.strip():
                        self.page.insert_text(
                            (content_x, self.y_pos), 
                            line, 
                            fontsize=self.config.code_size, 
                            color=self.config.code_text_color, 
                            fontname=self.config.code_font
                        )
                elif lang == 'python':
                    if actual_line_num + 1 in line_tokens:
                        line_tok = sorted(line_tokens[actual_line_num + 1], key=lambda x: x[0])
                        for scol, string, ttype in line_tok:
                            color = self._get_token_color(ttype, string)
                            x_pos = content_x + scol * mono_width
                            self.page.insert_text(
                                (x_pos, self.y_pos), 
                                string, 
                                fontsize=self.config.code_size, 
                                color=color, 
                                fontname=self.config.code_font
                            )
                    else:
                        if line.strip():
                            self.page.insert_text(
                                (content_x, self.y_pos), 
                                line, 
                                fontsize=self.config.code_size, 
                                color=self.config.code_text_color, 
                                fontname=self.config.code_font
                            )
                elif lang in ['html', 'css', 'javascript', 'js', 'jsx', 'typescript', 'ts']:
                    current_x = content_x
                    patterns = self._get_syntax_patterns(lang)
                    positions = []
                    for pat, col in patterns:
                        for m in re.finditer(pat, line):
                            positions.append((m.start(), m.end(), col))
                    
                    if positions:
                        positions.sort(key=lambda x: x[0])
                        last_end = 0
                        for start, end, color in positions:
                            if start > last_end:
                                substring = line[last_end:start]
                                self.page.insert_text(
                                    (current_x, self.y_pos),
                                    substring,
                                    fontsize=self.config.code_size,
                                    color=self.config.code_text_color,
                                    fontname=self.config.code_font
                                )
                                sub_width = fitz.get_text_length(substring, fontname=self.config.code_font, fontsize=self.config.code_size)
                                current_x += sub_width
                            substring = line[start:end]
                            self.page.insert_text(
                                (current_x, self.y_pos),
                                substring,
                                fontsize=self.config.code_size,
                                color=color,
                                fontname=self.config.code_font
                            )
                            sub_width = fitz.get_text_length(substring, fontname=self.config.code_font, fontsize=self.config.code_size)
                            current_x += sub_width
                            last_end = end
                        if last_end < len(line):
                            substring = line[last_end:]
                            self.page.insert_text(
                                (current_x, self.y_pos),
                                substring,
                                fontsize=self.config.code_size,
                                color=self.config.code_text_color,
                                fontname=self.config.code_font
                            )
                    else:
                        if line.strip():
                            self.page.insert_text(
                                (content_x, self.y_pos), 
                                line, 
                                fontsize=self.config.code_size, 
                                color=self.config.code_text_color, 
                                fontname=self.config.code_font
                            )
                
                self.y_pos += self.config.line_spacing
            
            # Move to next chunk
            i += lines_that_fit
            
            # If there are more lines, create a new page
            if i < len(code_lines):
                self._create_page()
        
        # Add extra spacing after code block
        self.y_pos += self.config.code_padding

    def _get_syntax_patterns(self, lang: str):
        """Get syntax highlighting patterns for different languages"""
        if lang == 'html':
            return [
                (r'<!--.*?-->', (0.5, 0.5, 0.5)),  # comments gray
                (r'</?[\w\-:]+', (0, 0, 1)),  # tags blue
                (r'[\w\-:]+ ?=', (0.5, 0, 0.5)),  # attributes purple
                (r'="[^"]*"', (0, 0.5, 0)),  # values green
                (r"='[^']*'", (0, 0.5, 0)),  # values green
            ]
        elif lang == 'css':
            return [
                (r'/\*.*?\*/', (0.5, 0.5, 0.5)),  # comments
                (r'[.#][\w-]+', (0.8, 0.4, 0)),  # selectors orange
                (r'[\w-]+(?=\s*:)', (0, 0, 1)),  # properties blue
                (r':\s*[^;]+', (0, 0.5, 0)),  # values green
            ]
        elif lang in ['javascript', 'js', 'jsx', 'typescript', 'ts']:
            return [
                (r'//.*$', (0.5, 0.5, 0.5)),  # comments
                (r'/\*.*?\*/', (0.5, 0.5, 0.5)),  # multi-line comments
                (r'\b(function|const|let|var|if|else|return|for|while|class|import|export|from|async|await)\b', (0, 0, 1)),  # keywords
                (r'"[^"]*"', (0, 0.5, 0)),  # strings
                (r"'[^']*'", (0, 0.5, 0)),  # strings
                (r'`[^`]*`', (0, 0.5, 0)),  # template strings
            ]
        else:
            return []
    
    
    def _draw_table(self, table_text: str, content_x: float, max_width: float):
        """Draw a markdown table"""
        lines = table_text.strip().split('\n')
        if len(lines) < 2:
            return
        
        # Parse table rows
        rows = []
        for line in lines:
            if line.strip() and '|' in line:
                # Remove leading/trailing pipes and split
                cells = [cell.strip() for cell in line.strip('|').split('|')]
                rows.append(cells)
        
        if len(rows) < 2:
            return
        
        # Calculate column widths
        col_widths = [0] * len(rows[0])
        for row in rows:
            for i, cell in enumerate(row):
                if i < len(col_widths):
                    cell_width = fitz.get_text_length(cell, fontname=self.config.text_font, fontsize=self.config.text_size)
                    col_widths[i] = max(col_widths[i], cell_width)
        
        # Add padding to column widths
        col_widths = [width + 2 * self.config.table_cell_padding for width in col_widths]
        
        # Calculate total table width
        table_width = sum(col_widths)
        scale_factor = 1.0
        if table_width > max_width:
            scale_factor = max_width / table_width
            col_widths = [width * scale_factor for width in col_widths]
            table_width = max_width
        
        # Check if we need a new page for the table
        table_height = len(rows) * (self.config.line_spacing + 2 * self.config.table_cell_padding)
        if self.y_pos + table_height > self.page.rect.height - self.config.page_break_threshold:
            self._create_page()
        
        # Draw table
        current_y = self.y_pos
        for row_idx, row in enumerate(rows):
            current_x = content_x
            for col_idx, cell in enumerate(row):
                if col_idx < len(col_widths):
                    # Draw cell background for header row
                    if row_idx == 0:
                        cell_rect = fitz.Rect(
                            current_x, current_y,
                            current_x + col_widths[col_idx], current_y + self.config.line_spacing + 2 * self.config.table_cell_padding
                        )
                        self.page.draw_rect(cell_rect, color=self.config.code_bg_color, fill=self.config.code_bg_color)
                    
                    # Draw cell text
                    self.page.insert_text(
                        (current_x + self.config.table_cell_padding, current_y + self.config.table_cell_padding + self.config.text_size - 3), 
                        cell, 
                        fontsize=self.config.text_size, 
                        color=self.config.text_dark, 
                        fontname=self.config.text_font if row_idx > 0 else self.config.title_font
                    )
                    
                    # Draw cell borders
                    cell_rect = fitz.Rect(
                        current_x, current_y,
                        current_x + col_widths[col_idx], current_y + self.config.line_spacing + 2 * self.config.table_cell_padding
                    )
                    self.page.draw_rect(cell_rect, color=self.config.table_border_color)
                    
                    current_x += col_widths[col_idx]
            
            current_y += self.config.line_spacing + 2 * self.config.table_cell_padding
        
        self.y_pos = current_y + self.config.message_spacing
    
    def _process_markdown_content(self, content: str, content_x: float, max_width: float):
        """Process markdown content with code blocks and tables"""
        # Split content into segments (text, code blocks, tables)
        segments = []
        current_segment = []
        in_code_block = False
        in_table = False
        language = 'text'
        
        lines = content.split('\n')
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Check for code blocks
            if line.strip().startswith('```'):
                if in_code_block:
                    # End of code block
                    segments.append(('code', '\n'.join(current_segment), language))
                    current_segment = []
                    in_code_block = False
                else:
                    # Start of code block
                    if current_segment:
                        segments.append(('text', current_segment))
                        current_segment = []
                    language = line.strip()[3:].strip()
                    if not language:
                        language = 'text'
                    in_code_block = True
                i += 1
                continue
            
            # Check for tables
            if '|' in line and not in_code_block:
                if not in_table:
                    if current_segment:
                        segments.append(('text', current_segment))
                        current_segment = []
                    in_table = True
                stripped = line.replace('|', '').replace('-', '').replace(':', '').replace(' ', '')
                if stripped:  # Only append if there's actual content
                    current_segment.append(line)                
            elif in_table and not line.strip().startswith('|'):
                # End of table
                segments.append(('table', '\n'.join(current_segment)))
                current_segment = [line] if line.strip() else []
                in_table = False
            else:
                if in_code_block:
                    current_segment.append(line)
                elif in_table:
                    current_segment.append(line)
                else:
                    # Regular text - preserve line structure
                    current_segment.append(line)
            
            i += 1
        
        # Add remaining content
        if current_segment:
            if in_code_block:
                segments.append(('code', '\n'.join(current_segment), language))
            elif in_table:
                segments.append(('table', '\n'.join(current_segment)))
            else:
                segments.append(('text', current_segment))
        
        # Process each segment
        for segment in segments:
            if segment[0] == 'text':
                # Process text while preserving markdown structure
                text_lines = segment[1] if isinstance(segment[1], list) else segment[1].split('\n')
                
                for line in text_lines:
                    line = line.rstrip()
                    
                    # Handle empty lines (paragraph breaks)
                    if not line.strip():
                        self.y_pos += self.config.line_spacing * 0.5
                        # Check for page break after empty line spacing
                        if self.y_pos > self.page.rect.height - self.config.page_break_threshold:
                            self._create_page()
                        continue
                    
                    # Handle headers
                    if line.startswith('#'):
                        header_level = len(line) - len(line.lstrip('#'))
                        header_text = line.lstrip('#').strip()
                        
                        # Add spacing before header
                        if header_level == 1:
                            self.y_pos += self.config.line_spacing * 1.1
                            fontsize = self.config.text_size + 4
                            fontname = self.config.text_font + '-Bold'
                        elif header_level == 2:
                            self.y_pos += self.config.line_spacing * 1.0
                            fontsize = self.config.text_size + 2
                            fontname = self.config.text_font + '-Bold'
                        else:
                            self.y_pos += self.config.line_spacing
                            fontsize = self.config.text_size + 1
                            fontname = self.config.text_font + '-Bold'
                        
                        # Check if header fits on current page
                        if self.y_pos + fontsize > self.page.rect.height - self.config.page_break_threshold:
                            self._create_page()
                        
                        self.page.insert_text(
                            (content_x, self.y_pos),
                            header_text,
                            fontsize=fontsize,
                            color=self.config.text_dark,
                            fontname=fontname
                        )
                        self.y_pos += fontsize + self.config.line_spacing * 0.5
                        
                        # Check for page break after header
                        if self.y_pos > self.page.rect.height - self.config.page_break_threshold:
                            self._create_page()
                        continue
                    
                    # Handle regular text with inline formatting
                    # Process bold text
                    processed_line = line
                    bold_pattern = r'\*\*(.+?)\*\*'
                    inline_code_pattern = r'`(.+?)`'
                    
                    # For now, just strip the markers (you can enhance this to use actual bold fonts)
                    processed_line = processed_line.replace('**', '')
                    processed_line = processed_line.replace('`', '')
                    
                    # Wrap and render text
                    wrapped_lines = self._wrap_text(processed_line, max_width, self.config.text_font, self.config.text_size)
                    for wrapped_line in wrapped_lines:
                        # Check if we need a new page before rendering this line
                        if self.y_pos + self.config.line_spacing > self.page.rect.height - self.config.page_break_threshold:
                            self._create_page()
                        
                        if wrapped_line.strip():
                            self.page.insert_text(
                                (content_x, self.y_pos),
                                wrapped_line,
                                fontsize=self.config.text_size,
                                color=self.config.text_dark,
                                fontname=self.config.text_font
                            )
                        self.y_pos += self.config.line_spacing
            
            elif segment[0] == 'code':
                # Process code block
                self._draw_code_block(segment[1], content_x, max_width, segment[2])
            
            elif segment[0] == 'table':
                # Process table
                self._draw_table(segment[1], content_x, max_width)
                
    def _process_message(self, message: dict):
        """Process and draw a single message"""
        # Check if we need a new page
        if self.y_pos > self.page.rect.height - self.config.page_break_threshold:
            self._create_page()
        
        role = message.get("role", "")
        name = message.get("name", "Unknown")
        content = message.get("content", "")
        timestamp = message.get("timestamp", "")
        
        # Format timestamp
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            time_str = dt.strftime(self.config.timestamp_format)
        except:
            time_str = timestamp
        
        # Message header with icon
        icon = self.config.user_icon if role == "user" else self.config.assistant_icon
        header_text = f"{icon} {name}"
        
        # Draw header
        self.page.insert_text(
            (self.config.margin, self.y_pos), 
            header_text, 
            fontsize=self.config.header_size, 
            color=self.config.text_dark, 
            fontname=self.config.title_font
        )
        
        # Calculate header width for timestamp placement
        header_width = fitz.get_text_length(
            header_text, 
            fontname=self.config.title_font, 
            fontsize=self.config.header_size
        )
        
        # Draw timestamp
        timestamp_x = self.config.margin + header_width + 20
        self.page.insert_text(
            (timestamp_x, self.y_pos), 
            time_str, 
            fontsize=self.config.small_size, 
            color=self.config.text_medium, 
            fontname=self.config.small_font
        )
        self.y_pos += 20
        
        # Process content
        content_x = self.config.margin + self.config.content_indent
        page_width = self.page.rect.width
        max_width = page_width - 2 * self.config.margin - self.config.content_indent
        
        # Process markdown content (code blocks, tables, etc.)
        self._process_markdown_content(content, content_x, max_width)
        
        self.y_pos += self.config.message_spacing
    
    def markdown_to_pdf(self, chat_data: dict, output_filename: str = "chat_export.pdf"):
        """Main method to convert chat data to PDF"""
        # Create document
        self.doc = fitz.open()
        self._create_page()
        
        # Draw header
        self._draw_header(chat_data)
        
        # Process messages
        messages = chat_data.get("messages", [])
        for message in messages:
            self._process_message(message)
        print("All messages processed.")
        # Save PDF
        self.doc.save(output_filename)
        self.doc.close()
        print(f"PDF saved as: {output_filename}")

    
    def load_from_file(self, file_path: str) -> Any:
        """
        Load chat data from JSON file

        Args:
            file_path (str): Path to the JSON file
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                return data
        except FileNotFoundError:
            return False
        except json.JSONDecodeError as e:
            return False
        except Exception as e:
            return False


# Example usage with different configurations
if __name__ == "__main__":
    # Sample data
    sample_data = {
        "conversation_title": "AI Chat Export Sample Extended",
        "messages": [
            {
                "role": "user",
                "name": "Afraim Joseph",
                "timestamp": "2025-09-12T08:00:00Z",
                "content": "Hello, could you explain what quantum computing is in simple terms?",
                "content_format": "markdown",
                "attachments": []
            },
            {
                "role": "assistant", 
                "name": "Gnie AI",
                "timestamp": "2025-09-12T08:01:00Z",
                "content": "Sure! Quantum computing uses **quantum bits** or `qubits`, which can represent both 0 and 1 at the same time. This allows certain computations to be performed much faster than classical computers.",
                "content_format": "markdown",
                "attachments": []
            }
        ]
    }
    
    # A2 Landscape configuration
    default_config = PDFConfig(
        page_size="A3",
        orientation="landscape"
    )
    
    default_converter = ChatToPDF(default_config)
    sample_data = default_converter.load_from_file("../large_chat_sample.json") or sample_data

    default_converter.markdown_to_pdf(sample_data, "a3_landscape_chat_export.pdf")