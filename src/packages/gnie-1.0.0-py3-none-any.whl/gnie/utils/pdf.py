import fitz
import os
from typing import Union
import hashlib


def is_pdf_protected(file_input: Union[str, bytes]) -> bool:
    """Check if a PDF file is password protected.

    Args:
        file_input: Either a file path (str) or PDF content as bytes

    Returns:
        bool: True if password protected, False otherwise

    Raises:
        FileNotFoundError: If file path doesn't exist (when input is str)
        RuntimeError: For other file access issues
    """
    try:
        if isinstance(file_input, str):
            if not os.path.exists(file_input):
                raise FileNotFoundError(f"File not found: {file_input}")
            doc = fitz.open(file_input)
        else:
            doc = fitz.open(stream=file_input, filetype="pdf")

        if doc.needs_pass:
            return True
        return False
    except Exception as e:
        raise RuntimeError(f"Error checking PDF protection: {str(e)}")


def calculate_checksum(file_or_bytes, algo="sha256"):
    """
    Calculate checksum of either a file or bytes.
    Args:
        file_or_bytes: Either a file path (str) or bytes object
        algo: Hash algorithm (default: "sha256")
    Returns:
        Hex digest of the hash
    """
    hash_func = getattr(hashlib, algo)()

    if isinstance(file_or_bytes, (str, os.PathLike)):
        # Handle file path case
        with open(file_or_bytes, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_func.update(chunk)
    elif isinstance(file_or_bytes, (bytes, bytearray)):
        # Handle bytes case
        hash_func.update(file_or_bytes)
    else:
        raise TypeError("Input must be file path (str) or bytes")

    return hash_func.hexdigest()
