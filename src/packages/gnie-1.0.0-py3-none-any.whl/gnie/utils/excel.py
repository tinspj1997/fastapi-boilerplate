import pandas as pd
from typing import List


def split_by_empty_rows(df: pd.DataFrame) -> List[pd.DataFrame]:
    """
    Splits a DataFrame into a list of smaller DataFrames, using completely empty (NaN-only) rows as separators.

    This function is useful when working with Excel sheets or structured data where multiple logical tables
    are present in the same DataFrame, separated by empty rows.

    Args:
        df (pd.DataFrame): The input DataFrame potentially containing multiple tables separated by empty rows.

    Returns:
        List[pd.DataFrame]: A list of DataFrames, each representing a contiguous block of non-empty rows.

    Example:
        >>> df = pd.read_excel("tables.xlsx")
        >>> tables = split_by_empty_rows(df)

    """
    tables = []
    current_table = []

    for idx, row in df.iterrows():
        if row.isnull().all():
            if current_table:
                # Convert collected rows into a DataFrame and reset index
                tables.append(pd.DataFrame(current_table).reset_index(drop=True))
                current_table = []
        else:
            current_table.append(row)

    if current_table:
        tables.append(pd.DataFrame(current_table).reset_index(drop=True))

    return tables


# def split_by_empty_columns(table: pd.DataFrame) -> List[pd.DataFrame]:
#     """
#     Splits a DataFrame into a list of smaller DataFrames, using completely empty (NaN-only) columns as separators.

#     This function is useful when dealing with tabular data where multiple logical tables are present side by side
#     in the same DataFrame, separated by columns with no data (NaN-only columns).

#     Args:
#         table (pd.DataFrame): The input DataFrame potentially containing multiple tables separated by empty columns.

#     Returns:
#         List[pd.DataFrame]: A list of DataFrames, each representing a contiguous block of non-empty columns.

#     Example:
#         >>> df = pd.read_excel("data.xlsx")
#         >>> tables = split_by_empty_columns(df)

#     """
#     tables = []
#     current_cols = []

#     # Iterate over each column in the DataFrame
#     for col_idx in table.columns:
#         if table[col_idx].isnull().all():
#             # If an empty column is found, save the current block of non-empty columns as a new table
#             if current_cols:
#                 tables.append(
#                     table[current_cols].dropna(how="all").reset_index(drop=True)
#                 )
#                 current_cols = []  # Reset the current columns list
#         else:
#             current_cols.append(col_idx)

#     # Append the final block of non-empty columns if any exist
#     if current_cols:
#         tables.append(table[current_cols].dropna(how="all").reset_index(drop=True))

#     return tables

def split_by_empty_columns(table: pd.DataFrame) -> List[pd.DataFrame]:
    """
    Splits a DataFrame into a list of smaller DataFrames, using completely empty (NaN-only) columns
    that have no meaningful header as separators.
    """
    tables = []
    current_cols = []

    for col in table.columns:
        is_empty_col = table[col].isnull().all()
        has_valid_header = not (pd.isna(col) or str(col).strip().lower().startswith("unnamed"))

        if is_empty_col and not has_valid_header:
            if current_cols:
                tables.append(table[current_cols].dropna(how="all").reset_index(drop=True))
                current_cols = []
        else:
            current_cols.append(col)

    if current_cols:
        tables.append(table[current_cols].dropna(how="all").reset_index(drop=True))

    return tables

