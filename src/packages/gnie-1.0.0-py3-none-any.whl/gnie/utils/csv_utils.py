from pandas import read_csv
import io

def has_content(file_or_bytes):
    try:
        if isinstance(file_or_bytes, bytes):
            file_or_bytes = io.BytesIO(file_or_bytes)
        
        # Try reading with UTF-8 first, then fallback to latin-1 if needed
        try:
            df = read_csv(file_or_bytes, header=None, encoding='utf-8')
        except UnicodeDecodeError:
            file_or_bytes.seek(0)  # Reset file pointer
            df = read_csv(file_or_bytes, header=None, encoding='latin-1')
            
        # If there are no columns and no data, return False
        if df.empty and len(df.columns) == 0:
            return False
        # If there is at least one column (even if no data), return True
        if len(df.columns) > 0:
            return True
        # If there are values anywhere in the dataframe, return True
        if df.notna().any().any():
            return True
        return False
    except Exception as e:
        print(e)
        return False
