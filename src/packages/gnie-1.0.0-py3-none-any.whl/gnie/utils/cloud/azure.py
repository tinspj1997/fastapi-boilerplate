from azure.keyvault.secrets import SecretClient


async def get_vault_keys():
    from azure.identity import DefaultAzureCredential

    # credential = ManagedIdentityCredential(client_id="9a823889-5b47-42a9-9ffd-4005043c1c1")
    # client = SecretClient("https://gniestudio.vault.azure.net/", credential)

    credential = DefaultAzureCredential()

    secret_client = SecretClient(
        vault_url="https://gniestudio.vault.azure.net/", credential=credential
    )
    secret_properties = secret_client.list_properties_of_secrets()
    for secret_property in secret_properties:
        # the list doesn't include values or versions of the secrets
        print(secret_property.name)

    """
    from azure.identity import ClientSecretCredential
from azure.keyvault.secrets import SecretClient

# Replace with your values
tenant_id = "<YourTenantID>"
client_id = "<YourAppID>"  # This is your App ID
client_secret = "<YourClientSecret>"
vault_url = "https://<YourVaultName>.vault.azure.net"

# Authenticate using Client Secret
credential = ClientSecretCredential(tenant_id, client_id, client_secret)
client = SecretClient(vault_url=vault_url, credential=credential)

# Fetch all secrets
properties = client.list_properties_of_secrets()
for secret_property in properties:
    secret = client.get_secret(secret_property.name)
    print(f"Secret Name: {secret.name}, Value: {secret.value}")

    """
