from pptx import Presentation
from pptx.util import Inches, Pt
import markdown
from bs4 import BeautifulSoup

MAX_CHARS = 800  # adjust for text fitting


def flush_buffer_to_slide(prs, layout, buffer, title=None, keep_title=False, max_chars=800, default_font_size=18):
    """Flush buffered text into a slide."""
    if not buffer:
        return
    text = "\n".join(buffer).strip()
    if not text:
        return

    slide = prs.slides.add_slide(layout)
    if title and keep_title:
        slide.shapes.title.text = title
    else:
        slide.shapes.title.text = ""
    text_frame = slide.placeholders[1].text_frame
    text_frame.clear()
    p = text_frame.add_paragraph()
    p.text = text
    p.font.size = Pt(default_font_size)
    buffer.clear()


def split_text_into_chunks(text, max_chars=800):
    """Split a long string into multiple chunks if too big."""
    words = text.split()
    chunks, chunk, count = [], [], 0
    for w in words:
        if count + len(w) + 1 > max_chars:
            chunks.append(" ".join(chunk))
            chunk = [w]
            count = len(w)
        else:
            chunk.append(w)
            count += len(w) + 1
    if chunk:
        chunks.append(" ".join(chunk))
    return chunks


def add_table_slide(prs, layout_blank, element, max_rows=12, table_left=0.5, table_top=1.5, table_width=9, table_height=5.5):
    """Add markdown table, split across slides with headers repeated."""
    rows = element.find_all("tr")
    header = rows[0]
    data_rows = rows[1:]
    cols = len(header.find_all(["td", "th"]))

    for i in range(0, len(data_rows), max_rows):
        chunk = data_rows[i:i + max_rows]
        slide = prs.slides.add_slide(layout_blank)
        left, top, width, height = Inches(table_left), Inches(table_top), Inches(table_width), Inches(table_height)
        table = slide.shapes.add_table(len(chunk) + 1, cols, left, top, width, height).table

        # Header row
        for c, cell in enumerate(header.find_all(["td", "th"])):
            table.cell(0, c).text = cell.text.strip()

        # Data rows
        for r, row in enumerate(chunk, start=1):
            cells = row.find_all(["td", "th"])
            for c, cell in enumerate(cells):
                table.cell(r, c).text = cell.text.strip()


def markdown_to_pptx(md_text, output_file="output_fixed.pptx", template_path=None, max_chars=800, default_font_size=18, code_font_size=16, code_font_name="Courier New", table_max_rows=12, table_left=0.5, table_top=1.5, table_width=9, table_height=5.5, code_max_chars=600, bytes_response=False):
    html = markdown.markdown(md_text, extensions=["tables", "fenced_code"])
    soup = BeautifulSoup(html, "html.parser")

    prs = Presentation(template_path) if template_path else Presentation()
    layout_text = prs.slide_layouts[1]
    layout_blank = prs.slide_layouts[5]

    buffer = []
    current_title = None
    title_used = False  # track if title already used for this section

    for element in soup.children:
        if element.name in ["h1", "h2", "h3"]:
            # Flush old buffer before switching heading
            flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
            current_title = element.text
            title_used = False  # reset for new heading

        elif element.name == "p":
            # Check for nested ul/li within p tags
            if element.find("ul") or element.find("li"):
                for sub_element in element.children:
                    if sub_element.name == "ul":
                        for li in sub_element.find_all("li"):
                            line = "• " + li.text.strip()
                            if sum(len(line) for line in buffer) + len(line) > max_chars:
                                flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
                                title_used = True
                            buffer.append(line)
                    elif sub_element.name == "li":
                        line = "• " + sub_element.text.strip()
                        if sum(len(line) for line in buffer) + len(line) > max_chars:
                            flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
                            title_used = True
                        buffer.append(line)
                    else:  # Handle plain text within p tag
                        chunks = split_text_into_chunks(sub_element.text, max_chars=max_chars)
                        for chunk in chunks:
                            if sum(len(line) for line in buffer) + len(chunk) > max_chars:
                                flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
                                title_used = True
                            buffer.append(chunk)
            else: # No nested lists, process as regular paragraph
                chunks = split_text_into_chunks(element.text, max_chars=max_chars)
                for chunk in chunks:
                    if sum(len(line) for line in buffer) + len(chunk) > max_chars:
                        flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
                        title_used = True
                    buffer.append(chunk)

        elif element.name == "ul":
            for li in element.find_all("li"):
                line = "• " + li.text.strip()
                if sum(len(line) for line in buffer) + len(line) > max_chars:
                    flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
                    title_used = True
                buffer.append(line)

        elif element.name == "pre":
            flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
            title_used = True
            code = element.get_text("\n")
            for chunk in split_text_into_chunks(code, max_chars=code_max_chars):
                slide = prs.slides.add_slide(layout_text)
                slide.shapes.title.text = ""  # never repeat heading for code
                text_frame = slide.placeholders[1].text_frame
                text_frame.clear()
                p = text_frame.add_paragraph()
                p.text = chunk
                p.font.size = Pt(code_font_size)
                p.font.name = code_font_name

        elif element.name == "table":
            flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)
            title_used = False
            add_table_slide(prs, layout_blank, element, max_rows=table_max_rows, table_left=table_left, table_top=table_top, table_width=table_width, table_height=table_height)

    # Flush leftovers
    flush_buffer_to_slide(prs, layout_text, buffer, current_title, keep_title=not title_used, max_chars=max_chars, default_font_size=default_font_size)

    if bytes_response:
        # Save to BytesIO buffer and return bytes
        from io import BytesIO
        buffer = BytesIO()
        prs.save(buffer)
        return buffer.getvalue()
    else:
        prs.save(output_file)
        # print(f"✅ PPTX saved as {output_file}")
        return output_file

