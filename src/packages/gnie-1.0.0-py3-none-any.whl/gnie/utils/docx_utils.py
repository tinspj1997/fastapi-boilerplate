import json
import re
from datetime import datetime
from dataclasses import dataclass
from typing import Any, Tuple, List, Optional
import keyword
import tokenize
import io

from docx import Document
from docx.shared import Inches, RGBColor, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_PARAGRAPH_ALIGNMENT
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.shared import OxmlElement, qn
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml
from docx.enum.style import WD_STYLE_TYPE

@dataclass
class DOCXConfig:
    """Configuration class for DOCX generation"""
    # Page settings
    page_size: str = "A4"  # A4, A3, A2, Letter, Legal, etc.
    orientation: str = "portrait"  # portrait or landscape
    
    # Margins (in inches)
    margin_top: float = 0.7
    margin_bottom: float = 0.7
    margin_left: float = 0.7
    margin_right: float = 0.7
    content_indent: float = 0.28  # indentation for message content
    
    # Colors (RGB tuples 0-255)
    primary_color: Tuple[int, int, int] = (132, 73, 228)  # #8449e4
    text_dark: Tuple[int, int, int] = (55, 65, 81)  # #374151
    text_medium: Tuple[int, int, int] = (107, 114, 128)  # #6b7280
    code_bg_color: Tuple[int, int, int] = (243, 243, 243)  # Light gray for code blocks
    code_text_color: Tuple[int, int, int] = (51, 51, 51)  # Dark gray for code text
    table_border_color: Tuple[int, int, int] = (204, 204, 204)  # Light gray for table borders
    table_header_bg: Tuple[int, int, int] = (240, 240, 240)  # Table header background
    
    # Syntax highlighting colors
    comment_color: Tuple[int, int, int] = (128, 128, 128)  # Gray
    string_color: Tuple[int, int, int] = (0, 128, 0)  # Green
    number_color: Tuple[int, int, int] = (255, 0, 0)  # Red
    keyword_color: Tuple[int, int, int] = (0, 0, 255)  # Blue
    
    # Fonts
    title_font: str = "Arial"
    text_font: str = "Calibri"
    small_font: str = "Calibri"
    code_font: str = "Consolas"  # Monospace font for code
    
    # Font sizes (in points)
    title_size: int = 18
    header_size: int = 16
    text_size: int = 12
    small_size: int = 9
    code_size: int = 9
    
    # Spacing
    line_spacing: float = 1.15
    message_spacing_before: int = 12
    message_spacing_after: int = 6
    section_spacing: int = 24
    code_block_spacing_before: int = 6
    code_block_spacing_after: int = 6
    table_spacing_before: int = 6
    table_spacing_after: int = 12
    
    # Icons
    user_icon: str = "👤"
    assistant_icon: str = "🤖"
    
    # Export info
    show_export_info: bool = True
    export_date_format: str = "%Y-%m-%d %H:%M:%S"
    timestamp_format: str = "%I:%M:%S %p"
    
    # Advanced formatting
    enable_syntax_highlighting: bool = True
    enable_table_formatting: bool = True
    enable_code_block_borders: bool = True
    enable_page_numbers: bool = True

class ChatToDOCX:
    """Class to convert chat data to DOCX with configurable settings"""
    
    def __init__(self, config: Optional[DOCXConfig] = None):
        self.config = config or DOCXConfig()
        self.doc = None
        self.styles = None
    
    def _get_page_dimensions(self) -> Tuple[float, float]:
        """Get page dimensions based on config"""
        page_sizes = {
            "A0": (33.1, 46.8),
            "A1": (23.4, 33.1),
            "A2": (16.5, 23.4),
            "A3": (11.7, 16.5),
            "A4": (8.27, 11.69),
            "A5": (5.83, 8.27),
            "LETTER": (8.5, 11.0),
            "LEGAL": (8.5, 14.0)
        }
        
        width, height = page_sizes.get(self.config.page_size.upper(), (8.27, 11.69))
        
        if self.config.orientation == "landscape":
            width, height = height, width
            
        return width, height
    
    def _setup_document(self):
        """Setup document with page settings and styles"""
        self.doc = Document()
        self.styles = self.doc.styles
        
        # Set page settings
        section = self.doc.sections[0]
        width, height = self._get_page_dimensions()
        
        section.page_width = Inches(width)
        section.page_height = Inches(height)
        section.top_margin = Inches(self.config.margin_top)
        section.bottom_margin = Inches(self.config.margin_bottom)
        section.left_margin = Inches(self.config.margin_left)
        section.right_margin = Inches(self.config.margin_right)
        
        # Add page numbers if enabled
        if self.config.enable_page_numbers:
            self._add_page_numbers(section)
        
        # Create custom styles
        self._create_styles()
    
    def _add_page_numbers(self, section):
        """Add page numbers to the document"""
        footer = section.footer
        footer_para = footer.paragraphs[0]
        footer_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        
        # Add page number field
        run = footer_para.add_run()
        fldChar1 = OxmlElement('w:fldChar')
        fldChar1.set(qn('w:fldCharType'), 'begin')
        run._r.append(fldChar1)
        
        instrText = OxmlElement('w:instrText')
        instrText.text = "PAGE"
        run._r.append(instrText)
        
        fldChar2 = OxmlElement('w:fldChar')
        fldChar2.set(qn('w:fldCharType'), 'end')
        run._r.append(fldChar2)
        
        run.font.size = Pt(self.config.small_size)
        run.font.color.rgb = RGBColor(*self.config.text_medium)
    
    def _create_styles(self):
        """Create comprehensive custom styles"""
        
        # Title style
        if 'ChatTitle' not in [s.name for s in self.styles]:
            title_style = self.styles.add_style('ChatTitle', WD_STYLE_TYPE.PARAGRAPH)
            title_font = title_style.font
            title_font.name = self.config.title_font
            title_font.size = Pt(self.config.title_size)
            title_font.color.rgb = RGBColor(*self.config.text_dark)
            title_font.bold = True
            title_style.paragraph_format.space_after = Pt(self.config.section_spacing)
            title_style.paragraph_format.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
        
        # Message header style
        if 'MessageHeader' not in [s.name for s in self.styles]:
            header_style = self.styles.add_style('MessageHeader', WD_STYLE_TYPE.PARAGRAPH)
            header_font = header_style.font
            header_font.name = self.config.text_font
            header_font.size = Pt(self.config.header_size)
            header_font.color.rgb = RGBColor(*self.config.text_dark)
            header_font.bold = True
            header_style.paragraph_format.space_before = Pt(self.config.message_spacing_before)
            header_style.paragraph_format.space_after = Pt(self.config.message_spacing_after)
        
        # Message content style
        if 'MessageContent' not in [s.name for s in self.styles]:
            content_style = self.styles.add_style('MessageContent', WD_STYLE_TYPE.PARAGRAPH)
            content_font = content_style.font
            content_font.name = self.config.text_font
            content_font.size = Pt(self.config.text_size)
            content_font.color.rgb = RGBColor(*self.config.text_dark)
            content_style.paragraph_format.left_indent = Inches(self.config.content_indent)
            content_style.paragraph_format.line_spacing = self.config.line_spacing
            content_style.paragraph_format.space_after = Pt(3)
        
        # Code block style
        if 'CodeBlock' not in [s.name for s in self.styles]:
            code_style = self.styles.add_style('CodeBlock', WD_STYLE_TYPE.PARAGRAPH)
            code_font = code_style.font
            code_font.name = self.config.code_font
            code_font.size = Pt(self.config.code_size)
            code_font.color.rgb = RGBColor(*self.config.code_text_color)
            code_style.paragraph_format.left_indent = Inches(self.config.content_indent + 0.2)
            code_style.paragraph_format.space_before = Pt(self.config.code_block_spacing_before)
            code_style.paragraph_format.space_after = Pt(self.config.code_block_spacing_after)
        
        # Small text style
        if 'SmallText' not in [s.name for s in self.styles]:
            small_style = self.styles.add_style('SmallText', WD_STYLE_TYPE.PARAGRAPH)
            small_font = small_style.font
            small_font.name = self.config.small_font
            small_font.size = Pt(self.config.small_size)
            small_font.color.rgb = RGBColor(*self.config.text_medium)
        
        # Export info style
        if 'ExportInfo' not in [s.name for s in self.styles]:
            export_style = self.styles.add_style('ExportInfo', WD_STYLE_TYPE.PARAGRAPH)
            export_font = export_style.font
            export_font.name = self.config.small_font
            export_font.size = Pt(self.config.small_size)
            export_font.color.rgb = RGBColor(*self.config.text_medium)
            export_style.paragraph_format.space_after = Pt(self.config.section_spacing)
    
    def _add_header(self, chat_data: dict):
        """Add comprehensive header section to document"""
        title = chat_data.get("conversation_title", "Chat Export")
        
        # Add title
        title_para = self.doc.add_paragraph(title, style='ChatTitle')
        
        # Add decorative horizontal line
        self._add_horizontal_line()
        
        # Add export info
        if self.config.show_export_info:
            message_count = len(chat_data.get("messages", []))
            export_info = (
                f"Exported on {datetime.now().strftime(self.config.export_date_format)} • "
                f"{message_count} messages"
            )
            info_para = self.doc.add_paragraph(export_info, style='ExportInfo')
    
    def _add_horizontal_line(self):
        """Add a styled horizontal line to the document"""
        para = self.doc.add_paragraph()
        
        # Add border bottom to paragraph
        pPr = para._element.get_or_add_pPr()
        pBdr = OxmlElement('w:pBdr')
        
        bottom_border = OxmlElement('w:bottom')
        bottom_border.set(qn('w:val'), 'single')
        bottom_border.set(qn('w:sz'), '12')  # Border size
        bottom_border.set(qn('w:space'), '1')
        bottom_border.set(qn('w:color'), f"{self.config.primary_color[0]:02x}{self.config.primary_color[1]:02x}{self.config.primary_color[2]:02x}")
        
        pBdr.append(bottom_border)
        pPr.append(pBdr)
        
        para.paragraph_format.space_after = Pt(12)
    
    def _get_token_color(self, ttype: int, string: str) -> Tuple[int, int, int]:
        """Get color based on token type for syntax highlighting"""
        if not self.config.enable_syntax_highlighting:
            return self.config.code_text_color
            
        if ttype == tokenize.COMMENT:
            return self.config.comment_color
        elif ttype == tokenize.STRING:
            return self.config.string_color
        elif ttype == tokenize.NUMBER:
            return self.config.number_color
        elif ttype == tokenize.NAME and string in keyword.kwlist:
            return self.config.keyword_color
        else:
            return self.config.code_text_color
    
    def _add_code_block_with_highlighting(self, code: str, language: str = 'text'):
        """Add a code block with syntax highlighting and background"""
        code_lines = code.strip().split('\n')
        
        # Add container paragraph for spacing
        container_para = self.doc.add_paragraph()
        container_para.paragraph_format.space_before = Pt(self.config.code_block_spacing_before)
        container_para.paragraph_format.space_after = Pt(self.config.code_block_spacing_after)
        
        lang = language.lower()
        
        # Process each line
        for i, line in enumerate(code_lines):
            para = self.doc.add_paragraph(style='CodeBlock')
            
            # Add background shading
            self._add_paragraph_shading(para, self.config.code_bg_color)
            
            # Add border if enabled
            if self.config.enable_code_block_borders:
                self._add_paragraph_border(para, self.config.table_border_color)
            
            if not line.strip():
                # Empty line
                para.add_run(" ")
                continue
            
            # Apply syntax highlighting based on language
            if lang == 'python' and self.config.enable_syntax_highlighting:
                self._add_python_syntax_highlighting(para, line, i + 1, code)
            elif lang == 'html' and self.config.enable_syntax_highlighting:
                self._add_html_syntax_highlighting(para, line)
            else:
                # Regular text
                run = para.add_run(line)
                run.font.name = self.config.code_font
                run.font.size = Pt(self.config.code_size)
                run.font.color.rgb = RGBColor(*self.config.code_text_color)
    
    def _add_python_syntax_highlighting(self, para, line: str, line_num: int, full_code: str):
        """Add Python syntax highlighting to a paragraph"""
        try:
            # Tokenize the full code to get proper context
            tokens = list(tokenize.tokenize(io.BytesIO(full_code.encode('utf-8')).readline))
            line_tokens = []
            
            for tok in tokens:
                if tok.type in (tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE, tokenize.NL):
                    continue
                (srow, scol), (erow, ecol) = tok.start, tok.end
                if srow == line_num:
                    line_tokens.append((scol, tok.string, tok.type))
            
            line_tokens.sort(key=lambda x: x[0])
            
            last_col = 0
            for scol, string, ttype in line_tokens:
                # Add any text before this token
                if scol > last_col:
                    text_before = line[last_col:scol]
                    if text_before:
                        run = para.add_run(text_before)
                        run.font.name = self.config.code_font
                        run.font.size = Pt(self.config.code_size)
                        run.font.color.rgb = RGBColor(*self.config.code_text_color)
                
                # Add the token with appropriate color
                color = self._get_token_color(ttype, string)
                run = para.add_run(string)
                run.font.name = self.config.code_font
                run.font.size = Pt(self.config.code_size)
                run.font.color.rgb = RGBColor(*color)
                
                last_col = scol + len(string)
            
            # Add any remaining text
            if last_col < len(line):
                remaining_text = line[last_col:]
                if remaining_text:
                    run = para.add_run(remaining_text)
                    run.font.name = self.config.code_font
                    run.font.size = Pt(self.config.code_size)
                    run.font.color.rgb = RGBColor(*self.config.code_text_color)
                    
        except Exception:
            # Fallback to regular formatting
            run = para.add_run(line)
            run.font.name = self.config.code_font
            run.font.size = Pt(self.config.code_size)
            run.font.color.rgb = RGBColor(*self.config.code_text_color)
    
    def _add_html_syntax_highlighting(self, para, line: str):
        """Add HTML syntax highlighting to a paragraph"""
        patterns = [
            (r'</?[\w\-]+[^>]*>', self.config.keyword_color),  # HTML tags
            (r'[\w\-]+=', (128, 0, 128)),  # Attributes (purple)
            (r'"[^"]*"', self.config.string_color),  # Quoted values
            (r"'[^']*'", self.config.string_color),  # Single quoted values
            (r'<!--.*?-->', self.config.comment_color),  # Comments
        ]
        
        processed_chars = [False] * len(line)
        colored_segments = []
        
        for pattern, color in patterns:
            for match in re.finditer(pattern, line):
                start, end = match.span()
                if not any(processed_chars[start:end]):
                    colored_segments.append((start, end, color, match.group()))
                    for i in range(start, end):
                        processed_chars[i] = True
        
        colored_segments.sort(key=lambda x: x[0])
        
        last_pos = 0
        for start, end, color, text in colored_segments:
            # Add text before this segment
            if start > last_pos:
                before_text = line[last_pos:start]
                run = para.add_run(before_text)
                run.font.name = self.config.code_font
                run.font.size = Pt(self.config.code_size)
                run.font.color.rgb = RGBColor(*self.config.code_text_color)
            
            # Add colored segment
            run = para.add_run(text)
            run.font.name = self.config.code_font
            run.font.size = Pt(self.config.code_size)
            run.font.color.rgb = RGBColor(*color)
            
            last_pos = end
        
        # Add remaining text
        if last_pos < len(line):
            remaining_text = line[last_pos:]
            run = para.add_run(remaining_text)
            run.font.name = self.config.code_font
            run.font.size = Pt(self.config.code_size)
            run.font.color.rgb = RGBColor(*self.config.code_text_color)
    
    def _add_paragraph_shading(self, paragraph, color: Tuple[int, int, int]):
        """Add background shading to a paragraph"""
        pPr = paragraph._element.get_or_add_pPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'), 'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'), f"{color[0]:02x}{color[1]:02x}{color[2]:02x}")
        pPr.append(shd)
    
    def _add_paragraph_border(self, paragraph, color: Tuple[int, int, int]):
        """Add border to a paragraph"""
        pPr = paragraph._element.get_or_add_pPr()
        pBdr = OxmlElement('w:pBdr')
        
        for side in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{side}')
            border.set(qn('w:val'), 'single')
            border.set(qn('w:sz'), '2')
            border.set(qn('w:space'), '0')
            border.set(qn('w:color'), f"{color[0]:02x}{color[1]:02x}{color[2]:02x}")
            pBdr.append(border)
        
        pPr.append(pBdr)
    
    def _add_enhanced_table(self, table_text: str):
        """Add a well-formatted markdown table"""
        lines = table_text.strip().split('\n')
        if len(lines) < 2:
            return
        
        # Parse table rows
        rows = []
        for line in lines:
            if line.strip() and '|' in line and not re.match(r'^\s*\|[\s\-\:]*\|\s*$', line):
                cells = [cell.strip() for cell in line.strip('|').split('|')]
                rows.append(cells)
        
        if len(rows) < 1:
            return
        
        # Create table
        table = self.doc.add_table(rows=len(rows), cols=len(rows[0]))
        table.alignment = WD_TABLE_ALIGNMENT.LEFT
        
        # Set table style and formatting
        if self.config.enable_table_formatting:
            table.style = 'Table Grid'
        
        # Populate and format table
        for row_idx, row_data in enumerate(rows):
            table_row = table.rows[row_idx]
            table_row.height = Pt(25)  # Set row height
            
            for col_idx, cell_data in enumerate(row_data):
                if col_idx < len(table_row.cells):
                    cell = table_row.cells[col_idx]
                    
                    # Set cell text
                    cell.text = cell_data
                    
                    # Format cell content
                    for paragraph in cell.paragraphs:
                        paragraph.alignment = WD_PARAGRAPH_ALIGNMENT.LEFT
                        for run in paragraph.runs:
                            run.font.name = self.config.text_font
                            run.font.size = Pt(self.config.text_size)
                            run.font.color.rgb = RGBColor(*self.config.text_dark)
                    
                    # Style header row
                    if row_idx == 0:
                        for paragraph in cell.paragraphs:
                            for run in paragraph.runs:
                                run.font.bold = True
                        
                        # Add background to header
                        if self.config.enable_table_formatting:
                            shading_elm = parse_xml(r'<w:shd {} w:fill="{}"/>'.format(
                                nsdecls('w'), 
                                f"{self.config.table_header_bg[0]:02x}{self.config.table_header_bg[1]:02x}{self.config.table_header_bg[2]:02x}"
                            ))
                            cell._tc.get_or_add_tcPr().append(shading_elm)
                    
                    # Set cell vertical alignment
                    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        
        # Add spacing after table
        para = self.doc.add_paragraph()
        para.paragraph_format.space_after = Pt(self.config.table_spacing_after)
    
    def _process_markdown_content(self, content: str):
        """Process comprehensive markdown content"""
        # Split content into segments
        segments = []
        current_segment = []
        in_code_block = False
        in_table = False
        language = 'text'
        
        lines = content.split('\n')
        i = 0
        while i < len(lines):
            line = lines[i]
            
            # Check for code blocks
            if line.strip().startswith('```'):
                if in_code_block:
                    # End of code block
                    segments.append(('code', '\n'.join(current_segment), language))
                    current_segment = []
                    in_code_block = False
                else:
                    # Start of code block
                    if current_segment:
                        segments.append(('text', current_segment))
                        current_segment = []
                    language = line.strip()[3:].strip() or 'text'
                    in_code_block = True
                i += 1
                continue
            
            # Check for tables
            if '|' in line and not in_code_block:
                if not in_table:
                    if current_segment:
                        segments.append(('text', current_segment))
                        current_segment = []
                    in_table = True
                stripped = line.replace('|', '').replace('-', '').replace(':', '').replace(' ', '')
                if stripped:  # Only append if there's actual content
                    current_segment.append(line)     
            elif in_table and not line.strip().startswith('|') and line.strip():
                # End of table
                segments.append(('table', '\n'.join(current_segment)))
                current_segment = [line] if line.strip() else []
                in_table = False
            else:
                if in_code_block:
                    current_segment.append(line)
                elif in_table:
                    current_segment.append(line)
                else:
                    current_segment.append(line)
            
            i += 1
        
        # Add remaining content
        if current_segment:
            if in_code_block:
                segments.append(('code', '\n'.join(current_segment), language))
            elif in_table:
                segments.append(('table', '\n'.join(current_segment)))
            else:
                segments.append(('text', current_segment))
        
        # Process each segment
        for segment in segments:
            if segment[0] == 'text':
                # Process text while preserving markdown structure
                text_lines = segment[1] if isinstance(segment[1], list) else segment[1].split('\n')
                
                current_paragraph_lines = []
                
                for line in text_lines:
                    line = line.rstrip()
                    
                    # Handle empty lines (paragraph breaks)
                    if not line.strip():
                        # Flush current paragraph if any
                        if current_paragraph_lines:
                            combined_text = ' '.join(current_paragraph_lines)
                            self._add_formatted_text(combined_text)
                            current_paragraph_lines = []
                        # Don't add extra empty paragraphs
                        continue
                    
                    # Handle headers
                    if line.startswith('#'):
                        # Flush current paragraph if any
                        if current_paragraph_lines:
                            combined_text = ' '.join(current_paragraph_lines)
                            self._add_formatted_text(combined_text)
                            current_paragraph_lines = []
                        
                        header_level = len(line) - len(line.lstrip('#'))
                        header_text = line.lstrip('#').strip()
                        
                        # Add spacing before header
                        if header_level <= 2:
                            self.doc.add_paragraph()  # Add space before major headers
                        
                        paragraph = self.doc.add_paragraph()
                        run = paragraph.add_run(header_text)
                        run.bold = True
                        run.font.name = self.config.text_font
                        # Proper header font sizes
                        if header_level == 1:
                            run.font.size = Pt(12)
                        elif header_level == 2:
                            run.font.size = Pt(11)
                        elif header_level == 3:
                            run.font.size = Pt(11)
                        else:
                            run.font.size = Pt(10)
                        paragraph.paragraph_format.left_indent = Inches(0.25)

                        continue
                    
                    # Handle bullet points
                    if line.strip().startswith('* ') or line.strip().startswith('- '):
                        # Flush current paragraph if any
                        if current_paragraph_lines:
                            combined_text = ' '.join(current_paragraph_lines)
                            self._add_formatted_text(combined_text)
                            current_paragraph_lines = []
                        
                        bullet_text = line.strip()[2:].strip()
                        # Process inline formatting
                        bullet_text = bullet_text.replace('**', '')
                        bullet_text = bullet_text.replace('`', '')
                        self.doc.add_paragraph(bullet_text, style='List Bullet')
                        continue
                    
                    # Handle numbered lists
                    if re.match(r'^\d+\.\s', line.strip()):
                        # Flush current paragraph if any
                        if current_paragraph_lines:
                            combined_text = ' '.join(current_paragraph_lines)
                            self._add_formatted_text(combined_text)
                            current_paragraph_lines = []
                        
                        list_text = re.sub(r'^\d+\.\s+', '', line.strip())
                        # Process inline formatting
                        list_text = list_text.replace('**', '')
                        list_text = list_text.replace('`', '')
                        self.doc.add_paragraph(list_text, style='List Number')
                        continue
                    
                    # Accumulate regular text lines into paragraphs
                    if line.strip():
                        current_paragraph_lines.append(line.strip())
                
                # Flush any remaining paragraph
                if current_paragraph_lines:
                    combined_text = ' '.join(current_paragraph_lines)
                    self._add_formatted_text(combined_text)
            
            elif segment[0] == 'code':
                # Process code block
                self._add_code_block_with_highlighting(segment[1], segment[2])
            
            elif segment[0] == 'table':
                # Process table
                self._add_enhanced_table(segment[1])
    
    def _add_formatted_text(self, text: str):
        """Add text with basic markdown formatting (bold, italic, inline code)"""
        # Split by paragraphs
        paragraphs = text.split('\n\n')
        
        for para_text in paragraphs:
            if not para_text.strip():
                continue
                
            para = self.doc.add_paragraph(style='MessageContent')
            
            # Process inline formatting
            parts = re.split(r'(\*\*.*?\*\*|`.*?`)', para_text)
            
            for part in parts:
                if not part:
                    continue
                    
                if part.startswith('**') and part.endswith('**'):
                    # Bold text
                    run = para.add_run(part[2:-2])
                    run.bold = True
                elif part.startswith('`') and part.endswith('`'):
                    # Inline code
                    run = para.add_run(part[1:-1])
                    run.font.name = self.config.code_font
                    run.font.size = Pt(self.config.code_size)
                    run.font.color.rgb = RGBColor(*self.config.code_text_color)
                    # Add light background
                    self._add_run_shading(run, (248, 248, 248))
                else:
                    # Regular text
                    run = para.add_run(part)
    
    def _add_run_shading(self, run, color: Tuple[int, int, int]):
        """Add background shading to a run"""
        rPr = run._element.get_or_add_rPr()
        shd = OxmlElement('w:shd')
        shd.set(qn('w:val'), 'clear')
        shd.set(qn('w:color'), 'auto')
        shd.set(qn('w:fill'), f"{color[0]:02x}{color[1]:02x}{color[2]:02x}")
        rPr.append(shd)
    
    def _add_message(self, message: dict):
        """Add a comprehensive message to the document"""
        role = message.get("role", "")
        name = message.get("name", "Unknown")
        content = message.get("content", "")
        timestamp = message.get("timestamp", "")
        
        # Format timestamp
        try:
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            time_str = dt.strftime(self.config.timestamp_format)
        except:
            time_str = timestamp
        
        # Message header
        # icon = self.config.user_icon if role == "user" else self.config.assistant_icon
        header_text = f"{name}"
        
        header_para = self.doc.add_paragraph(style='MessageHeader')
        header_run = header_para.add_run(header_text)
        
        # Add timestamp
        if time_str:
            timestamp_run = header_para.add_run(f"  {time_str}")
            timestamp_run.font.size = Pt(self.config.small_size)
            timestamp_run.font.color.rgb = RGBColor(*self.config.text_medium)
            timestamp_run.font.bold = False
        
        # Process content
        if content.strip():
            self._process_markdown_content(content)
        
        self.doc.add_paragraph()

    
    def markdown_to_docx(self, chat_data: dict, output_filename: str = "chat_export.docx"):
        """Main method to convert chat data to DOCX"""
        # Setup document
        self._setup_document()
        
        # Add header
        self._add_header(chat_data)
        
        # Process messages
        messages = chat_data.get("messages", [])
        for message in messages:
            self._add_message(message)
        
        # Add footer with generation info
        self._add_footer()
        
        # Save document
        self.doc.save(output_filename)
        print(f"DOCX saved as: {output_filename}")
    
    def _add_footer(self):
        """Add a footer with generation information"""
        # Add a page break before footer info
        self.doc.add_page_break()
        
        # Add generation info
        footer_para = self.doc.add_paragraph("", style='SmallText')
        footer_para.alignment = WD_PARAGRAPH_ALIGNMENT.CENTER
        footer_run = footer_para.add_run(f"Generated by GnieStudio 4.0 on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        footer_run.italic = True
    
    def load_from_file(self, file_path: str) -> Any:
        """
        Load chat data from JSON file

        Args:
            file_path (str): Path to the JSON file
            
        Returns:
            dict: Chat data if successful, None if failed
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                data = json.load(file)
                return data
        except FileNotFoundError:
            print(f"Error: File '{file_path}' not found.")
            return None
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON in file '{file_path}': {e}")
            return None
        except Exception as e:
            print(f"Error loading file '{file_path}': {e}")
            return None
    
    def validate_chat_data(self, chat_data: dict) -> bool:
        """
        Validate chat data structure
        
        Args:
            chat_data (dict): Chat data to validate
            
        Returns:
            bool: True if valid, False otherwise
        """
        if not isinstance(chat_data, dict):
            print("Error: Chat data must be a dictionary")
            return False
        
        if "messages" not in chat_data:
            print("Error: Chat data must contain 'messages' key")
            return False
        
        messages = chat_data["messages"]
        if not isinstance(messages, list):
            print("Error: 'messages' must be a list")
            return False
        
        for i, message in enumerate(messages):
            if not isinstance(message, dict):
                print(f"Error: Message {i} must be a dictionary")
                return False
            
            required_fields = ["role", "content"]
            for field in required_fields:
                if field not in message:
                    print(f"Error: Message {i} missing required field '{field}'")
                    return False
        
        return True
    
    def get_document_stats(self, chat_data: dict) -> dict:
        """
        Get statistics about the document to be generated
        
        Args:
            chat_data (dict): Chat data
            
        Returns:
            dict: Document statistics
        """
        if not self.validate_chat_data(chat_data):
            return {}
        
        messages = chat_data.get("messages", [])
        
        # Count different message types
        user_messages = sum(1 for msg in messages if msg.get("role") == "user")
        assistant_messages = sum(1 for msg in messages if msg.get("role") == "assistant")
        
        # Count content features
        total_words = 0
        code_blocks = 0
        tables = 0
        
        for message in messages:
            content = message.get("content", "")
            total_words += len(content.split())
            code_blocks += content.count("```") // 2
            tables += len(re.findall(r'\|.*\|', content))
        
        return {
            "total_messages": len(messages),
            "user_messages": user_messages,
            "assistant_messages": assistant_messages,
            "estimated_words": total_words,
            "code_blocks": code_blocks,
            "tables": tables // 2 if tables > 0 else 0  # Rough estimate
        }


# Example usage and configuration presets
def create_preset_configs():
    """Create different preset configurations"""
    
    # Minimal configuration
    minimal_config = DOCXConfig(
        page_size="A4",
        orientation="portrait",
        enable_syntax_highlighting=False,
        enable_table_formatting=False,
        enable_code_block_borders=False,
        enable_page_numbers=False,
        text_size=11,
        code_size=10
    )
    
    # Professional configuration
    professional_config = DOCXConfig(
        page_size="A4",
        orientation="portrait",
        enable_syntax_highlighting=True,
        enable_table_formatting=True,
        enable_code_block_borders=True,
        enable_page_numbers=True,
        title_font="Calibri",
        text_font="Calibri",
        code_font="Consolas",
        primary_color=(0, 102, 204),  # Professional blue
        text_size=11,
        code_size=9
    )
    
    # Presentation configuration (landscape, larger fonts)
    presentation_config = DOCXConfig(
        page_size="A4",
        orientation="landscape",
        enable_syntax_highlighting=True,
        enable_table_formatting=True,
        enable_code_block_borders=True,
        enable_page_numbers=True,
        title_size=22,
        header_size=14,
        text_size=12,
        code_size=11,
        margin_top=0.8,
        margin_bottom=0.8,
        margin_left=1.0,
        margin_right=1.0
    )
    
    # Compact configuration
    compact_config = DOCXConfig(
        page_size="A4",
        orientation="portrait",
        enable_syntax_highlighting=True,
        enable_table_formatting=True,
        enable_code_block_borders=False,
        enable_page_numbers=True,
        title_size=16,
        header_size=10,
        text_size=9,
        code_size=8,
        margin_top=0.5,
        margin_bottom=0.5,
        margin_left=0.6,
        margin_right=0.6,
        line_spacing=0.5,
        message_spacing_before=8,
        message_spacing_after=4
    )
    
    return {
        "minimal": minimal_config,
        "professional": professional_config,
        "presentation": presentation_config,
        "compact": compact_config
    }


# Example usage with different configurations
if __name__ == "__main__":
    # Sample data for testing
    sample_data = {
        "conversation_title": "AI Chat Export - DOCX Sample",
        "messages": [
            {
                "role": "user",
                "name": "User",
                "timestamp": "2025-09-12T08:00:00Z",
                "content": "Hello! Could you show me a **Python** example with some `inline code` and explain how it works?",
                "content_format": "markdown",
                "attachments": []
            },
            {
                "role": "assistant", 
                "name": "Assistant",
                "timestamp": "2025-09-12T08:01:00Z",
                "content": """Sure! Here's a simple Python example:\n\n```python\ndef fibonacci(n):\n    \"\"\"Calculate the nth Fibonacci number\"\"\"\n    if n <= 1:\n        return n\n    else:\n        return fibonacci(n-1) + fibonacci(n-2)\n\n# Test the function\nfor i in range(10):\n    print(f"F({i}) = {fibonacci(i)}")\n```\n\nThis function calculates **Fibonacci numbers** recursively. Here's a comparison table:\n\n| n | F(n) | Time Complexity |\n|---|------|----------------|\n| 0 | 0    | O(1)           |\n| 1 | 1    | O(1)           |\n| 5 | 5    | O(φⁿ)          |\n| 10| 55   | O(φⁿ)          |\n\nThe time complexity grows exponentially, so for larger values, you'd want to use **dynamic programming** or memoization.""",
                "content_format": "markdown",
                "attachments": []
            },
            {
                "role": "user",
                "name": "User", 
                "timestamp": "2025-09-12T08:02:00Z",
                "content": "That's great! Can you also show me an HTML example?",
                "content_format": "markdown",
                "attachments": []
            },
            {
                "role": "assistant",
                "name": "Assistant",
                "timestamp": "2025-09-12T08:03:00Z",
                "content": """Absolutely! Here's a simple HTML example:\n\n```html\n<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>My First Web Page</title>\n    <style>\n        body { font-family: Arial, sans-serif; }\n        .highlight { background-color: yellow; }\n    </style>\n</head>\n<body>\n    <h1>Welcome to My Website</h1>\n    <p>This is a <span class="highlight">highlighted</span> paragraph.</p>\n    <!-- This is a comment -->\n    <ul>\n        <li>Item 1</li>\n        <li>Item 2</li>\n    </ul>\n</body>\n</html>\n```\n\nThis creates a basic web page with **styling** and **semantic HTML** structure.""",
                "content_format": "markdown",
                "attachments": []
            }
        ]
    }
    
    # Get preset configurations
    configs = create_preset_configs()
    
    # Test with professional configuration
    print("Creating DOCX with professional configuration...")
    professional_converter = ChatToDOCX(configs["professional"])
    
    # Load from file if available, otherwise use sample data
    loaded_data = professional_converter.load_from_file("../large_chat_sample.json")
    test_data = loaded_data if loaded_data else sample_data
    
    # Get document statistics
    stats = professional_converter.get_document_stats(test_data)
    print(f"Document Statistics: {stats}")
    
    # Generate DOCX
    professional_converter.convert_to_docx(test_data, "professional_chat_export.docx")
    
    # Test with presentation configuration (landscape)
    print("\nCreating DOCX with presentation configuration...")
    presentation_converter = ChatToDOCX(configs["presentation"])
    presentation_converter.convert_to_docx(test_data, "presentation_chat_export.docx")
    
    # Test with compact configuration
    print("\nCreating DOCX with compact configuration...")
    compact_converter = ChatToDOCX(configs["compact"])
    compact_converter.convert_to_docx(test_data, "compact_chat_export.docx")
    
    print("\nAll DOCX files generated successfully!")