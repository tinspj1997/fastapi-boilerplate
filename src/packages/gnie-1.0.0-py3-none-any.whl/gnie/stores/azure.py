import io
import os
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from functools import singledispatchmethod
from pathlib import Path
from typing import List, NewType, Tuple

from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.storage.blob import (
    BlobServiceClient,
    ContainerClient,
    ContainerSasPermissions,
    generate_container_sas,
)

from gnie.schema.azure import BlobUploadEntity, UploadError, UploadResult, UploadSuccess

HttpsUrl = NewType("HttpsUrl", str)


class AzureBlob:
    def __init__(self, connection_string: str) -> None:
        """
        Initialize the AzureBlob instance.

        Args:
            connection_string (str): Azure Blob Storage connection string.
        """
        self.connection_string = connection_string
        self.blob_client = BlobServiceClient.from_connection_string(connection_string)
        self.containers = []

    def list_all_containers(self) -> list:
        """
        List all containers in the Blob Storage account.

        Returns:
            list: A list of container names.
        """
        self.containers = [
            container["name"] for container in self.blob_client.list_containers()
        ]
        return self.containers

    def is_container_exists(self, container_name: str) -> bool:
        """
        Check if a container exists.

        Args:
            container_name (str): The name of the container to check.

        Returns:
            bool: True if the container exists, False otherwise.
        """
        try:
            container_client = self.blob_client.get_container_client(container_name)
            container_client.get_container_properties()
            return True
        except ResourceNotFoundError:
            return False
        except Exception:
            return False

    def create_container(self, container_name: str) -> bool:
        """
        Create a new container.

        Args:
            container_name (str): The name of the container to create.

        Returns:
            bool: True if container creation was successful.

        Raises:
            ValueError: If the container already exists or creation fails.
        """
        try:
            container_client = self.blob_client.get_container_client(container_name)
            container_client.create_container()
            return True
        except ResourceExistsError:
            raise ValueError(f"container {container_name} already exists.")
        except Exception as e:
            raise ValueError(f"could not create container: {e}") from e

    def delete_container(self, container_name: str):
        """
        Delete an existing container.

        Args:
            container_name (str): The name of the container to delete.

        Returns:
            bool: True if deletion was successful.

        Raises:
            ValueError: If the container does not exist or deletion fails.
        """
        try:
            self.blob_client.delete_container(container_name)
            return True
        except ResourceNotFoundError:
            raise ValueError(f"Container {container_name} does not exist.")
        except Exception as e:
            raise ValueError(f"Failed to delete container {container_name}: {e}") from e

    def is_file_exists(self, container_name: str, blob_name: str) -> bool:
        """
        Check if a blob exists.

        Args:
            container_name (str): The name of the container to check.
            blob_name (str): The name of the blob to check.

        Returns:
            bool: True if the blob exists, False otherwise.
        """
        try:
            container_client = self.blob_client.get_container_client(container_name)
            blob_client = container_client.get_blob_client(blob_name)
            blob_client.get_blob_properties()
            return True
        except ResourceNotFoundError:
            return False
        except Exception:
            return False

    @singledispatchmethod
    def upload_file(self, data, container_name: str) -> UploadResult:
        """
        Uploads file in to blob.

        :param data: The input data (BlobUploadEntity or list of BlobUploadEntity).
        :param container_name: The name of the target container.
        :raises TypeError: If the data type is unsupported.
        :return: An `UploadResult` object containing details about the upload operation.
         - `UploadResult.success`: Indicates successful uploads.
         - `UploadResult.error`: Contains error information if the upload fails.
        """
        raise TypeError(f"Unsupported data type: {type(data).__name__}")

    @upload_file.register
    def _(self, data: BlobUploadEntity, container_name: str) -> UploadResult:
        if not self.is_container_exists(container_name):
            raise ValueError(f"Container '{container_name}' does not exist")

        container_client = self.blob_client.get_container_client(container_name)
        results = UploadResult(success=None, errors=None)

        try:
            url = self._upload_to_blob(data.file, container_client, data.blob_name)
            results.success = UploadSuccess(blob_name=data.blob_name, url=url)
        except Exception as e:
            results.errors = UploadError(blob_name=data.blob_name, error=str(e))

        return results

    @upload_file.register
    def _(self, data: list, container_name: str) -> UploadResult:
        if not self.is_container_exists(container_name):
            raise ValueError(f"Container '{container_name}' does not exist")

        if not all(isinstance(item, BlobUploadEntity) for item in data):
            raise TypeError("All items in the list must be BlobUploadEntity instances")

        container_client = self.blob_client.get_container_client(container_name)
        results = UploadResult(success=[], errors=[])

        def safe_upload(entity: BlobUploadEntity):
            try:
                url = self._upload_to_blob(
                    entity.file, container_client, entity.blob_name
                )
                return UploadSuccess(blob_name=entity.blob_name, url=url)
            except Exception as e:
                return UploadError(blob_name=entity.blob_name, error=str(e))

        with ThreadPoolExecutor(max_workers=min(10, os.cpu_count() or 1)) as executor:
            for result in executor.map(safe_upload, data):
                (
                    results.success
                    if isinstance(result, UploadSuccess)
                    else results.errors
                ).append(result)

        return results

    def _upload_to_blob(
        self, file, container_client: ContainerClient, blob_name: str
    ) -> str:
        blob = container_client.get_blob_client(blob_name)

        if isinstance(file, str):
            with open(file, "rb") as data:
                blob.upload_blob(data, overwrite=True)
        elif isinstance(file, io.IOBase):
            blob.upload_blob(file, overwrite=True)
        else:
            raise TypeError(f"Unsupported file type: {type(file).__name__}")

        return urllib.parse.unquote(blob.url)

    @singledispatchmethod
    def delete_file(self, blob_name, container_name: str) -> bool:
        raise TypeError(f"Unsupported file type: {type(blob_name).__name__}")

    @delete_file.register
    def _(self, blob_name: str, container_name: str) -> bool:
        try:
            if not self.is_container_exists(container_name):
                raise ValueError(f"Container '{container_name}' does not exist")

            blob_client = self.blob_client.get_blob_client(
                container=container_name, blob=blob_name
            )
            blob_client.delete_blob()
            return True
        except ResourceNotFoundError:
            raise FileNotFoundError(f"file {blob_name} not found")
        except Exception as e:
            raise ValueError(str(e)) from e

    @delete_file.register
    def _(self, blob_name: list, container_name: str) -> bool:
        try:
            if not self.is_container_exists(container_name):
                raise ValueError(f"Container '{container_name}' does not exist")

            blob_client = self.blob_client.get_container_client(
                container=container_name
            )
            blob_client.delete_blobs(*blob_name)
            return True
        except ResourceNotFoundError:
            raise FileNotFoundError(f"file {blob_name} not found")
        except Exception as e:
            raise ValueError(str(e)) from e

    def list_files(self, container_name: str) -> List[HttpsUrl]:
        """
        List all files (blob names) in a container.

        Args:
            container_name (str): The name of the container.

        Returns:
            List[HttpsUrl]: List of blob names in the container.

        Raises:
            ValueError: If listing fails.
        """
        try:
            container_client = self.blob_client.get_container_client(container_name)
            blobs = container_client.list_blobs()
            return [blob.name for blob in blobs]
        except Exception as e:
            raise ValueError(str(e)) from e

    def download_file(
        self, container_name: str, blob_name: str, download_dir: str = ""
    ):
        """
        Download a file (blob) from a container to the local file system.

        Args:
            container_name (str): The name of the container.
            blob_name (str): The name of the blob to download.
            download_dir (str): The directory to save the file to (default is current working directory).

        Returns:
            Path: The path to the downloaded file.

        Raises:
            FileNotFoundError: If the blob does not exist.
            ValueError: If download fails or `download_dir` is invalid.
        """
        try:
            if not isinstance(download_dir, str):
                raise ValueError("download dir should be str format")
            blob_client = self.blob_client.get_blob_client(
                container=container_name, blob=blob_name
            )

            # creating download path
            local_path = Path(download_dir) if download_dir else Path.cwd()
            local_path.mkdir(parents=True, exist_ok=True)
            download_file_path = local_path / blob_name

            with open(download_file_path, "wb") as file:
                file.write(blob_client.download_blob().readall())

            return download_file_path

        except ResourceNotFoundError:
            raise FileNotFoundError(
                f"Blob '{blob_name}' not found in container '{container_name}'."
            )
        except Exception as e:
            raise ValueError(f"Failed to download file: {e}") from e

    def _get_account_details(self):
        """
        Extract account name and account key from the connection string.
        """
        parsed = dict(
            item.split("=", 1)
            for item in self.connection_string.split(";")
            if "=" in item
        )
        return parsed["AccountName"], parsed["AccountKey"]

    def generate_container_sas_token(
        self,
        container_name: str,
        expiry_hours: int = 1,
        permission: str = "r",
        content_type=None,
        content_disposition=None,
    ) -> str:
        """
        Generates a SAS token for container.

        Args:
            container_name (str): Name of the container.
            expiry_hours (int): Token expiry time in hours. Defaults to 1.
            permission (str): Access permissions ("r", "w", "rw", "rwd"). Defaults to "r".
            content_type (str, optional): Content type for the blob/container.
            content_disposition (str, optional): Content disposition header.

        Returns:
            str: Generated SAS token.

        Raises:
            ValueError: If the container does not exist.
        """
        if not self.is_container_exists(container_name):
            raise ValueError(f"Container '{container_name}' does not exist")

        account_name, account_key = self._get_account_details()
        expiry = datetime.now(timezone.utc) + timedelta(hours=expiry_hours)

        sas_kwargs = {
            "account_name": account_name,
            "container_name": container_name,
            "account_key": account_key,
            "permission": ContainerSasPermissions.from_string(permission),
            "expiry": expiry,
        }

        # Only add optional kwargs if they are provided
        if content_type and content_disposition:
            sas_kwargs["content_type"] = content_type
            sas_kwargs["content_disposition"] = content_disposition

        sas_token = generate_container_sas(**sas_kwargs)
        return sas_token

    def generate_blob_sas_url(
        self,
        container_name: str,
        blob_name: str,
        expiry_hours: int = 1,
        permission: str = "r",
    ) -> str:
        """
        Generates a SAS URL for the specified blob.

        Args:
            container_name (str): Name of the container.
            blob_name (str): Name of the blob.
            expiry_hours (int): URL expiry time in hours. Defaults to 1.
            permission (str): Access permission ("r", "w", "rw", "rwd"). Defaults to "r".

        Returns:
            str: Full SAS URL for the blob.

        Raises:
            ValueError: If the container does not exist.
        """
        if not self.is_container_exists(container_name):
            raise ValueError(f"Container '{container_name}' does not exist")

        account_name, _ = self._get_account_details()
        sas_token = self.generate_container_sas_token(
            container_name=container_name,
            expiry_hours=expiry_hours,
            permission=permission,
        )

        return f"https://{account_name}.blob.core.windows.net/{container_name}/{blob_name}?{sas_token}"

    @staticmethod
    def parse_blob_url(blob_url: str) -> Tuple[str, str]:
        """
        Extracts the container name and blob name from a blob URL.

        Args:
            blob_url (str): The full blob URL.

        Returns:
            Tuple[str, str]: (container_name, blob_name)

        Raises:
            ValueError: If the URL is invalid or does not contain both container and blob.
        """
        try:
            parsed = urllib.parse.urlparse(blob_url)
            if not parsed.scheme.startswith("http") or "blob.core.windows.net" not in parsed.netloc:
                raise ValueError("Invalid Azure Blob URL format")

            path_parts = parsed.path.strip("/").split("/", 1)
            if len(path_parts) != 2:
                raise ValueError("Blob URL must contain both container and blob name")

            container_name, blob_name = path_parts
            return container_name, blob_name
        except Exception as e:
            raise ValueError(f"Failed to parse blob URL: {e}") from e
