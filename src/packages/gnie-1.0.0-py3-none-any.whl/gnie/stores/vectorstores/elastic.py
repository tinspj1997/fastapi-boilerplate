from dataclasses import dataclass, field
from typing import Optional, List, Any, Dict

from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError
from langchain_elasticsearch import ElasticsearchStore
from langchain_core.documents import Document


@dataclass(slots=True)
class ElasticSearchVectorStore:
    host: str = "http://localhost:9200"
    username: Optional[str] = None
    password: Optional[str] = None
    _client: Elasticsearch = field(init=False)
    request_timeout: Optional[int] = None
    retry_on_timeout: Optional[bool] = None
    max_retries: Optional[int] = None

    def __post_init__(self):
        client_args: dict[str, Any] = {"verify_certs": False}

        # Only add basic_auth if both username and password are truthy strings
        if self.username and self.password:
            client_args["basic_auth"] = (self.username, self.password)

        # Only add parameters if they are not None
        if self.request_timeout is not None:
            client_args["request_timeout"] = self.request_timeout

        if self.retry_on_timeout is not None:
            client_args["retry_on_timeout"] = self.retry_on_timeout

        if self.max_retries is not None:
            client_args["max_retries"] = self.max_retries

        self._client = Elasticsearch(self.host, **client_args)

    @property
    def client(self):
        return self._client

    def ping_es(self) -> bool:
        return self._client.ping()

    def is_index_exists(self, index_name: str) -> bool:
        return self._client.indices.exists(index=index_name)

    def create_index(self, index_name: str, mapping: dict) -> None:
        if self.is_index_exists(index_name):
            raise ValueError(f"Index '{index_name}' already exists.")
        self._client.indices.create(index=index_name, body=mapping)

    def batch_documents(self, documents: List[Document], batch_size):
        for i in range(0, len(documents), batch_size):
            yield documents[i : i + batch_size]

    async def add_documents(
        self, index_name: str, embedding_model, documents: List[Document], batch_size=50
    ) -> None:
        vector_store = ElasticsearchStore(
            es_connection=self._client,
            index_name=index_name,
            embedding=embedding_model,
        )
        for batch in self.batch_documents(documents, batch_size):
            await vector_store.aadd_documents(batch)

    def delete_document(self, index_name: str, doc_id: str) -> None:
        try:
            self._client.delete(index=index_name, id=doc_id)
        except NotFoundError:
            raise ValueError(
                f"Document with ID '{doc_id}' not found in index '{index_name}'."
            )

    def delete_index(self, index_name: str) -> None:
        if not self.is_index_exists(index_name):
            raise ValueError(f"Index '{index_name}' does not exist.")
        self._client.indices.delete(index=index_name)

    def delete_documents_with_query(self, index_name: str, filters: dict) -> Any:
        """
        Deletes documents from the specified Elasticsearch index that match the given metadata filters.

        Args:
            index_name (str): The name of the Elasticsearch index.
            filters (dict): Key-value pairs to filter documents for deletion.

        Returns:
            Any: The response from Elasticsearch's delete_by_query API.
        """
        if not filters or not isinstance(filters, dict):
            raise ValueError("Filters must be a non-empty dictionary.")
        if (
            not isinstance(index_name, str)
            or not index_name.strip()
            or not self._client.indices.exists(index=index_name)
        ):
            raise ValueError(f"Index '{index_name}' does not exist or is invalid.")

        filter_clauses = self.build_metadata_filters(filters)
        query = {"bool": {"filter": filter_clauses}}
        body = {"query": query}
        response = self._client.delete_by_query(index=index_name, body=body)
        return response

    def build_metadata_filters(self, filters: dict) -> list:
        """
        Convert a dict of filters into Elasticsearch filter clauses targeting metadata fields.

        Args:
            filters (dict): e.g. { "doc_id": 101, "page": [1, 2, 3] }

        Returns:
            list: Elasticsearch-compatible `term` or `terms` filter clauses.
        """
        clauses = []
        for key, value in filters.items():
            field = f"metadata.{key.strip()}"
            if isinstance(value, list) and value:
                clauses.append({"terms": {field: value}})
            elif isinstance(value, (str, int, float, bool)):
                clauses.append({"term": {field: value}})
        return clauses

    def search_documents(
        self,
        index_name: str,
        filters: Dict[str, Any],
        size: int = 1000,
        required_metadata: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetches up to `size` documents from the specified Elasticsearch index that match the given metadata filters.
        Uses the standard Elasticsearch search API, which is stateless and returns fresh data at query time.

        Args:
            index_name (str): The name of the Elasticsearch index to search.
            filters (Dict[str, Any]): Dictionary of metadata filters used to match documents.
            size (int, optional): Maximum number of documents to retrieve. Defaults to 1000.
            required_metadata (Optional[List[str]]): Specific metadata fields to retain. If None, all metadata is returned.

        Returns:
            List[Dict[str, Any]]: A list of matching documents, each containing:
                - "page_content": the document's text content.
                - "metadata": filtered metadata dictionary as per `required_metadata`.

        Raises:
            ValueError: If `filters` is empty or not a dictionary.
            ValueError: If `index_name` is missing or invalid.
            ValueError: If the Elasticsearch client is not initialized.

        Note:
            Ideal for quick retrieval of up to ~10,000 documents.
            For larger or paginated results, use `scroll_documents()` instead.
        """
        if not filters or not isinstance(filters, dict):
            raise ValueError("Filters must be a non-empty dictionary.")
        if (
            not isinstance(index_name, str)
            or not index_name.strip()
            or not self.client.indices.exists(index=index_name)
        ):
            raise ValueError(f"Index '{index_name}' does not exist or is invalid.")
        if not self.client:
            raise ValueError("Elasticsearch client is not initialized.")

        query = {"bool": {"filter": self.build_metadata_filters(filters)}}

        body = {"query": query, "_source": {"excludes": ["vector"]}, "size": size}

        response = self._client.search(index=index_name, body=body)
        hits = response["hits"]["hits"]

        return self.clean_es_docs(hits, required_metadata)

    def clean_es_docs(
        self, docs: List[Dict[str, Any]], required_metadata: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Transforms raw Elasticsearch documents into simplified format:
        {
            "page_content": <text>,
            "metadata": { filtered metadata }
        }

        Args:
            docs (List[Dict[str, Any]]): List of Elasticsearch documents from hits.
            required_metadata (Optional[List[str]]): Metadata keys to retain. If None, all are retained.

        Returns:
            List[Dict[str, Any]]: Simplified document structure.
        """
        cleaned = []
        for doc in docs:
            source = doc.get("_source", {})
            metadata = source.get("metadata", {})

            if required_metadata is not None:
                metadata = {
                    key: metadata.get(key)
                    for key in required_metadata
                    if key in metadata
                }

            cleaned.append(
                {"page_content": source.get("text", ""), "metadata": metadata}
            )

        return cleaned
