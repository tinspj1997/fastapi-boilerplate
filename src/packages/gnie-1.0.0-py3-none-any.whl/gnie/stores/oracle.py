import io
import os
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from functools import singledispatchmethod
from pathlib import Path
from typing import List, NewType, Optional
from dataclasses import dataclass

import oci
from oci.exceptions import ServiceError
from oci.object_storage import ObjectStorageClient


HttpsUrl = NewType("HttpsUrl", str)


@dataclass
class ObjectUploadEntity:
    """Entity for object upload operations."""
    file: str | io.IOBase
    object_name: str


@dataclass
class UploadSuccess:
    """Represents successful upload result."""
    object_name: str
    url: str


@dataclass
class UploadError:
    """Represents upload error."""
    object_name: str
    error: str


@dataclass
class UploadResult:
    """Container for upload results."""
    success: Optional[UploadSuccess | List[UploadSuccess]] = None
    errors: Optional[UploadError | List[UploadError]] = None


class OCIObjectStorage:
    def __init__(self, config_path: str = None, profile: str = "DEFAULT") -> None:
        """
        Initialize the OCIObjectStorage instance.

        Args:
            config_path (str, optional): Path to OCI config file. Defaults to ~/.oci/config.
            profile (str): Profile name in config file. Defaults to "DEFAULT".
        """
        try:
            if config_path:
                self.config = oci.config.from_file(config_path, profile)
            else:
                self.config = oci.config.from_file(profile_name=profile)
            
            # Validate config
            oci.config.validate_config(self.config)
            
            self.object_storage_client = ObjectStorageClient(self.config)
            self.namespace = self.object_storage_client.get_namespace().data
            self.buckets = []
            
        except Exception as e:
            raise ValueError(f"Failed to initialize OCI client: {e}") from e

    def list_all_buckets(self) -> List[str]:
        """
        List all buckets in the Object Storage namespace.

        Returns:
            List[str]: A list of bucket names.
        """
        try:
            response = self.object_storage_client.list_buckets(
                namespace_name=self.namespace,
                compartment_id=self.config["compartment_id"]
            )
            self.buckets = [bucket.name for bucket in response.data]
            return self.buckets
        except ServiceError as e:
            raise ValueError(f"Failed to list buckets: {e.message}") from e

    def is_bucket_exists(self, bucket_name: str) -> bool:
        """
        Check if a bucket exists.

        Args:
            bucket_name (str): The name of the bucket to check.

        Returns:
            bool: True if the bucket exists, False otherwise.
        """
        try:
            self.object_storage_client.head_bucket(
                namespace_name=self.namespace,
                bucket_name=bucket_name
            )
            return True
        except ServiceError as e:
            if e.status == 404:
                return False
            return False
        except Exception:
            return False

    def create_bucket(self, bucket_name):
        try:
            details = oci.object_storage.models.CreateBucketDetails(
                name=bucket_name,
                compartment_id=self.config["compartment_id"],
                public_access_type="NoPublicAccess",
            )
            self.object_storage_client.create_bucket(
                namespace_name=self.namespace,
                create_bucket_details=details
            )
            return f"Bucket '{bucket_name}' created."
        except oci.exceptions.ServiceError as e:
            if e.status == 409 and e.code == "BucketAlreadyExists":
                return f"Bucket '{bucket_name}' already exists."
            raise ValueError(f"Could not create bucket {bucket_name}: {e.message}") from e



    def delete_bucket(self, bucket_name: str) -> bool:
        """
        Delete an existing bucket.

        Args:
            bucket_name (str): The name of the bucket to delete.

        Returns:
            bool: True if deletion was successful.

        Raises:
            ValueError: If the bucket does not exist or deletion fails.
        """
        try:
            if not self.is_bucket_exists(bucket_name):
                raise ValueError(f"Bucket {bucket_name} does not exist.")
            
            self.object_storage_client.delete_bucket(
                namespace_name=self.namespace,
                bucket_name=bucket_name
            )
            return True
        except ServiceError as e:
            raise ValueError(f"Failed to delete bucket {bucket_name}: {e.message}") from e
        except Exception as e:
            raise ValueError(f"Failed to delete bucket {bucket_name}: {e}") from e

    def is_object_exists(self, bucket_name: str, object_name: str) -> bool:
        """
        Check if an object exists.

        Args:
            bucket_name (str): The name of the bucket to check.
            object_name (str): The name of the object to check.

        Returns:
            bool: True if the object exists, False otherwise.
        """
        try:
            self.object_storage_client.head_object(
                namespace_name=self.namespace,
                bucket_name=bucket_name,
                object_name=object_name
            )
            return True
        except ServiceError as e:
            if e.status == 404:
                return False
            return False
        except Exception:
            return False

    @singledispatchmethod
    def upload_object(self, data, bucket_name: str) -> UploadResult:
        """
        Uploads object to bucket.

        :param data: The input data (ObjectUploadEntity or list of ObjectUploadEntity).
        :param bucket_name: The name of the target bucket.
        :raises TypeError: If the data type is unsupported.
        :return: An `UploadResult` object containing details about the upload operation.
         - `UploadResult.success`: Indicates successful uploads.
         - `UploadResult.error`: Contains error information if the upload fails.
        """
        raise TypeError(f"Unsupported data type: {type(data).__name__}")

    @upload_object.register
    def _(self, data: ObjectUploadEntity, bucket_name: str) -> UploadResult:
        if not self.is_bucket_exists(bucket_name):
            raise ValueError(f"Bucket '{bucket_name}' does not exist")

        results = UploadResult(success=None, errors=None)

        try:
            url = self._upload_to_bucket(data.file, bucket_name, data.object_name)
            results.success = UploadSuccess(object_name=data.object_name, url=url)
        except Exception as e:
            results.errors = UploadError(object_name=data.object_name, error=str(e))

        return results

    @upload_object.register
    def _(self, data: list, bucket_name: str) -> UploadResult:
        if not self.is_bucket_exists(bucket_name):
            raise ValueError(f"Bucket '{bucket_name}' does not exist")

        if not all(isinstance(item, ObjectUploadEntity) for item in data):
            raise TypeError("All items in the list must be ObjectUploadEntity instances")

        results = UploadResult(success=[], errors=[])

        def safe_upload(entity: ObjectUploadEntity):
            try:
                url = self._upload_to_bucket(entity.file, bucket_name, entity.object_name)
                return UploadSuccess(object_name=entity.object_name, url=url)
            except Exception as e:
                return UploadError(object_name=entity.object_name, error=str(e))

        with ThreadPoolExecutor(max_workers=min(10, os.cpu_count() or 1)) as executor:
            for result in executor.map(safe_upload, data):
                (
                    results.success
                    if isinstance(result, UploadSuccess)
                    else results.errors
                ).append(result)

        return results

    def _upload_to_bucket(self, file, bucket_name: str, object_name: str) -> str:
        """Internal method to upload file to OCI Object Storage."""
        try:
            if isinstance(file, str):
                with open(file, "rb") as data:
                    self.object_storage_client.put_object(
                        namespace_name=self.namespace,
                        bucket_name=bucket_name,
                        object_name=object_name,
                        put_object_body=data
                    )
            elif isinstance(file, io.IOBase):
                self.object_storage_client.put_object(
                    namespace_name=self.namespace,
                    bucket_name=bucket_name,
                    object_name=object_name,
                    put_object_body=file
                )
            else:
                raise TypeError(f"Unsupported file type: {type(file).__name__}")

            # Generate the object URL
            region = self.config["region"]
            url = f"https://objectstorage.{region}.oraclecloud.com/n/{self.namespace}/b/{bucket_name}/o/{urllib.parse.quote(object_name, safe='')}"
            return url
            
        except ServiceError as e:
            raise ValueError(f"Upload failed: {e.message}") from e

    @singledispatchmethod
    def delete_object(self, object_name, bucket_name: str) -> bool:
        raise TypeError(f"Unsupported object type: {type(object_name).__name__}")

    @delete_object.register
    def _(self, object_name: str, bucket_name: str) -> bool:
        try:
            if not self.is_bucket_exists(bucket_name):
                raise ValueError(f"Bucket '{bucket_name}' does not exist")

            if not self.is_object_exists(bucket_name, object_name):
                raise FileNotFoundError(f"Object {object_name} not found")

            self.object_storage_client.delete_object(
                namespace_name=self.namespace,
                bucket_name=bucket_name,
                object_name=object_name
            )
            return True
        except ServiceError as e:
            raise ValueError(f"Delete failed: {e.message}") from e
        except Exception as e:
            raise ValueError(str(e)) from e

    @delete_object.register
    def _(self, object_names: list, bucket_name: str) -> bool:
        try:
            if not self.is_bucket_exists(bucket_name):
                raise ValueError(f"Bucket '{bucket_name}' does not exist")

            for object_name in object_names:
                self.object_storage_client.delete_object(
                    namespace_name=self.namespace,
                    bucket_name=bucket_name,
                    object_name=object_name
                )
            return True
        except ServiceError as e:
            raise ValueError(f"Bulk delete failed: {e.message}") from e
        except Exception as e:
            raise ValueError(str(e)) from e

    def list_objects(self, bucket_name: str, prefix: str = None) -> List[str]:
        """
        List all objects in a bucket.

        Args:
            bucket_name (str): The name of the bucket.
            prefix (str, optional): Filter objects with this prefix.

        Returns:
            List[str]: List of object names in the bucket.

        Raises:
            ValueError: If listing fails.
        """
        try:
            if not self.is_bucket_exists(bucket_name):
                raise ValueError(f"Bucket '{bucket_name}' does not exist")

            objects = []
            kwargs = {
                "namespace_name": self.namespace,
                "bucket_name": bucket_name
            }
            
            if prefix:
                kwargs["prefix"] = prefix

            response = self.object_storage_client.list_objects(**kwargs)
            
            while True:
                objects.extend([obj.name for obj in response.data.objects])
                
                if response.data.next_start_with is None:
                    break
                    
                kwargs["start"] = response.data.next_start_with
                response = self.object_storage_client.list_objects(**kwargs)
            
            return objects
        except ServiceError as e:
            raise ValueError(f"List objects failed: {e.message}") from e
        except Exception as e:
            raise ValueError(str(e)) from e

    def download_object(
        self, bucket_name: str, object_name: str, download_dir: str = ""
    ) -> Path:
        """
        Download an object from a bucket to the local file system.

        Args:
            bucket_name (str): The name of the bucket.
            object_name (str): The name of the object to download.
            download_dir (str): The directory to save the file to (default is current working directory).

        Returns:
            Path: The path to the downloaded file.

        Raises:
            FileNotFoundError: If the object does not exist.
            ValueError: If download fails or `download_dir` is invalid.
        """
        try:
            if not isinstance(download_dir, str):
                raise ValueError("download dir should be str format")
            
            if not self.is_object_exists(bucket_name, object_name):
                raise FileNotFoundError(
                    f"Object '{object_name}' not found in bucket '{bucket_name}'."
                )

            # Create download path
            local_path = Path(download_dir) if download_dir else Path.cwd()
            local_path.mkdir(parents=True, exist_ok=True)
            download_file_path = local_path / Path(object_name).name

            # Download object
            response = self.object_storage_client.get_object(
                namespace_name=self.namespace,
                bucket_name=bucket_name,
                object_name=object_name
            )

            with open(download_file_path, "wb") as file:
                for chunk in response.data.raw.stream(1024 * 1024, decode_content=False):
                    file.write(chunk)

            return download_file_path

        except ServiceError as e:
            raise ValueError(f"Download failed: {e.message}") from e
        except Exception as e:
            raise ValueError(f"Failed to download object: {e}") from e

    def generate_presigned_url(
        self,
        bucket_name: str,
        object_name: str,
        expiry_hours: int = 1,
        http_method: str = "GET",
    ) -> str:
        """
        Generates a pre-signed URL for the specified object.

        Args:
            bucket_name (str): Name of the bucket.
            object_name (str): Name of the object.
            expiry_hours (int): URL expiry time in hours. Defaults to 1.
            http_method (str): HTTP method ("GET", "PUT", "DELETE"). Defaults to "GET".

        Returns:
            str: Pre-signed URL for the object.

        Raises:
            ValueError: If the bucket does not exist.
        """
        try:
            if not self.is_bucket_exists(bucket_name):
                raise ValueError(f"Bucket '{bucket_name}' does not exist")

            # Calculate expiry time
            expiry_time = datetime.utcnow() + timedelta(hours=expiry_hours)
            
            # Generate pre-signed URL
            preauthenticated_request = self.object_storage_client.create_preauthenticated_request(
                namespace_name=self.namespace,
                bucket_name=bucket_name,
                create_preauthenticated_request_details=oci.object_storage.models.CreatePreauthenticatedRequestDetails(
                    name=f"presigned-{object_name}-{int(datetime.utcnow().timestamp())}",
                    access_type="ObjectRead" if http_method == "GET" else "ObjectReadWrite",
                    time_expires=expiry_time,
                    object_name=object_name
                )
            )
            
            # Construct the full URL
            region = self.config["region"]
            base_url = f"https://objectstorage.{region}.oraclecloud.com"
            presigned_url = f"{base_url}{preauthenticated_request.data.access_uri}"
            
            return presigned_url
            
        except ServiceError as e:
            raise ValueError(f"Failed to generate presigned URL: {e.message}") from e
        except Exception as e:
            raise ValueError(f"Failed to generate presigned URL: {e}") from e

    def get_object_metadata(self, bucket_name: str, object_name: str) -> dict:
        """
        Get metadata for an object.

        Args:
            bucket_name (str): Name of the bucket.
            object_name (str): Name of the object.

        Returns:
            dict: Object metadata.

        Raises:
            ValueError: If the bucket or object does not exist.
        """
        try:
            if not self.is_bucket_exists(bucket_name):
                raise ValueError(f"Bucket '{bucket_name}' does not exist")
            
            if not self.is_object_exists(bucket_name, object_name):
                raise FileNotFoundError(f"Object '{object_name}' not found")

            response = self.object_storage_client.head_object(
                namespace_name=self.namespace,
                bucket_name=bucket_name,
                object_name=object_name
            )
            
            return {
                "content_length": response.headers.get("content-length"),
                "content_type": response.headers.get("content-type"),
                "etag": response.headers.get("etag"),
                "last_modified": response.headers.get("last-modified"),
                "metadata": dict(response.headers)
            }
            
        except ServiceError as e:
            raise ValueError(f"Failed to get object metadata: {e.message}") from e
        except Exception as e:
            raise ValueError(f"Failed to get object metadata: {e}") from e