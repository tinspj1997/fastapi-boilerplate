from dataclasses import dataclass
from typing import Callable, Any

import pika


@dataclass(slots=True)
class RabbitMQ:
    queue_name: str
    host: str = "localhost"
    port: int = 5673
    username: str = "gnierabbitmq"
    password: str = "gnierabbitmq"
    heartbeat: int = 600
    blocked_connection_timeout: int = 300
    on_process: Callable[[Any, Any, Any, bytes], None] = None
    connection: Any = None
    channel: Any = None

    def __post_init__(self):
        self._connect()

    def _connect(self):
        credentials = pika.PlainCredentials(self.username, self.password)
        params = pika.ConnectionParameters(
            host=self.host,
            port=self.port,
            credentials=credentials,
            heartbeat=self.heartbeat,
            blocked_connection_timeout=self.blocked_connection_timeout,
        )
        self.connection = pika.BlockingConnection(params)
        self.channel = self.connection.channel()

        self.channel.queue_declare(queue=self.queue_name, durable=True)
        self.channel.basic_qos(prefetch_count=1)

    def disconnect(self):
        if self.connection and self.connection.is_open:
            self.connection.close()

    def publish(self, data: str, close_connection: bool = False):
        self.channel.basic_publish(exchange="", routing_key=self.queue_name, body=data)
        if close_connection:
            self.disconnect()

    def start_consume(self):
        if self.on_process is None:
            raise ValueError(
                "on_process:Callable function is mandatory.Please pass when initialize the object"
            )

        self.channel.basic_consume(
            queue=self.queue_name, on_message_callback=self.on_process
        )
        self.channel.start_consuming()

    def stop_consuming(self):
        if self.channel and self.channel.is_open:
            self.channel.stop_consuming()

    def retry(self, ch, method, properties, body, max_retry_count=3):
        headers = properties.headers if properties and properties.headers else {}
        retry_count = headers.get("x-retry-count", 0)
        if retry_count < max_retry_count:
            new_headers = headers.copy()
            new_headers["x-retry-count"] = retry_count + 1
            ch.basic_publish(
                exchange="",
                routing_key=method.routing_key,
                body=body,
                properties=pika.BasicProperties(headers=new_headers),
            )
        return retry_count, max_retry_count
