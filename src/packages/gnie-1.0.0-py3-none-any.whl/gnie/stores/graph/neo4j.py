from langchain_neo4j import Neo4jVector
from langchain.docstore.document import Document
from langchain_experimental.graph_transformers import LLMGraphTransformer


def add_documents(
    documents: list[Document], llm, url: str, username: str, password: str
):
    try:
        llm_transformer = LLMGraphTransformer(llm=llm)
        # Neo4jVector.from_documents(
        #     documents, embedding_model, url=url, username=username, password=password
        # )
        return True
    except Exception as e:
        print(f"Error adding documents to Neo4j: {e}")
        return False


def query_documents(
    query: str, embedding_model, url: str, username: str, password: str, k: int = 5
):
    db = Neo4jVector(
        embedding=embedding_model, url=url, username=username, password=password
    )
    docs_with_score = db.similarity_search_with_score(query, k=k)
    return docs_with_score
