import redis
from typing import Optional, Dict, Any, List
import json


class Redis:
    """
    A reusable Redis utility class for storing, accessing, and updating keys.
    Supports both simple key-value operations and complex data structures.
    """

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        username: Optional[str] = None,
        password: Optional[str] = None,
        decode_responses: bool = True,
    ):
        """
        Initialize Redis connection.

        Args:
            redis_url: Redis connection URL
            username: Redis username (optional)
            password: Redis password (optional)
            decode_responses: Whether to decode responses to strings
        """
        self.redis_url = redis_url
        self.username = username
        self.password = password
        self.decode_responses = decode_responses
        self._redis = None  # Lazy initialization

    @property
    def redis(self) -> redis.Redis:
        """Get Redis client with lazy initialization."""
        if self._redis is None:
            self._redis = redis.Redis.from_url(
                self.redis_url,
                username=self.username,
                password=self.password,
                decode_responses=self.decode_responses,
            )
        return self._redis

    def set(self, key: str, value: Any, ex: Optional[int] = None) -> bool:
        """
        Set a key-value pair in Redis.

        Args:
            key: Redis key
            value: Value to store (will be JSON serialized if not string/int)
            ex: Expiration time in seconds (optional)

        Returns:
            bool: True if successful
        """
        try:
            if isinstance(value, (str, int, float)):
                return self.redis.set(key, value, ex=ex)
            else:
                # Serialize complex objects to JSON
                return self.redis.set(key, json.dumps(value), ex=ex)
        except Exception as e:
            print(f"Error setting key {key}: {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        """
        Get value from Redis by key.

        Args:
            key: Redis key
            default: Default value if key doesn't exist

        Returns:
            Retrieved value or default
        """
        try:
            value = self.redis.get(key)
            if value is None:
                return default

            # Try to deserialize JSON, fall back to raw value
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        except Exception as e:
            print(f"Error getting key {key}: {e}")
            return default

    def get_or_set(self, key: str, default_value: Any, ex: Optional[int] = None) -> Any:
        """
        Get value from Redis, set default if key doesn't exist.

        Args:
            key: Redis key
            default_value: Value to set if key doesn't exist
            ex: Expiration time in seconds (optional)

        Returns:
            Retrieved or default value
        """
        value = self.get(key)
        if value is None:
            self.set(key, default_value, ex=ex)
            return default_value
        return value

    def increment(self, key: str, amount: int = 1) -> int:
        """
        Increment a numeric value in Redis.

        Args:
            key: Redis key
            amount: Amount to increment by (default: 1)

        Returns:
            New value after increment
        """
        try:
            return self.redis.incr(key, amount)
        except Exception as e:
            print(f"Error incrementing key {key}: {e}")
            return 0

    def decrement(self, key: str, amount: int = 1) -> int:
        """
        Decrement a numeric value in Redis.

        Args:
            key: Redis key
            amount: Amount to decrement by (default: 1)

        Returns:
            New value after decrement
        """
        try:
            return self.redis.decr(key, amount)
        except Exception as e:
            print(f"Error decrementing key {key}: {e}")
            return 0

    def delete(self, *keys: str) -> int:
        """
        Delete one or more keys from Redis.

        Args:
            keys: Redis keys to delete

        Returns:
            Number of keys deleted
        """
        try:
            return self.redis.delete(*keys)
        except Exception as e:
            print(f"Error deleting keys {keys}: {e}")
            return 0

    def exists(self, key: str) -> bool:
        """
        Check if a key exists in Redis.

        Args:
            key: Redis key

        Returns:
            True if key exists, False otherwise
        """
        try:
            return self.redis.exists(key) > 0
        except Exception as e:
            print(f"Error checking existence of key {key}: {e}")
            return False

    def expire(self, key: str, seconds: int) -> bool:
        """
        Set expiration time for a key.

        Args:
            key: Redis key
            seconds: Seconds until expiration

        Returns:
            True if successful
        """
        try:
            return self.redis.expire(key, seconds)
        except Exception as e:
            print(f"Error setting expiration for key {key}: {e}")
            return False

    def keys(self, pattern: str = "*") -> List[str]:
        """
        Get all keys matching a pattern.

        Args:
            pattern: Pattern to match (default: "*" for all keys)

        Returns:
            List of matching keys
        """
        try:
            return self.redis.keys(pattern)
        except Exception as e:
            print(f"Error getting keys with pattern {pattern}: {e}")
            return []

    def get_multiple(self, keys: List[str]) -> Dict[str, Any]:
        """
        Get multiple values at once.

        Args:
            keys: List of Redis keys

        Returns:
            Dictionary mapping keys to values
        """
        try:
            values = self.redis.mget(keys)
            result = {}
            for key, value in zip(keys, values):
                if value is not None:
                    try:
                        result[key] = json.loads(value)
                    except (json.JSONDecodeError, TypeError):
                        result[key] = value
                else:
                    result[key] = None
            return result
        except Exception as e:
            print(f"Error getting multiple keys {keys}: {e}")
            return {}

    def set_multiple(self, mapping: Dict[str, Any]) -> bool:
        """
        Set multiple key-value pairs at once.

        Args:
            mapping: Dictionary of key-value pairs

        Returns:
            True if successful
        """
        try:
            processed_mapping = {}
            for key, value in mapping.items():
                if isinstance(value, (str, int, float)):
                    processed_mapping[key] = value
                else:
                    processed_mapping[key] = json.dumps(value)

            return self.redis.mset(processed_mapping)
        except Exception as e:
            print(f"Error setting multiple keys: {e}")
            return False

    def flush_db(self) -> bool:
        """
        Clear all keys from the current database.

        Returns:
            True if successful
        """
        try:
            return self.redis.flushdb()
        except Exception as e:
            print(f"Error flushing database: {e}")
            return False

    def ping(self) -> bool:
        """
        Test Redis connection.

        Returns:
            True if connection is alive
        """
        try:
            return self.redis.ping()
        except Exception as e:
            print(f"Error pinging Redis: {e}")
            return False

    def get_usage_stats(self, key_pattern: str) -> Dict[str, int]:
        """
        Get usage statistics for keys matching a pattern.
        Useful for monitoring usage counts like in your original code.

        Args:
            key_pattern: Pattern to match keys

        Returns:
            Dictionary mapping keys to their integer values
        """
        try:
            keys = self.keys(key_pattern)
            usage_map = {}

            for key in keys:
                value = self.get(key, 0)
                usage_map[key] = int(value) if isinstance(value, (int, str)) else 0

            return usage_map
        except Exception as e:
            print(f"Error getting usage stats for pattern {key_pattern}: {e}")
            return {}

    def close(self):
        """Close Redis connection."""
        if self._redis:
            self._redis.close()
            self._redis = None

    def create_namespaced_key(self, namespace: str, *parts: str) -> str:
        """
        Create a namespaced key similar to your _get_key method.

        Args:
            namespace: Namespace prefix
            parts: Key parts to join

        Returns:
            Formatted key string
        """
        return f"{namespace}_{'_'.join(parts)}"
