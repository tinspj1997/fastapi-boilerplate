# from langchain.prompts import PromptTemplate
from typing import Any


def qa_excel_table(llm: Any, prompt, table_data: str, query) -> str:
    llm_chain = prompt | llm
    response = llm_chain.invoke({"input": query, "table_data": table_data})
    return response
