"""
This module provides Elasticsearch-based retrieval functionality with support for vector and hybrid searches.
It implements a retriever class that can perform semantic searches using embeddings and traditional text searches.
"""

from langchain_elasticsearch import ElasticsearchRetriever
from elasticsearch import Elasticsearch
from typing import List, Optional, Any, Dict, Literal, Union, Generator
from dataclasses import dataclass, field
from langchain_core.documents import Document

QueryType = Literal["vector", "hybrid"]


@dataclass(slots=True)
class ElasticRetriever:
    """
    A retriever class that interfaces with Elasticsearch for document retrieval.

    This class supports both vector-based and hybrid (vector + text) search strategies,
    with configurable filtering and scoring mechanisms.

    Attributes:
        host (str): Elasticsearch host URL. Defaults to "http://localhost:9200".
        username (Optional[str]): Username for Elasticsearch authentication.
        password (Optional[str]): Password for Elasticsearch authentication.
        embedding_model (Optional[Any]): Model used to generate embeddings for vector search.
        _client (Elasticsearch): Internal Elasticsearch client instance.
        _retriever (Union[ElasticsearchRetriever, None]): Internal LangChain Elasticsearch retriever.
    """

    host: str = "http://localhost:9200"
    username: Optional[str] = None
    password: Optional[str] = None
    embedding_model: Optional[Any] = None
    _client: Elasticsearch = field(init=False)
    _retriever: Union[ElasticsearchRetriever, None] = None

    def __post_init__(self):
        """
        Initializes the Elasticsearch client after instance creation.
        Sets up authentication if credentials are provided.
        """
        if self.username and self.password:
            self._client = Elasticsearch(
                self.host, basic_auth=(self.username, self.password), verify_certs=False
            )
        else:
            self._client = Elasticsearch(self.host, verify_certs=False)

    @property
    def client(self) -> Elasticsearch:
        """
        Returns the internal Elasticsearch client instance.

        Returns:
            Elasticsearch: The configured Elasticsearch client.
        """
        return self._client

    def normalize_score(self, score: float, max_score: float = 10.0) -> float:
        """
        Normalize a single score to the range [0, 1].

        Args:
            score (float): The score to normalize.
            max_score (float): The maximum possible score for normalization. Defaults to 10.0.

        Returns:
            float: The normalized score between 0 and 1.
        """
        if not isinstance(score, (float, int)):
            return score
        if 0.0 <= score <= 1.0:
            return float(score)
        return min(float(score) / max_score, 1.0)

    def vector_query(
        self, search_query: str, k: int, num_candidates: int, filters: dict = {}
    ) -> Dict:
        """
        Constructs a vector-based search query for Elasticsearch.

        Args:
            search_query (str): The search query to embed and search for.
            k (int): Number of results to return.
            num_candidates (int): Number of initial candidates to consider.
            filters (dict): Metadata filters to apply to the search.

        Returns:
            Dict: Elasticsearch query body for vector search.

        Raises:
            ValueError: If no embedding model is configured.
        """
        if not self.embedding_model:
            raise ValueError("Embedding model is required for vector search.")
        vector = self.embedding_model.embed_query(search_query)

        knn_config = {
            "field": "vector",
            "query_vector": vector,
            "k": k,
            "num_candidates": min(num_candidates or 10 * k, 9999),
        }

        # Add filters directly to KNN if they exist
        if filters:
            knn_config["filter"] = self.build_metadata_filters(filters)

        body = {"_source": {"excludes": ["vector"]}, "size": k, "knn": knn_config}

        return body

    def hybrid_query(
        self, search_query: str, k: int, num_candidates: int, filters: dict = {}
    ) -> Dict:
        """
        Constructs a hybrid search query combining vector search with text matching.

        Args:
            search_query (str): The search query to embed and search for.
            k (int): Number of results to return.
            num_candidates (int): Number of initial candidates to consider.
            filters (dict): Metadata filters to apply to the search.

        Returns:
            Dict: Elasticsearch query body for hybrid search.

        Raises:
            ValueError: If no embedding model is configured.
        """
        if not self.embedding_model:
            raise ValueError("Embedding model is required for vector search.")
        vector = self.embedding_model.embed_query(search_query)

        query_config = {
            "bool": {
                "must": [{"multi_match": {"query": search_query, "fields": ["text"]}}]
            }
        }

        knn_config = {
            "field": "vector",
            "query_vector": vector,
            "k": k,
            "num_candidates": min(num_candidates or 10 * k, 9999),
        }

        # Apply filters to both query and knn if they exist
        if filters:
            filter_clauses = self.build_metadata_filters(filters)
            query_config["bool"]["filter"] = filter_clauses
            knn_config["filter"] = filter_clauses

        return {
            "_source": {"excludes": ["vector"]},
            "size": k,
            "query": query_config,
            "knn": knn_config,
        }

    def build_metadata_filters(self, filters: dict) -> list:
        """
        Convert a dict of filters into Elasticsearch filter clauses targeting metadata fields.

        Args:
        filters (dict): Either:
                - Flat metadata filters (e.g. { "doc_id": 101, "page": [1, 2, 3] })
                - Or raw ES bool filters (e.g. { "bool": { "must": [...], ... } })

        Returns:
            list: Elasticsearch-compatible `term` or `terms` filter clauses.
        """
            # Pass through full bool clause
        if not filters:
            return []
        
        if "bool" in filters:
            return filters
        
        clauses = []
        for key, value in filters.items():
            field = f"metadata.{key.strip()}"
            if isinstance(value, list) and value:
                clauses.append({"terms": {field: value}})
            elif isinstance(value, (str, int, float, bool)):
                clauses.append({"term": {field: value}})
        return clauses

    def configure_retriever(
        self,
        index_name: str,
        filters: Optional[Dict[str, Any]] = {},
        query_type: QueryType = "vector",
        k: int = 5,
        num_candidates: Optional[int] = None,
    ) -> None:
        """
        Configures the internal Elasticsearch retriever with specified settings.

        Args:
            index_name (str): Name of the Elasticsearch index to search.
            filters (Optional[Dict[str, Any]]): Metadata filters to apply to searches.
            query_type (QueryType): Type of search to perform ("vector" or "hybrid").
            k (int): Number of results to return.
            num_candidates (Optional[int]): Number of initial candidates to consider.
        """
        filters = filters or {}

        def body_func(search_query: str) -> dict:
            body = getattr(self, f"{query_type}_query")(
                search_query,
                k=k,
                num_candidates=min(num_candidates or 10 * k, 9999),
                filters=filters,
            )
            return body

        self._retriever = ElasticsearchRetriever(
            index_name=index_name,
            body_func=body_func,
            es_client=self.client,
            content_field="text",
        )

    def get_retriever(self) -> Optional[ElasticsearchRetriever]:
        """
        Returns the configured Elasticsearch retriever.

        Returns:
            Optional[ElasticsearchRetriever]: The configured retriever or None if not configured.
        """
        return self._retriever

    def get_matching_documents(
        self,
        query: str,
        score_threshold: Union[float, None] = None,
        normalize_score: bool = True,
        required_metadata: Optional[List[str]] = None,
    ):
        """
        Retrieves matching documents for the given query.

        Args:
            query (str): The search query.
            score_threshold (Union[float, None]): Minimum score threshold for returned documents.
            normalize_score (bool): Whether to normalize the scores to [0,1] range.

        Returns:
            list: List of matching documents with their scores.

        Raises:
            AttributeError: If retriever is not configured (None).
        """
        if self._retriever is None:
            raise AttributeError(
                "Retriever is not configured. Call configure_retriever first."
            )

        documents = self._retriever.invoke(query)

        if not documents:
            return []

        filtered_docs = []
        first_doc_score = documents[0].metadata.get("_score", 0.0)
        highest_score = first_doc_score if first_doc_score > 0 else 1.0
        
        for doc in documents:
            original_score = doc.metadata.get("_score", 0.0)
            score = (
                self.normalize_score(original_score, highest_score)
                if normalize_score and highest_score > 0
                else original_score
            )

            if score_threshold is not None and score < score_threshold:
                continue

            if required_metadata:
                # Extract from nested metadata only
                nested_meta = doc.metadata.get("_source", {}).get("metadata", {})
                doc.metadata = {
                    "_score": score,
                    **{
                        key: nested_meta.get(key)
                        for key in required_metadata
                        if key in nested_meta
                    },
                }
            else:
                # Preserve full metadata and just update _score
                doc.metadata["_score"] = score

            filtered_docs.append(doc)

        return filtered_docs

    def clean_es_docs(
        self, docs: List[Dict[str, Any]], required_metadata: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Transforms raw Elasticsearch documents into simplified format:
        {
            "page_content": <text>,
            "metadata": { filtered metadata }
        }

        Args:
            docs (List[Dict[str, Any]]): List of Elasticsearch documents from hits.
            required_metadata (Optional[List[str]]): Metadata keys to retain. If None, all are retained.

        Returns:
            List[Dict[str, Any]]: Simplified document structure.
        """
        cleaned = []
        for doc in docs:
            source = doc.get("_source", {})
            metadata = source.get("metadata", {})

            if required_metadata is not None:
                metadata = {
                    key: metadata.get(key)
                    for key in required_metadata
                    if key in metadata
                }

            cleaned.append(
                {"page_content": source.get("text", ""), "metadata": metadata}
            )

        return cleaned

    def delete_documents(self, index_name: str, filters: dict) -> Any:
        """
        Deletes documents from the specified Elasticsearch index that match the given metadata filters.

        Args:
            index_name (str): The name of the Elasticsearch index.
            filters (dict): Key-value pairs to filter documents for deletion.

        Returns:
            Any: The response from Elasticsearch's delete_by_query API.
        """
        if not filters or not isinstance(filters, dict):
            raise ValueError("Filters must be a non-empty dictionary.")
        if (
            not isinstance(index_name, str)
            or not index_name.strip()
            or not self.client.indices.exists(index=index_name)
        ):
            raise ValueError(f"Index '{index_name}' does not exist or is invalid.")

        filter_clauses = self.build_metadata_filters(filters)
        query = {"bool": {"filter": filter_clauses}}
        body = {"query": query}
        response = self.client.delete_by_query(index=index_name, body=body)
        return response

    def scroll_documents(
        self,
        index_name: str,
        filters: Dict[str, Any],
        scroll_timeout: str = "2m",
        batch_size: int = 1000,
        required_metadata: Optional[List[str]] = None,
    ) -> Generator[Dict[str, Any], None, None]:
        """
        Iterates through all documents in the specified Elasticsearch index that match the provided metadata filters,
        using Elasticsearch's scroll API. This is intended for retrieving large datasets in a memory-efficient way.

        Args:
            index_name (str): The name of the Elasticsearch index to query.
            filters (Dict[str, Any]): Dictionary of metadata filters used to match documents.
            scroll_timeout (str, optional): Duration the scroll context is maintained on the server. Defaults to "2m".
            batch_size (int, optional): Number of documents to retrieve per scroll batch. Defaults to 1000.
            required_metadata (Optional[List[str]]): Specific metadata fields to retain. If None, all metadata is returned.

        Yields:
            Dict[str, Any]: Each document is a dictionary containing:
                - "page_content": The document's textual content from `_source.text`.
                - "metadata": Filtered metadata dictionary from `_source.metadata`, as per `required_metadata`.

        Raises:
            ValueError: If `filters` is empty or not a dictionary.
            ValueError: If `index_name` is missing or invalid.
            ValueError: If the Elasticsearch client is not initialized.

        Note:
            Recommended when retrieving more than ~10,000 documents, or when consistent snapshot-style retrieval is needed.
            For smaller, quick lookups (<10,000), prefer `search_documents()` for faster performance and lower overhead.
        """
        if not filters or not isinstance(filters, dict):
            raise ValueError("Filters must be a non-empty dictionary.")
        if (
            not isinstance(index_name, str)
            or not index_name.strip()
            or not self.client.indices.exists(index=index_name)
        ):
            raise ValueError(f"Index '{index_name}' does not exist or is invalid.")
        if not self.client:
            raise ValueError("Elasticsearch client is not initialized.")

        query = {"bool": {"filter": self.build_metadata_filters(filters)}}

        body = {"_source": {"excludes": ["vector"]}, "query": query}

        response = self.client.search(
            index=index_name, scroll=scroll_timeout, size=batch_size, body=body
        )

        scroll_id = response.get("_scroll_id")
        hits = response["hits"]["hits"]

        try:
            while hits:
                cleaned_docs = self.clean_es_docs(hits, required_metadata)
                for doc in cleaned_docs:
                    yield doc
                response = self.client.scroll(
                    scroll_id=scroll_id, scroll=scroll_timeout
                )
                scroll_id = response.get("_scroll_id")
                hits = response["hits"]["hits"]
        finally:
            if scroll_id:
                self.client.clear_scroll(scroll_id=scroll_id)

    def search_documents(
        self,
        index_name: str,
        filters: Optional[Dict[str, Any]] = None,
        size: Optional[int] = 1000,
        required_metadata: Optional[List[str]] = None,
        custom_query: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Fetches up to `size` documents from the specified Elasticsearch index that match the given metadata filters.
        Uses the standard Elasticsearch search API, which is stateless and returns fresh data at query time.

        Args:
            index_name (str): The name of the Elasticsearch index to search.
            filters (Dict[str, Any]): Dictionary of metadata filters used to match documents.
            size (int, optional): Maximum number of documents to retrieve. Defaults to 1000.
            required_metadata (Optional[List[str]]): Specific metadata fields to retain. If None, all metadata is returned.

        Returns:
            List[Dict[str, Any]]: A list of matching documents, each containing:
                - "page_content": the document's text content.
                - "metadata": filtered metadata dictionary as per `required_metadata`.

        Raises:
            ValueError: If `filters` is empty or not a dictionary.
            ValueError: If `index_name` is missing or invalid.
            ValueError: If the Elasticsearch client is not initialized.

        Note:
            Ideal for quick retrieval of up to ~10,000 documents.
            For larger or paginated results, use `scroll_documents()` instead.
        """
        if not self.client:
            raise ValueError("Elasticsearch client is not initialized.")
        if (
            not isinstance(index_name, str)
            or not index_name.strip()
            or not self.client.indices.exists(index=index_name.strip())
        ):
            raise ValueError(f"Index '{index_name}' does not exist or is invalid.")

        if filters:  
            query = {"bool": {"filter": self.build_metadata_filters(filters)}}

            body = {"query": query, "_source": {"excludes": ["vector"]}, "size": size}
        elif custom_query:
            body = custom_query
        else:
            raise ValueError(
                "Either filters or custom_query must be provided for search."
            )
        response = self.client.search(index=index_name, body=body)
        hits = response["hits"]["hits"]

        return self.clean_es_docs(hits, required_metadata)

    def is_index_exists(self, index_name: str) -> bool:
        return self._client.indices.exists(index=index_name)

    def search_documents_all_with_vectors(
        self,
        index_name: str,
        filters: dict,
        required_metadata: list = None,
        page_size: int = 200
    ) -> list:
        """
        Fetch all documents matching filters from Elasticsearch using search_after,
        keeping vectors for clustering.

        Args:
            client: Elasticsearch client instance
            index_name (str): Name of the index
            filters (dict): Metadata filters to match (e.g., {"metadata.doc_id": 2835})
            required_metadata (list, optional): List of metadata keys to keep. Defaults to None.
            page_size (int, optional): Number of documents per page. Defaults to 200.

        Returns:
            list: List of Document objects with page_content, metadata, and vector.
        """
        if not self.client:
            raise ValueError("Elasticsearch client is not initialized.")
        if not index_name or not self.client.indices.exists(index=index_name):
            raise ValueError(f"Index '{index_name}' does not exist.")

        all_docs = []
        search_after = None

        while True:
            body = {
                "size": page_size,
                "query": {
                    "bool": {
                        "must": [{"match_all": {}}],
                        "filter": [{"term": {k: v}} for k, v in filters.items()],
                    }
                },
                "sort": ["_doc"]
            }

            if search_after:
                body["search_after"] = search_after

            resp = self.client.search(index=index_name, body=body)
            hits = resp["hits"]["hits"]

            if not hits:
                break

            for hit in hits:
                # Prepare metadata
                metadata = {"_id": hit["_id"]}
                if required_metadata:
                    metadata.update(
                        {
                            k: hit["_source"]["metadata"].get(k) for k in required_metadata
                        }
                    )
                else:
                    metadata.update(hit["_source"]["metadata"])

                # Put vector inside metadata
                metadata["vector"] = hit["_source"].get("vector")

                doc_content = hit["_source"].get("text", "")
                all_docs.append(
                    Document(page_content=doc_content, metadata=metadata)
                )

            search_after = hits[-1]["sort"]

        return all_docs