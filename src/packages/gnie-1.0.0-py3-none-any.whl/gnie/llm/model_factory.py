"""Module for creating and managing LLM model clients."""

from typing import Dict, List, Optional
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from gnie.schema.llm import LLMModel
from gnie.core.security import decrypt


class ModelFactory:
    """Factory class for creating and managing LLM model clients."""
    
    def __init__(self) -> None:
        """Initialize the ModelFactory with an empty client dictionary."""
        self._initialized_clients: Dict[str, object] = {}

    def create_model_client(self, config: LLMModel, fernet_key: Optional[str] = None) -> object:
        """Create a model client based on the provided configuration.

        Args:
            config: LLMModel configuration object
            fernet_key: Optional encryption key for decrypting API keys

        Returns:
            The initialized model client

        Raises:
            ValueError: If provider or model type is not supported, or if there's an error creating the client
        """
        # Validate the configuration
        validated_config = LLMModel.model_validate(config)
        
        # Decrypt API key if encryption key is provided
        if fernet_key:
            validated_config.api_key = decrypt(validated_config.api_key, fernet_key)
        
        try:
            provider = validated_config.provider.lower()
            model_type = validated_config.model_type.lower()
            
            if provider == "azure":
                if model_type == "llm":
                    return AzureChatOpenAI(
                        azure_endpoint=validated_config.endpoint,
                        azure_deployment=validated_config.model_name,
                        api_key=validated_config.api_key,
                        api_version=validated_config.version,
                        timeout=(30,390)
                    )
                elif model_type == "embedding":
                    return AzureOpenAIEmbeddings(
                        azure_endpoint=validated_config.endpoint,
                        azure_deployment=validated_config.model_name,
                        api_key=validated_config.api_key,
                        api_version=validated_config.version,
                        dimensions=3072,
                    )
                else:
                    raise ValueError(f"Unsupported model type for Azure: {validated_config.model_type}")
            else:
                raise ValueError(f"Unsupported provider: {validated_config.provider}")
                
        except Exception as e:
            raise ValueError(f"Error creating model client: {e}") from e

    def initialize_model_clients(
        self, 
        subscriptions: List[LLMModel], 
        fernet_key: Optional[str] = None
    ) -> Dict[str, object]:
        """Initialize multiple model clients from a list of configurations.

        Args:
            subscriptions: List of LLMModel configurations
            fernet_key: Optional encryption key for decrypting API keys

        Returns:
            Dictionary mapping subscription IDs to initialized clients
        """
        validated_subscriptions = [LLMModel.model_validate(sub) for sub in subscriptions]
        
        for subscription in validated_subscriptions:
            self._initialized_clients[subscription.id] = self.create_model_client(
                subscription, 
                fernet_key
            )
        return self._initialized_clients
        

    