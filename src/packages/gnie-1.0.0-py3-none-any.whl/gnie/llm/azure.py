from langchain_openai import AzureChatOpenAI as CoreAzureChatOpenAI
from gnie.llm.base import LLMBase
from typing import Self


class AzureChatOpenAI(LLMBase):
    def __init__(self, **kwargs) -> Self:
        self.client = CoreAzureChatOpenAI(**kwargs)
