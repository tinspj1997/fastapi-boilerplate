from typing import (
    Any,
    AsyncIterator,
    Iterator,
    Union,
)
from gnie.prompt.base import Prompt


class LLMBase(Prompt):
    """Base class for Large Language Model implementations.

    This abstract class provides a common interface for different LLM providers
    and implementations. It handles both synchronous and asynchronous interactions,
    streaming capabilities, and structured output generation.
    """

    client = None

    def __call__(self, *args, **kwargs) -> Any:
        """Return the underlying LLM client instance.

        Returns:
            Any: The LLM client instance
        """
        return self.client

    def invoke(self, prompt: str, stream: bool = False) -> Union[str, Iterator[str]]:
        """Invoke the LLM with a prompt and get a response.

        Args:
            prompt: The input prompt text
            stream: If True, return a streaming response

        Returns:
            Union[str, Iterator[str]]: The model's response as text or stream

        Raises:
            ValueError: If the prompt is empty
        """
        if len(prompt.strip()) == 0:
            raise ValueError("cannot process empty prompt")

        if stream:
            return self.client.stream(prompt)

        return self.client.invoke(prompt)

    async def ainvoke(
        self, prompt: str, stream: bool = False
    ) -> Union[str, AsyncIterator[str]]:
        """Asynchronously invoke the LLM with a prompt.

        Args:
            prompt: The input prompt text
            stream: If True, return a streaming response

        Returns:
            Union[str, AsyncIterator[str]]: The model's response as text or async stream

        Raises:
            ValueError: If the prompt is empty
        """
        if len(prompt.strip()) == 0:
            raise ValueError("cannot process empty prompt")

        if stream:
            return self.client.astream(prompt)

        return await self.client.ainvoke(prompt)

    def invoke_structured_output(
        self,
        prompt: str,
        structured_class: Any,
        stream: bool = False,
        method: str = "function_calling",
    ):
        """Invoke the LLM and get a structured response based on a Pydantic model.

        Args:
            prompt: The input prompt text
            structured_class: A Pydantic model class defining the output structure
            stream: If True, return a streaming response
            method: Method for structured output generation ("function_calling" or "json_schema")

        Returns:
            Union[T, Iterator[Union[str, T]]]: The structured response or stream

        Raises:
            ValueError: If the prompt is empty
        """
        if len(prompt.strip()) == 0:
            raise ValueError("cannot process empty prompt")

        structured_llm = self.client.with_structured_output(
            structured_class, method=method
        )

        if stream:
            return structured_llm.stream(prompt)

        return structured_llm.invoke(prompt)

    async def ainvoke_structured_output(
        self,
        prompt: str,
        structured_class: Any,
        stream: bool = False,
        method: str = "function_calling",
    ) -> Union[str, Iterator[str]]:
        """Asynchronously invoke the LLM and get a structured response.

        Args:
            prompt: The input prompt text
            structured_class: A Pydantic model class defining the output structure
            stream: If True, return a streaming response
            method: Method for structured output generation ("function_calling" or "json_schema")

        Returns:
            Union[T, AsyncIterator[Union[str, T]]]: The structured response or async stream

        Raises:
            ValueError: If the prompt is empty
        """
        if len(prompt.strip()) == 0:
            raise ValueError("cannot process empty prompt")

        structured_llm = self.client.with_structured_output(
            structured_class, method=method
        )

        if stream:
            return structured_llm.astream(prompt)

        return await structured_llm.ainvoke(prompt)
