from pathlib import Path
from typing import List, Optional, Dict, Any
from langchain.schema import Document


def extract_content(
    file_path: str, encoding: str = "utf-8", metadata: Optional[Dict[str, Any]] = None
) -> List[Document]:
    """Load and process text documents from a file.

    Args:
        file_path: Path to the text file
        encoding: File encoding to use (default: utf-8)
        metadata: Additional metadata to merge with default metadata

    Returns:
        List of Document objects containing file content and metadata
    """
    # Convert to Path object
    path = Path(file_path).absolute()

    # Prepare metadata
    default_metadata = {
        "source": str(path),
        "size_bytes": path.stat().st_size,
        "last_modified": str(path.stat().st_mtime),
    }
    merged_metadata = {**default_metadata, **(metadata or {})}

    # Read file content
    with open(file_path, "r", encoding=encoding) as f:
        text = f.read()

    return [Document(page_content=text, metadata=merged_metadata)]
