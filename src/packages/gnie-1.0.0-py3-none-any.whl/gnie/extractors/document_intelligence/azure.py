import asyncio
import sys
import time
import weakref
from contextlib import asynccontextmanager
from pathlib import Path
from typing import (
    Any,
    AsyncGenerator,
    AsyncIterator,
    Dict,
    List,
    Optional,
    Tuple,
    Union,
)

import aiofiles
from azure.ai.documentintelligence.aio import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ResourceNotFoundError,
    ServiceRequestError,
)

from gnie.schema.document_intelligence import (
    AnalysisConfig,
    AnalysisResult,
    DocumentInput,
    OutputFormat,
    ContentType,
)


class RateLimiter:
    """Token bucket rate limiter for Azure Document Intelligence (15 TPS)."""

    def __init__(self, rate: float = 15.0, capacity: int = 30):
        """
        Initialize rate limiter.

        Args:
            rate: Tokens per second (Azure DI limit is 15 TPS)
            capacity: Maximum tokens in bucket
        """
        self._rate = rate
        self._capacity = capacity
        self._tokens = capacity
        self._last_update = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self, tokens: int = 1) -> None:
        """Acquire tokens, blocking if necessary."""
        async with self._lock:
            now = time.monotonic()
            # Add tokens based on elapsed time
            elapsed = now - self._last_update
            self._tokens = min(self._capacity, self._tokens + elapsed * self._rate)
            self._last_update = now

            # If not enough tokens, wait
            if self._tokens < tokens:
                wait_time = (tokens - self._tokens) / self._rate
                await asyncio.sleep(wait_time)
                self._tokens = 0
            else:
                self._tokens -= tokens


class ConnectionPool:
    """Connection pool for Document Intelligence clients."""

    def __init__(
        self, endpoint: str, credential: AzureKeyCredential, pool_size: int = 10
    ):
        self._endpoint = endpoint
        self._credential = credential
        self._pool_size = pool_size
        self._available_clients: asyncio.Queue = asyncio.Queue(maxsize=pool_size)
        self._all_clients: weakref.WeakSet = weakref.WeakSet()
        self._initialized = False
        self._lock = asyncio.Lock()

    async def _initialize_pool(self):
        """Initialize the connection pool."""
        if self._initialized:
            return

        async with self._lock:
            if self._initialized:
                return

            for _ in range(self._pool_size):
                client = DocumentIntelligenceClient(
                    endpoint=self._endpoint, credential=self._credential
                )
                self._all_clients.add(client)
                await self._available_clients.put(client)

            self._initialized = True

    @asynccontextmanager
    async def get_client(self) -> AsyncGenerator[DocumentIntelligenceClient, None]:
        """Get a client from the pool."""
        await self._initialize_pool()

        try:
            # Try to get a client without blocking
            client = self._available_clients.get_nowait()
        except asyncio.QueueEmpty:
            # If no clients available, wait for one
            client = await self._available_clients.get()

        try:
            yield client
        finally:
            # Return client to pool
            try:
                self._available_clients.put_nowait(client)
            except asyncio.QueueFull:
                # Pool is full, this shouldn't happen but handle gracefully
                pass

    async def close_all(self):
        """Close all clients in the pool."""
        # Close all available clients
        while not self._available_clients.empty():
            try:
                client = self._available_clients.get_nowait()
                await client.close()
            except asyncio.QueueEmpty:
                break

        # Close any remaining clients
        for client in self._all_clients:
            try:
                await client.close()
            except:
                pass


class DocumentIntelligenceAnalyzer:
    """Azure Document Intelligence analyzer"""

    def __init__(
        self,
        endpoint: str,
        credential: Union[str, AzureKeyCredential],
        model_id: str = "prebuilt-layout",
        max_retries: int = 3,
        timeout_seconds: int = 300,
        config: Optional[AnalysisConfig] = None,
        max_concurrency: int = 15,
        connection_pool_size: int = 10,
    ):
        """
        Initialize the Document Intelligence Analyzer.

        Args:
            endpoint: Azure Document Intelligence endpoint URL
            credential: API key string or AzureKeyCredential instance
            model_id: Model ID to use for analysis (backward compatibility)
            max_retries: Maximum number of retry attempts (backward compatibility)
            timeout_seconds: Timeout for analysis operations (backward compatibility)
            config: Analysis configuration (overrides individual parameters if provided)
            max_concurrency: Maximum concurrent operations (should not exceed rate limit)
            connection_pool_size: Size of connection pool
        """
        self._credential = (
            credential
            if isinstance(credential, AzureKeyCredential)
            else AzureKeyCredential(credential)
        )

        # Handle configuration: use provided config or create from individual parameters
        if config is not None:
            self._config = config
        else:
            self._config = AnalysisConfig(
                model_id=model_id,
                max_retries=max_retries,
                timeout_seconds=timeout_seconds,
            )

        self._max_concurrency = min(max_concurrency, 15)  # Azure DI rate limit

        # Rate limiter and connection pool
        self._rate_limiter = RateLimiter(rate=15.0, capacity=30)
        self._connection_pool = ConnectionPool(
            endpoint, self._credential, connection_pool_size
        )
        self._semaphore = asyncio.Semaphore(self._max_concurrency)

        # Resource cleanup tracking
        self._closed = False

    def _validate_file_path(self, file_path: Union[str, Path]) -> Path:
        """Validate and convert file path."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        if not path.is_file():
            raise ValueError(f"Path is not a file: {file_path}")
        if path.stat().st_size == 0:
            raise ValueError(f"File is empty: {file_path}")
        return path

    def _validate_pages(
        self, pages: Optional[Union[int, str, List[int]]]
    ) -> Optional[str]:
        """Validate and format page specification."""
        if pages is None:
            return None

        if isinstance(pages, int):
            if pages < 1:
                raise ValueError("Page numbers must be >= 1")
            return str(pages)
        elif isinstance(pages, str):
            if not pages.strip():
                return None
            return pages.strip()
        elif isinstance(pages, list):
            if not pages:
                return None
            if any(not isinstance(p, int) or p < 1 for p in pages):
                raise ValueError("All page numbers must be integers >= 1")
            return ",".join(map(str, sorted(set(pages))))  # Remove duplicates and sort
        else:
            raise TypeError("Pages must be int, str, or list of ints")

    def _calculate_backoff_time(self, attempt: int) -> float:
        """Calculate exponential backoff time with jitter."""
        base_delay = min(
            self._config.exponential_backoff_base**attempt,
            self._config.max_backoff_seconds,
        )
        # Add jitter to prevent thundering herd
        import random

        jitter = random.uniform(0.1, 0.3) * base_delay
        return base_delay + jitter

    async def _read_file_efficiently(self, file_path: Path) -> bytes:
        """Read file with efficient memory usage."""
        file_size = file_path.stat().st_size

        # For large files, consider streaming or chunked reading
        if file_size > 400 * 1024 * 1024:  # 400MB
            raise ValueError(
                f"File too large: {file_size} bytes. Consider splitting the document."
            )

        async with aiofiles.open(file_path, "rb") as f:
            return await f.read()

    async def analyze_document(
        self,
        file_path: Union[str, Path],
        pages: Optional[Union[int, str, List[int]]] = None,
        config_override: Optional[AnalysisConfig] = None,
        index: Optional[int] = None,
    ) -> AnalysisResult:
        """
        Analyze a single document.

        Args:
            file_path: Path to the document file
            pages: Page specification (int, str, or list of ints)
            config_override: Override default configuration
            index: Optional index for tracking order in batch operations

        Returns:
            AnalysisResult: The analysis result with metadata
        """
        if self._closed:
            raise RuntimeError("Analyzer has been closed")

        config = config_override or self._config
        validated_path = self._validate_file_path(file_path)
        validated_pages = self._validate_pages(pages)

        start_time = time.monotonic()
        result = AnalysisResult(
            file_path=str(file_path), index=index, pages_analyzed=validated_pages
        )

        for attempt in range(config.max_retries + 1):
            try:
                # Rate limiting
                await self._rate_limiter.acquire()

                # Get client from pool
                async with self._connection_pool.get_client() as client:
                    # Read file efficiently
                    file_content = await self._read_file_efficiently(validated_path)

                    analyze_params = {
                        "model_id": config.model_id,
                        "body": file_content,
                        "content_type": config.content_type.value,
                        "output_content_format": config.output_format.value,
                    }

                    if validated_pages:
                        analyze_params["pages"] = validated_pages

                    poller = await client.begin_analyze_document(**analyze_params)

                    try:
                        analysis_result = await asyncio.wait_for(
                            poller.result(), timeout=config.timeout_seconds
                        )
                        result.result = analysis_result
                        result.processing_time = time.monotonic() - start_time
                        return result

                    except asyncio.TimeoutError:
                        error = TimeoutError(
                            f"Analysis timed out after {config.timeout_seconds} seconds"
                        )
                        if attempt == config.max_retries:
                            result.error = error
                            result.retry_count = attempt
                            result.processing_time = time.monotonic() - start_time
                            return result
                        # Continue to retry

            except (ClientAuthenticationError, ResourceNotFoundError) as e:
                # These are non-retryable errors
                result.error = RuntimeError(f"Authentication or resource error: {e}")
                result.retry_count = attempt
                result.processing_time = time.monotonic() - start_time
                return result

            except (ServiceRequestError, HttpResponseError) as e:
                if attempt < config.max_retries:
                    wait_time = self._calculate_backoff_time(attempt)
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    result.error = RuntimeError(
                        f"Service error after {config.max_retries + 1} attempts: {e}"
                    )
                    result.retry_count = attempt
                    result.processing_time = time.monotonic() - start_time
                    return result

            except Exception as e:
                result.error = RuntimeError(f"Unexpected error: {e}")
                result.retry_count = attempt
                result.processing_time = time.monotonic() - start_time
                return result

        result.error = RuntimeError("Analysis failed for unknown reason")
        result.retry_count = config.max_retries
        result.processing_time = time.monotonic() - start_time
        return result

    async def analyze_documents_stream(
        self,
        file_paths: List[Union[str, Path]],
        pages: Optional[Union[int, str, List[int]]] = None,
        config_override: Optional[AnalysisConfig] = None,
        preserve_order: bool = False,
    ) -> AsyncIterator[AnalysisResult]:
        """
        Analyze multiple documents and yield results as they complete.

        This is an async generator that yields results as soon as they're ready,
        allowing the caller to process results without waiting for all documents.

        Args:
            file_paths: List of file paths to analyze
            pages: Page specification applied to all documents
            config_override: Override default configuration
            preserve_order: If True, yield results in input order (may add latency)

        Yields:
            AnalysisResult objects as they complete
        """
        if self._closed:
            raise RuntimeError("Analyzer has been closed")

        if not file_paths:
            return

        if preserve_order:
            async for result in self._analyze_documents_ordered(
                file_paths, pages, config_override
            ):
                yield result
        else:
            async for result in self._analyze_documents_unordered(
                file_paths, pages, config_override
            ):
                yield result

    async def analyze_documents_with_specs_stream(
        self,
        document_inputs: List[DocumentInput],
        preserve_order: bool = False,
    ) -> AsyncIterator[AnalysisResult]:
        """
        Analyze multiple documents with individual page specifications.

        This method allows different page specifications for each document.

        Args:
            document_inputs: List of DocumentInput objects specifying file and pages
            preserve_order: If True, yield results in input order (may add latency)

        Yields:
            AnalysisResult objects as they complete

        Example:
            >>> inputs = [
            ...     DocumentInput("doc1.pdf", pages="1-3"),
            ...     DocumentInput("doc2.pdf", pages=[1, 5, 10]),
            ...     DocumentInput("doc3.pdf"),  # All pages
            ... ]
            >>> async for result in analyzer.analyze_documents_with_specs_stream(inputs):
            ...     print(f"Analyzed {result.file_path}, pages: {result.pages_analyzed}")
        """
        if self._closed:
            raise RuntimeError("Analyzer has been closed")

        if not document_inputs:
            return

        if preserve_order:
            async for result in self._analyze_documents_with_specs_ordered(
                document_inputs
            ):
                yield result
        else:
            async for result in self._analyze_documents_with_specs_unordered(
                document_inputs
            ):
                yield result

    async def _analyze_documents_with_specs_unordered(
        self,
        document_inputs: List[DocumentInput],
    ) -> AsyncIterator[AnalysisResult]:
        """Yield results with individual specs as soon as they complete."""

        async def _analyze_with_semaphore(
            doc_input: DocumentInput, index: int
        ) -> AnalysisResult:
            async with self._semaphore:
                try:
                    return await self.analyze_document(
                        doc_input.file_path,
                        doc_input.pages,
                        doc_input.config_override,
                        index,
                    )
                except Exception as e:
                    # Return error result instead of raising
                    return AnalysisResult(
                        file_path=str(doc_input.file_path),
                        error=e,
                        index=index,
                        pages_analyzed=self._validate_pages(doc_input.pages),
                    )

        # Create all tasks
        tasks = [
            asyncio.create_task(_analyze_with_semaphore(doc_input, i))
            for i, doc_input in enumerate(document_inputs)
        ]

        # Yield results as they complete
        for coro in asyncio.as_completed(tasks):
            result = await coro
            yield result

    async def _analyze_documents_with_specs_ordered(
        self,
        document_inputs: List[DocumentInput],
    ) -> AsyncIterator[AnalysisResult]:
        """Yield results with individual specs in the same order as input."""
        pending_results: Dict[int, asyncio.Future] = {}
        next_index = 0

        async def _analyze_with_tracking(doc_input: DocumentInput, index: int):
            async with self._semaphore:
                result = await self.analyze_document(
                    doc_input.file_path,
                    doc_input.pages,
                    doc_input.config_override,
                    index,
                )
                return index, result

        # Create tasks
        tasks = [
            asyncio.create_task(_analyze_with_tracking(doc_input, i))
            for i, doc_input in enumerate(document_inputs)
        ]

        # Process results
        pending_tasks = set(tasks)

        while pending_tasks or pending_results:
            # Wait for at least one task to complete
            if pending_tasks:
                done, pending_tasks = await asyncio.wait(
                    pending_tasks, return_when=asyncio.FIRST_COMPLETED
                )

                # Store completed results
                for task in done:
                    idx, result = await task
                    if idx == next_index:
                        # Yield immediately if it's the next expected result
                        yield result
                        next_index += 1

                        # Check if we can yield any pending results
                        while next_index in pending_results:
                            yield pending_results.pop(next_index)
                            next_index += 1
                    else:
                        # Store for later
                        pending_results[idx] = result
            else:
                # All tasks done, yield remaining results in order
                while next_index in pending_results:
                    yield pending_results.pop(next_index)
                    next_index += 1

    async def analyze_documents_with_specs(
        self,
        document_inputs: List[DocumentInput],
    ) -> List[AnalysisResult]:
        """
        Analyze multiple documents with individual page specifications.

        This method collects all results before returning. For streaming results,
        use analyze_documents_with_specs_stream() instead.

        Args:
            document_inputs: List of DocumentInput objects specifying file and pages

        Returns:
            List of AnalysisResult objects

        Example:
            >>> inputs = [
            ...     DocumentInput("doc1.pdf", pages="1-3"),
            ...     DocumentInput("doc2.pdf", pages=[1, 5, 10]),
            ...     DocumentInput("doc3.pdf"),  # All pages
            ... ]
            >>> results = await analyzer.analyze_documents_with_specs(inputs)
        """
        results = []
        async for result in self.analyze_documents_with_specs_stream(document_inputs):
            results.append(result)
        return results

    async def _analyze_documents_unordered(
        self,
        file_paths: List[Union[str, Path]],
        pages: Optional[Union[int, str, List[int]]],
        config_override: Optional[AnalysisConfig],
    ) -> AsyncIterator[AnalysisResult]:
        """Yield results as soon as they complete, regardless of order."""

        async def _analyze_with_semaphore(
            file_path: Union[str, Path], index: int
        ) -> AnalysisResult:
            async with self._semaphore:
                try:
                    return await self.analyze_document(
                        file_path, pages, config_override, index
                    )
                except Exception as e:
                    # Return error result instead of raising
                    return AnalysisResult(
                        file_path=str(file_path), error=e, index=index
                    )

        # Create all tasks
        tasks = [
            asyncio.create_task(_analyze_with_semaphore(fp, i))
            for i, fp in enumerate(file_paths)
        ]

        # Yield results as they complete
        for coro in asyncio.as_completed(tasks):
            result = await coro
            yield result

    async def _analyze_documents_ordered(
        self,
        file_paths: List[Union[str, Path]],
        pages: Optional[Union[int, str, List[int]]],
        config_override: Optional[AnalysisConfig],
    ) -> AsyncIterator[AnalysisResult]:
        """Yield results in the same order as input files."""
        # Use a queue to manage ordered results
        pending_results: Dict[int, asyncio.Future] = {}
        next_index = 0

        async def _analyze_with_tracking(file_path: Union[str, Path], index: int):
            async with self._semaphore:
                result = await self.analyze_document(
                    file_path, pages, config_override, index
                )
                return index, result

        # Create tasks
        tasks = [
            asyncio.create_task(_analyze_with_tracking(fp, i))
            for i, fp in enumerate(file_paths)
        ]

        # Process results
        pending_tasks = set(tasks)

        while pending_tasks or pending_results:
            # Wait for at least one task to complete
            if pending_tasks:
                done, pending_tasks = await asyncio.wait(
                    pending_tasks, return_when=asyncio.FIRST_COMPLETED
                )

                # Store completed results
                for task in done:
                    idx, result = await task
                    if idx == next_index:
                        # Yield immediately if it's the next expected result
                        yield result
                        next_index += 1

                        # Check if we can yield any pending results
                        while next_index in pending_results:
                            yield pending_results.pop(next_index)
                            next_index += 1
                    else:
                        # Store for later
                        pending_results[idx] = result
            else:
                # All tasks done, yield remaining results in order
                while next_index in pending_results:
                    yield pending_results.pop(next_index)
                    next_index += 1

    async def analyze_documents(
        self,
        file_paths: List[Union[str, Path]],
        pages: Optional[Union[int, str, List[int]]] = None,
        config_override: Optional[AnalysisConfig] = None,
    ) -> List[AnalysisResult]:
        """
        Analyze multiple documents and return all results.

        This method collects all results before returning. For streaming results,
        use analyze_documents_stream() instead.

        Args:
            file_paths: List of file paths to analyze
            pages: Page specification applied to all documents
            config_override: Override default configuration

        Returns:
            List of AnalysisResult objects
        """
        results = []
        async for result in self.analyze_documents_stream(
            file_paths, pages, config_override
        ):
            results.append(result)
        return results

    async def get_stats(self) -> Dict[str, Any]:
        """Get analyzer statistics."""
        return {
            "max_concurrency": self._max_concurrency,
            "connection_pool_size": self._connection_pool._pool_size,
            "available_connections": self._connection_pool._available_clients.qsize(),
            "rate_limiter_tokens": self._rate_limiter._tokens,
            "is_closed": self._closed,
        }

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def close(self):
        """Close the analyzer and cleanup resources."""
        if self._closed:
            return

        self._closed = True
        await self._connection_pool.close_all()

    def __del__(self):
        """Cleanup on deletion."""
        if not self._closed and sys.version_info >= (3, 7):
            # Only create cleanup task if event loop is running
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self.close())
            except RuntimeError:
                # No event loop running, can't cleanup async resources
                pass


# Helper function for creating document inputs from various formats
def create_document_inputs(
    specs: Union[
        List[Union[str, Path]],  # Simple list of paths
        List[
            Tuple[Union[str, Path], Optional[Union[int, str, List[int]]]]
        ],  # List of (path, pages) tuples
        Dict[
            Union[str, Path], Optional[Union[int, str, List[int]]]
        ],  # Dict mapping paths to pages
        List[DocumentInput],  # Already formatted
    ],
) -> List[DocumentInput]:
    """
    Helper to create DocumentInput list from various input formats.

    Args:
        specs: Various formats of document specifications

    Returns:
        List of DocumentInput objects

    Examples:
        >>> # Simple list of paths
        >>> inputs = create_document_inputs(["doc1.pdf", "doc2.pdf"])

        >>> # List of tuples
        >>> inputs = create_document_inputs([
        ...     ("doc1.pdf", "1-3"),
        ...     ("doc2.pdf", [1, 5, 10]),
        ...     ("doc3.pdf", None),
        ... ])

        >>> # Dictionary mapping
        >>> inputs = create_document_inputs({
        ...     "doc1.pdf": "1-3",
        ...     "doc2.pdf": [1, 5, 10],
        ...     "doc3.pdf": None,
        ... })
    """
    if not specs:
        return []

    # Already DocumentInput list
    if isinstance(specs, list) and all(isinstance(s, DocumentInput) for s in specs):
        return specs

    # Dictionary format
    if isinstance(specs, dict):
        return [
            DocumentInput(file_path=path, pages=pages) for path, pages in specs.items()
        ]

    # List format
    if isinstance(specs, list):
        # Check if it's a list of tuples
        if all(isinstance(s, tuple) and len(s) == 2 for s in specs):
            return [DocumentInput(file_path=path, pages=pages) for path, pages in specs]

        # Simple list of paths
        return [DocumentInput(file_path=path) for path in specs]

    raise TypeError(f"Unsupported input format: {type(specs)}")
