"""
Document Content Extractor

A comprehensive solution for extracting text, tables, and graphs from images and PDFs
using Tesseract OCR, LayoutParser, and Camelot.

Dependencies:
    pip install pytesseract layoutparser camelot-py[cv] pillow opencv-python pandas numpy
    pip install "layoutparser[efficiencydet]" torch torchvision

System Requirements:
    - Tesseract OCR installed on system
    - Poppler utils for PDF processing
    - Ghostscript for PDF handling
"""

import os
import logging
import tempfile
import warnings
from abc import ABC, abstractmethod
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any
import traceback

import cv2
import numpy as np
import pandas as pd
from PIL import Image
import pytesseract
import layoutparser as lp
import camelot

print(dir(lp))

import detectron2
from detectron2.engine import DefaultPredictor

# Suppress warnings for cleaner output
warnings.filterwarnings("ignore", category=UserWarning)

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

os.environ["TESSERACT_PATH"] = r"C:\\Program Files\\Tesseract-OCR"

pytesseract.pytesseract.tesseract_cmd = os.path.join(
    os.getenv("TESSERACT_PATH"), "tesseract.exe"
)


@dataclass
class ExtractionResult:
    """Data class to hold extraction results."""

    text: str = ""
    tables: List[pd.DataFrame] = None
    graphs_detected: int = 0
    metadata: Dict[str, Any] = None

    def __post_init__(self):
        if self.tables is None:
            self.tables = []
        if self.metadata is None:
            self.metadata = {}


class ExtractorConfig:
    """Configuration class for extraction parameters."""

    def __init__(self):
        # Tesseract configuration
        self.tesseract_config = "--oem 3 --psm 6"
        self.tesseract_lang = "eng"

        # LayoutParser configuration
        self.layout_model = "lp://PubLayNet/faster_rcnn_R_50_FPN_3x/config"
        self.confidence_threshold = 0.5

        # Camelot configuration
        self.camelot_flavor = "lattice"  # 'lattice' or 'stream'
        self.camelot_pages = "all"

        # Image preprocessing
        self.enable_preprocessing = True
        self.target_dpi = 300

        # Output configuration
        self.save_debug_images = False
        self.debug_output_dir = "debug_output"


class BaseExtractor(ABC):
    """Abstract base class for content extractors."""

    def __init__(self, config: ExtractorConfig):
        self.config = config
        self._resources = []

    @abstractmethod
    def extract(self, input_path: Union[str, Path]) -> ExtractionResult:
        """Extract content from the given input."""
        pass

    def cleanup(self):
        """Clean up allocated resources."""
        for resource in self._resources:
            try:
                if hasattr(resource, "close"):
                    resource.close()
                elif hasattr(resource, "cleanup"):
                    resource.cleanup()
            except Exception as e:
                logger.warning(f"Error cleaning up resource: {e}")
        self._resources.clear()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()


class ImagePreprocessor:
    """Handles image preprocessing for better OCR results."""

    @staticmethod
    def enhance_image(image: np.ndarray) -> np.ndarray:
        """
        Apply image enhancement techniques for better OCR.

        Args:
            image: Input image as numpy array

        Returns:
            Enhanced image as numpy array
        """
        try:
            # Convert to grayscale if needed
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image.copy()

            # Apply Gaussian blur to reduce noise
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)

            # Apply threshold to get better contrast
            _, thresh = cv2.threshold(
                blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )

            # Remove noise using morphological operations
            kernel = np.ones((1, 1), np.uint8)
            cleaned = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
            cleaned = cv2.morphologyEx(cleaned, cv2.MORPH_OPEN, kernel)

            return cleaned

        except Exception as e:
            logger.error(f"Error in image preprocessing: {e}")
            return image

    @staticmethod
    def resize_for_ocr(image: np.ndarray, target_height: int = 1200) -> np.ndarray:
        """
        Resize image to optimal size for OCR.

        Args:
            image: Input image
            target_height: Target height for resizing

        Returns:
            Resized image
        """
        try:
            height, width = image.shape[:2]
            if height < target_height:
                # Scale up small images
                scale_factor = target_height / height
                new_width = int(width * scale_factor)
                resized = cv2.resize(
                    image, (new_width, target_height), interpolation=cv2.INTER_CUBIC
                )
                return resized
            return image
        except Exception as e:
            logger.error(f"Error resizing image: {e}")
            return image


class TextExtractor(BaseExtractor):
    """Extracts text content using Tesseract OCR."""

    def __init__(self, config: ExtractorConfig):
        super().__init__(config)
        self.preprocessor = ImagePreprocessor()

        # Verify Tesseract installation
        try:
            pytesseract.get_tesseract_version()
        except Exception as e:
            raise RuntimeError(f"Tesseract not found or not properly installed: {e}")

    def extract(self, input_path: Union[str, Path]) -> ExtractionResult:
        """
        Extract text from image using OCR.

        Args:
            input_path: Path to input image file

        Returns:
            ExtractionResult containing extracted text
        """
        result = ExtractionResult()

        try:
            # Load image
            image = self._load_image(input_path)
            if image is None:
                return result

            # Preprocess image if enabled
            if self.config.enable_preprocessing:
                image = self.preprocessor.enhance_image(image)
                image = self.preprocessor.resize_for_ocr(image)

            # Extract text using Tesseract
            text = pytesseract.image_to_string(
                image,
                lang=self.config.tesseract_lang,
                config=self.config.tesseract_config,
            )

            result.text = text.strip()
            result.metadata["confidence"] = self._get_text_confidence(image)

            logger.info(f"Extracted {len(result.text)} characters of text")

        except Exception as e:
            logger.error(f"Error extracting text: {e}")
            result.metadata["error"] = str(e)

        return result

    def _load_image(self, input_path: Union[str, Path]) -> Optional[np.ndarray]:
        """Load image from file path."""
        try:
            image_path = Path(input_path)
            if not image_path.exists():
                logger.error(f"Image file not found: {input_path}")
                return None

            # Use PIL to load image, then convert to OpenCV format
            pil_image = Image.open(image_path)
            image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)

            return image

        except Exception as e:
            logger.error(f"Error loading image {input_path}: {e}")
            return None

    def _get_text_confidence(self, image: np.ndarray) -> float:
        """Get confidence score for text extraction."""
        try:
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            confidences = [int(conf) for conf in data["conf"] if int(conf) > 0]
            return sum(confidences) / len(confidences) if confidences else 0.0
        except Exception:
            return 0.0


class LayoutAnalyzer(BaseExtractor):
    """Analyzes document layout using LayoutParser."""

    def __init__(self, config: ExtractorConfig):
        super().__init__(config)
        self._model = None

        # Initialize layout model lazily
        self._initialize_model()

    def _initialize_model(self):
        """Initialize the LayoutParser model."""
        try:
            self._model = lp.Detectron2LayoutModel(
                self.config.layout_model,
                extra_config=[
                    "MODEL.ROI_HEADS.SCORE_THRESH_TEST",
                    self.config.confidence_threshold,
                ],
            )
            self._resources.append(self._model)
            logger.info("LayoutParser model initialized successfully")

        except Exception as e:
            logger.error(f"Error initializing LayoutParser model: {e}")
            raise RuntimeError(f"Failed to initialize LayoutParser: {e}")

    def extract(self, input_path: Union[str, Path]) -> ExtractionResult:
        """
        Analyze document layout and extract structured content.

        Args:
            input_path: Path to input image file

        Returns:
            ExtractionResult with layout analysis results
        """
        result = ExtractionResult()

        try:
            # Load image
            image = cv2.imread(str(input_path))
            if image is None:
                logger.error(f"Could not load image: {input_path}")
                return result

            # Convert BGR to RGB for LayoutParser
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            # Detect layout elements
            layout = self._model.detect(image_rgb)

            # Process detected elements
            text_blocks = []
            table_regions = []
            figure_count = 0

            for element in layout:
                if element.type == "Text":
                    text_blocks.append(
                        self._extract_text_from_region(image_rgb, element)
                    )
                elif element.type == "Table":
                    table_regions.append(element)
                elif element.type in ["Figure", "Image"]:
                    figure_count += 1

            # Combine text from all text blocks
            result.text = "\n\n".join(filter(None, text_blocks))
            result.graphs_detected = figure_count
            result.metadata["layout_elements"] = len(layout)
            result.metadata["text_blocks"] = len(text_blocks)
            result.metadata["table_regions"] = len(table_regions)

            logger.info(f"Layout analysis complete: {len(layout)} elements detected")

        except Exception as e:
            logger.error(f"Error in layout analysis: {e}")
            result.metadata["error"] = str(e)

        return result

    def _extract_text_from_region(self, image: np.ndarray, element) -> str:
        """Extract text from a specific region of the image."""
        try:
            # Get coordinates
            x1, y1, x2, y2 = map(int, element.coordinates)

            # Crop region
            region = image[y1:y2, x1:x2]

            # Extract text using Tesseract
            text = pytesseract.image_to_string(
                region,
                lang=self.config.tesseract_lang,
                config=self.config.tesseract_config,
            )

            return text.strip()

        except Exception as e:
            logger.error(f"Error extracting text from region: {e}")
            return ""


class TableExtractor(BaseExtractor):
    """Extracts tables using Camelot."""

    def extract(self, input_path: Union[str, Path]) -> ExtractionResult:
        """
        Extract tables from PDF or image file.

        Args:
            input_path: Path to input file

        Returns:
            ExtractionResult containing extracted tables
        """
        result = ExtractionResult()

        try:
            file_path = Path(input_path)

            if file_path.suffix.lower() == ".pdf":
                tables = self._extract_from_pdf(file_path)
            else:
                # Convert image to PDF first
                with tempfile.NamedTemporaryFile(
                    suffix=".pdf", delete=False
                ) as tmp_pdf:
                    self._convert_image_to_pdf(file_path, tmp_pdf.name)
                    tables = self._extract_from_pdf(tmp_pdf.name)
                    # Clean up temporary file
                    os.unlink(tmp_pdf.name)

            result.tables = [table.df for table in tables if not table.df.empty]
            result.metadata["tables_found"] = len(result.tables)

            logger.info(f"Extracted {len(result.tables)} tables")

        except Exception as e:
            logger.error(f"Error extracting tables: {e}")
            result.metadata["error"] = str(e)

        return result

    def _extract_from_pdf(self, pdf_path: Path):
        """Extract tables from PDF using Camelot."""
        try:
            tables = camelot.read_pdf(
                str(pdf_path),
                flavor=self.config.camelot_flavor,
                pages=self.config.camelot_pages,
            )
            return tables
        except Exception as e:
            logger.error(f"Error reading PDF with Camelot: {e}")
            return []

    def _convert_image_to_pdf(self, image_path: Path, output_path: str):
        """Convert image to PDF for table extraction."""
        try:
            image = Image.open(image_path)
            # Convert to RGB if necessary
            if image.mode != "RGB":
                image = image.convert("RGB")
            image.save(output_path, "PDF")
        except Exception as e:
            logger.error(f"Error converting image to PDF: {e}")
            raise


class DocumentContentExtractor:
    """Main class that orchestrates all extraction processes."""

    def __init__(self, config: Optional[ExtractorConfig] = None):
        self.config = config or ExtractorConfig()
        self._ensure_output_directory()

    def _ensure_output_directory(self):
        """Create output directory if it doesn't exist."""
        if self.config.save_debug_images:
            Path(self.config.debug_output_dir).mkdir(parents=True, exist_ok=True)

    @contextmanager
    def _get_extractors(self):
        """Context manager for managing extractor resources."""
        extractors = {}
        try:
            extractors["text"] = TextExtractor(self.config)
            extractors["layout"] = LayoutAnalyzer(self.config)
            extractors["table"] = TableExtractor(self.config)
            yield extractors
        finally:
            # Clean up all extractors
            for extractor in extractors.values():
                try:
                    extractor.cleanup()
                except Exception as e:
                    logger.warning(f"Error cleaning up extractor: {e}")

    def extract_all(self, input_path: Union[str, Path]) -> Dict[str, ExtractionResult]:
        """
        Extract all content types from the input file.

        Args:
            input_path: Path to input file (image or PDF)

        Returns:
            Dictionary containing results from all extractors
        """
        input_path = Path(input_path)

        # Validate input file
        if not input_path.exists():
            raise FileNotFoundError(f"Input file not found: {input_path}")

        if input_path.suffix.lower() not in [
            ".png",
            ".jpg",
            ".jpeg",
            ".tiff",
            ".bmp",
            ".pdf",
        ]:
            raise ValueError(f"Unsupported file format: {input_path.suffix}")

        results = {}

        with self._get_extractors() as extractors:
            try:
                # Extract text using OCR
                logger.info("Extracting text...")
                results["text"] = extractors["text"].extract(input_path)

                # Analyze layout (only for images)
                if input_path.suffix.lower() != ".pdf":
                    logger.info("Analyzing layout...")
                    results["layout"] = extractors["layout"].extract(input_path)

                # Extract tables
                logger.info("Extracting tables...")
                results["table"] = extractors["table"].extract(input_path)

            except Exception as e:
                logger.error(f"Error during extraction: {e}")
                logger.error(traceback.format_exc())
                raise

        return results

    def extract_text_only(self, input_path: Union[str, Path]) -> ExtractionResult:
        """Extract only text content."""
        with TextExtractor(self.config) as extractor:
            return extractor.extract(input_path)

    def extract_tables_only(self, input_path: Union[str, Path]) -> ExtractionResult:
        """Extract only tables."""
        with TableExtractor(self.config) as extractor:
            return extractor.extract(input_path)

    def save_results(
        self, results: Dict[str, ExtractionResult], output_dir: Union[str, Path]
    ):
        """
        Save extraction results to files.

        Args:
            results: Results from extraction
            output_dir: Directory to save results to
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        try:
            # Save text results
            if "text" in results and results["text"].text:
                with open(
                    output_path / "extracted_text.txt", "w", encoding="utf-8"
                ) as f:
                    f.write(results["text"].text)

            # Save layout results
            if "layout" in results and results["layout"].text:
                with open(output_path / "layout_text.txt", "w", encoding="utf-8") as f:
                    f.write(results["layout"].text)

            # Save table results
            if "table" in results and results["table"].tables:
                for i, table in enumerate(results["table"].tables):
                    table.to_csv(output_path / f"table_{i+1}.csv", index=False)

            # Save metadata
            metadata = {}
            for key, result in results.items():
                metadata[key] = result.metadata

            import json

            with open(output_path / "metadata.json", "w") as f:
                json.dump(metadata, f, indent=2, default=str)

            logger.info(f"Results saved to {output_path}")

        except Exception as e:
            logger.error(f"Error saving results: {e}")
            raise


def main():
    """Example usage of the DocumentContentExtractor."""

    # Configure extraction parameters
    config = ExtractorConfig()
    config.tesseract_config = "--oem 3 --psm 6"
    config.confidence_threshold = 0.7
    config.save_debug_images = True

    # Initialize extractor
    extractor = DocumentContentExtractor(config)

    # Example file path (replace with actual file)
    input_file = r"C:\Users\TinsPJoseph\Downloads\Skoda Kushaq Brochure Update_MC and Sportline_5 Feb25 3.pdf"  # or .pdf

    try:
        # Extract all content
        results = extractor.extract_all(input_file)

        # Print results
        print("=== EXTRACTION RESULTS ===")

        if "text" in results:
            print(f"\nText (OCR): {len(results['text'].text)} characters")
            print(f"Sample: {results['text'].text[:200]}...")

        if "layout" in results:
            print(
                f"\nLayout Analysis: {results['layout'].metadata.get('layout_elements', 0)} elements"
            )
            print(f"Graphs detected: {results['layout'].graphs_detected}")

        if "table" in results:
            print(f"\nTables: {len(results['table'].tables)} found")
            for i, table in enumerate(
                results["table"].tables[:3]
            ):  # Show first 3 tables
                print(f"Table {i+1} shape: {table.shape}")

        # Save results
        extractor.save_results(results, "output")

    except Exception as e:
        logger.error(f"Extraction failed: {e}")
        return 1

    return 0


if __name__ == "__main__":
    exit(main())
