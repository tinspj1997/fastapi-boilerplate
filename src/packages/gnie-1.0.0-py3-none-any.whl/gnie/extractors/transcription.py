import asyncio
import os
import re
import shutil
import tempfile
from datetime import timedelta
from typing import AsyncGenerator, List, Tuple
import subprocess
import imageio_ffmpeg as ffmpeg
import tiktoken
from openai import AsyncAzureOpenAI
from gnie.schema.transcription_schema import (
    MediaProcessingConfig,
    SegmentationConfig,
    TranscriptionConfig,
    ProcessingConfig # noqa: F401
)
__all__ = [
    "MediaProcessingConfig",
    "SegmentationConfig",
    "TranscriptionConfig",
    "ProcessingConfig",
] 

async def process_media_streaming(
    video_path: str,
    whisper_model: AsyncAzureOpenAI,
    config: MediaProcessingConfig = MediaProcessingConfig(),
) -> AsyncGenerator[dict, None]:
    """
    Process a large media file in a streaming fashion, yielding transcript segments.

    Args:
        video_path (str): Path to the input video/audio file.
        whisper_model (Any): Whisper model instance for transcription.
        segment_duration (int, optional): Duration of each segment in milliseconds. Defaults to 3000.
            - At ~12 kbps OGG:
                • ~10 MB ≈ 6915 seconds (115 minutes 15 seconds)
                • ~15 MB ≈ 10373 seconds (173 minutes 7 seconds)
                • ~20 MB ≈ 13830 seconds (230 minutes 10 seconds)

        temp_dir (Optional[str], optional): Temporary directory for segments. Defaults to None.
        cleanup_segments (bool, optional): Whether to delete temp segments after use. Defaults to True.
        return_tokens (bool, optional): Whether to include token count in results. Defaults to False.
        adjust_segment_timestamps (bool, optional): Adjust timestamps for streaming. Defaults to True.
        timestamp_granularities (str, optional): Allowed values: "segment", "word". Defaults to "segment".
        temperature (float, optional): Sampling temperature for model. Defaults to 0.0.
        response_format (str, optional): Allowed values: "srt", "vtt", "verbose_json". Defaults to "srt".

    Yields:
        dict: Contains 'segment', 'transcript', and optionally 'tokens'.
        Example:
            {
                'segment': 0,
                'transcript': 'Hello world.',
                'tokens': 12
            }

    Raises:
        ValueError: If adjust_segment_timestamps is True and response_format is not 'vtt' or 'srt'.
        FileNotFoundError: If video_path does not exist.
        RuntimeError: If segment extraction or transcription fails.
    """

    if not os.path.exists(video_path):
        raise FileNotFoundError(f"Video file not found: {video_path}")

    if (
        config.processing.adjust_segment_timestamps is True
        and config.transcription.response_format not in ["vtt", "srt"]
    ):
        raise ValueError(
            "Timestamp adjustments = True is only supported with response_format = 'vtt' or 'srt'."
        )
    created_temp_dir = False
    temp_dir = config.processing.temp_dir

    if temp_dir is None:
        temp_dir = tempfile.mkdtemp(prefix="media_processing_")
        created_temp_dir = True

    try:
        segment_count = 0
        async for segment_path, segment_offset in extract_audio_segments(
            video_path, temp_dir, config.segmentation
        ):
            try:
                transcript = await transcribe_segment(
                    segment_path, whisper_model, config.transcription
                )
                if (
                    transcript
                    and config.processing.adjust_segment_timestamps
                    and config.transcription.response_format in ["vtt", "srt"]
                ):
                    transcript = shift_vtt(transcript, float(segment_offset))
                result = {"segment": segment_count, "transcript": transcript}

                if config.processing.return_tokens:
                    result["tokens"] = estimate_tokens(transcript)

                if transcript:
                    yield result

                segment_count += 1

            finally:
                if config.processing.cleanup_segments and os.path.exists(segment_path):
                    os.remove(segment_path)

    finally:
        if created_temp_dir and os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


async def extract_audio_segments(
    video_path: str,
    temp_dir: str,
    config: SegmentationConfig,
) -> AsyncGenerator[Tuple[str, float], None]:
    """
    Extract audio segments with overlap and speech detection.

    Args:
        video_path (str): Path to input video/audio file.
        segment_duration (int, optional): Duration of each segment in seconds. Defaults to 300.
        temp_dir (Optional[str], optional): Temporary directory for segments. Defaults to None.
        overlap_duration (int, optional): Overlap between segments in seconds. Defaults to 30.
        bitrate (str, optional): Audio bitrate for output. Defaults to "12k".
        silence_threshold (float, optional): Silence detection threshold. Defaults to 0.0009.
        silence_duration (float, optional): Minimum silence duration to consider as gap. Defaults to 2.0.

    Yields:
        Tuple[str, float]: Path to segment file and segment offset in seconds.
        Example:
            ("/tmp/segment_001.ogg", 0.0)

    Raises:
        FileNotFoundError: If video_path does not exist.
        RuntimeError: If speech detection or segment generation fails.
    """
    if not os.path.exists(video_path):
        raise FileNotFoundError(f"Video file not found: {video_path}")

    if temp_dir is None:
        temp_dir = tempfile.mkdtemp(prefix="audio_segments_")

    # First, detect speech segments
    speech_segments = await detect_speech_segments(
        video_path, config.silence_threshold, config.silence_duration
    )

    if not speech_segments:
        return  # No speech detected

    # Generate overlapping segments from speech regions
    async for segment_path, segment_offset in generate_overlapping_segments(
        video_path, speech_segments, temp_dir, config
    ):
        yield segment_path, segment_offset


async def detect_speech_segments(
    video_path: str,
    silence_threshold: float,
    silence_duration: float,
) -> List[Tuple[float, float]]:
    """
    Detect segments with speech using FFmpeg's silencedetect filter.

    Args:
        video_path (str): Path to input video/audio file.
        silence_threshold (float): Silence detection threshold.
        silence_duration (float): Minimum silence duration to consider as gap.

    Returns:
        List[Tuple[float, float]]: List of (start, end) times for speech segments.
        Example: [(0.0, 12.5), (15.0, 30.0)]

    Raises:
        FileNotFoundError: If video_path does not exist.
        RuntimeError: If FFmpeg fails or output cannot be parsed.
    """
    ffmpeg_exe = ffmpeg.get_ffmpeg_exe()

    # Use silencedetect to find non-silent segments
    command = [
        ffmpeg_exe,
        "-i",
        video_path,
        "-af",
        f"silencedetect=noise={silence_threshold}:duration={silence_duration}",
        "-f",
        "null",
        "-",
    ]

    process = await asyncio.create_subprocess_exec(
        *command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )

    _, stderr = await process.communicate()

    if process.returncode != 0:
        raise RuntimeError(f"FFmpeg silence detection failed: {stderr.decode()}")

    # Parse silence detection output
    stderr_text = stderr.decode()
    speech_segments = []
    silence_start = None
    current_start = 0.0

    for line in stderr_text.split("\n"):
        if "silence_start:" in line:
            # Extract silence start time
            try:
                silence_start = float(line.split("silence_start: ")[1].split()[0])
            except (ValueError, IndexError):
                raise RuntimeError(f"Failed to parse silence_start from line: {line}")
            # Add speech segment before this silence
            if silence_start > current_start:
                speech_segments.append((current_start, silence_start))

        elif "silence_end:" in line and silence_start is not None:
            # Extract silence end time and update current start
            try:
                silence_end = float(line.split("silence_end: ")[1].split()[0])
            except (ValueError, IndexError):
                raise RuntimeError(f"Failed to parse silence_end from line: {line}")
            current_start = silence_end
            silence_start = None

    # Add final segment if file doesn't end with silence
    if silence_start is None:
        # Get total duration
        duration = await get_audio_duration(video_path)
        if duration > current_start:
            speech_segments.append((current_start, duration))

    return speech_segments


async def get_audio_duration(video_path: str) -> float:
    """
    Get total duration of audio/video file in seconds.

    Args:
        video_path (str): Path to input video/audio file.

    Returns:
        float: Duration in seconds. Example: 123.45

    Raises:
        FileNotFoundError: If video_path does not exist.
        RuntimeError: If FFmpeg fails or output cannot be parsed.
    """
    ffmpeg_exe = ffmpeg.get_ffmpeg_exe()
    command = [ffmpeg_exe, "-i", video_path, "-f", "null", "-"]

    process = await asyncio.create_subprocess_exec(
        *command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )

    _, stderr = await process.communicate()
    stderr_text = stderr.decode()

    # Extract duration from ffmpeg output
    for line in stderr_text.split("\n"):
        if "Duration:" in line:
            duration_str = line.split("Duration: ")[1].split(",")[0]
            h, m, s = duration_str.split(":")
            return float(h) * 3600 + float(m) * 60 + float(s)

    return 0.0


async def generate_overlapping_segments(
    video_path: str,
    speech_segments: List[Tuple[float, float]],
    temp_dir: str,
    config: SegmentationConfig,
) -> AsyncGenerator[Tuple[str, float], None]:
    """
    Generate overlapping audio segments from speech regions.

    Args:
        video_path (str): Path to input video/audio file.
        speech_segments (List[Tuple[float, float]]): List of (start, end) times for speech segments.
        segment_duration (int): Duration of each segment in seconds.
        overlap_duration (int): Overlap between segments in seconds.
        temp_dir (str): Temporary directory for segments.
        bitrate (str): Audio bitrate for output.
        min_speech_duration (float, optional): Minimum speech duration to keep. Defaults to 3.0.

    Yields:
        Tuple[str, float]: Path to segment file and segment offset in seconds.
        Example:
            ("/tmp/segment_001.ogg", 0.0)

    Raises:
        RuntimeError: If segment extraction fails.
    """
    segment_count = 0

    for speech_start, speech_end in speech_segments:
        speech_duration = speech_end - speech_start

        # Skip very short speech segments
        if (
            speech_duration < config.min_speech_duration
        ):  # Less than min_speech_duration
            continue

        # Generate segments within this speech region
        current_start = speech_start

        while current_start < speech_end:
            # Calculate segment end time
            segment_end = min(current_start + config.segment_duration, speech_end)

            # Create segment file
            segment_path = os.path.join(temp_dir, f"segment_{segment_count:03d}.ogg")

            success = await extract_single_segment(
                video_path, current_start, segment_end, segment_path, config.bitrate
            )

            if success:
                yield segment_path, current_start
                segment_count += 1

            # Move to next segment start with overlap consideration
            next_start = (
                current_start + config.segment_duration - config.overlap_duration
            )

            # If the remaining duration is less than segment_duration,
            # adjust to avoid very short final segments
            remaining_duration = speech_end - next_start
            if remaining_duration < config.segment_duration * 0.5:
                break

            current_start = next_start


async def extract_single_segment(
    video_path: str, start_time: float, end_time: float, output_path: str, bitrate: int
) -> bool:
    """
    Extract a single audio segment from a media file.

    Args:
        video_path (str): Path to input video/audio file.
        start_time (float): Start time in seconds.
        end_time (float): End time in seconds.
        output_path (str): Path to output segment file.
        bitrate (str): Audio bitrate for output.

    Returns:
        bool: True if extraction succeeded, False otherwise.

    Raises:
        RuntimeError: If FFmpeg fails to extract segment.
    """
    ffmpeg_exe = ffmpeg.get_ffmpeg_exe()
    duration = end_time - start_time

    command = [
        ffmpeg_exe,
        "-i",
        video_path,
        "-ss",
        str(start_time),
        "-t",
        str(duration),
        "-vn",
        "-map_metadata",
        "-1",
        "-ac",
        "1",
        "-c:a",
        "libopus",
        "-b:a",
        f"{bitrate}k",
        "-application",
        "voip",
        "-threads",
        "1",
        "-y",
        output_path,
    ]

    process = await asyncio.create_subprocess_exec(
        *command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )

    _, stderr = await process.communicate()

    if process.returncode != 0:
        raise RuntimeError(
            f"Failed to extract segment {start_time}-{end_time}: {stderr.decode()}"
        )

    return True


async def transcribe_segment(
    segment_path: str, whisper_model: AsyncAzureOpenAI, config: TranscriptionConfig
) -> str:
    """
    Transcribe a single audio segment using the provided Whisper model.

    Args:
        segment_path (str): Path to audio segment file.
        whisper_model (Any): Whisper model instance for transcription.
        timestamp_granularities (str, optional): Allowed values: "segment", "word". Defaults to "segment".
        temperature (float, optional): Sampling temperature for model. Defaults to 0.0.
        response_format (str, optional): Allowed values: "verbose_json", "vtt", "srt". Defaults to "verbose_json".

    Returns:
        str: Transcribed text or full response depending on response_format.
        Example: "Hello world."

    Raises:
        FileNotFoundError: If segment_path does not exist.
        RuntimeError: If transcription fails.
    """
    if not os.path.exists(segment_path):
        raise FileNotFoundError(f"Segment not found: {segment_path}")
    if os.path.getsize(segment_path) > 23 * 1024 * 1024:  # Greater than 23MB
        raise ValueError(f"Segment too Large: {segment_path}")
    try:
        with open(segment_path, "rb") as audio_file:
            response = await whisper_model.audio.transcriptions.create(
                model=config.model_name,
                file=audio_file,
                timestamp_granularities=config.timestamp_granularities,
                temperature=config.temperature,
                response_format=config.response_format,
            )
    except Exception as e:
        raise RuntimeError(f"Transcription failed for {segment_path}: {str(e)}")
    return response.text.strip() if response and hasattr(response, "text") else response


def shift_vtt(vtt_str: str, offset: float) -> str:
    """
    Shift all timestamps in a VTT/Subtitle block by 'offset' seconds.

    Args:
        vtt_str (str): VTT or subtitle string.
        offset (float): Number of seconds to shift timestamps.

    Returns:
        str: Subtitle string with shifted timestamps.
        Example: "00:00:12.200 --> 00:00:16.200" becomes "00:00:14.200 --> 00:00:18.200" if offset=2.0
    """

    def _to_seconds(h, m, s, ms) -> float:
        try:
            return int(h) * 3600 + int(m) * 60 + int(s) + (int(ms) / 1000 if ms else 0)
        except ValueError as e:
            raise ValueError(
                f"Invalid timestamp values: h={h}, m={m}, s={s}, ms={ms}"
            ) from e

    def _replace(match):
        start = _to_seconds(*match.groups()[0:4])
        end = _to_seconds(*match.groups()[4:8])
        return f"{format_ts(start + offset)} --> {format_ts(end + offset)}"

    # Regex for timestamps like 00:00:12.200 --> 00:00:16.200
    pattern = re.compile(
        r"(\d+):(\d+):(\d+)(?:\.(\d+))?\s-->\s(\d+):(\d+):(\d+)(?:\.(\d+))?"
    )
    return pattern.sub(_replace, normalize_timestamps(vtt_str))


def format_ts(total_seconds: float) -> str:
    """
    Convert float seconds into VTT timestamp: HH:MM:SS.mmm

    Args:
        total_seconds (float): Number of seconds.

    Returns:
        str: Timestamp string in format HH:MM:SS.mmm
        Example: "01:02:03.456"
    """
    if total_seconds < 0:
        total_seconds = 0  # clamp negative shifts

    td = timedelta(seconds=total_seconds)
    total_ms = int(round(td.total_seconds() * 1000))

    hours, remainder = divmod(total_ms, 3600 * 1000)
    minutes, remainder = divmod(remainder, 60 * 1000)
    seconds, milliseconds = divmod(remainder, 1000)

    return f"{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:03}"


def normalize_timestamps(text: str) -> str:
    """
    Accepts VTT or SRT, strips ms (.000 or ,000), returns clean subtitles with HH:MM:SS only.

    Args:
        text (str): Subtitle text in VTT or SRT format.

    Returns:
        str: Subtitle text with timestamps normalized to HH:MM:SS.
    """

    lines = text.strip().splitlines()
    cleaned = []

    for line in lines:
        # Skip empty or VTT header
        if line.strip().upper() == "WEBVTT" or not line.strip():
            continue

        # Remove numeric cue indexes (SRT)
        if line.strip().isdigit():
            continue

        # Fix timestamps
        ts_line = re.sub(r"(\d{2}:\d{2}:\d{2})([.,]\d{3})?", r"\1", line)

        cleaned.append(ts_line)

    return "\n".join(cleaned)


def estimate_tokens(text: str, encoding: str = "cl100k_base") -> int:
    """
    Estimate token count for given text using tiktoken encoding.

    Args:
        text (str): Input text to estimate tokens for.
        encoding (str, optional): Encoding name. Defaults to "cl100k_base".

    Returns:
        int: Estimated token count. Example: 12

    Raises:
        Exception: If tiktoken encoding fails.
    """
    try:
        enc = tiktoken.get_encoding(encoding)
        return len(enc.encode(text))
    except Exception:
        # Fallback approximation: ~4 chars per token
        return len(text) // 4


def is_valid_media(file_path_or_bytes) -> bool:
    """
    Validate if input is a playable media file (audio or video).
    Uses ffmpeg (from imageio-ffmpeg) to try decoding without output.
    """
    tmp_path = None
    try:
        if isinstance(file_path_or_bytes, (bytes, bytearray)):
            with tempfile.NamedTemporaryFile(delete=False, suffix=".bin") as tmp:
                tmp.write(file_path_or_bytes)
                tmp.flush()
                tmp_path = tmp.name
            path = tmp_path
        else:
            path = str(file_path_or_bytes)

        ffmpeg_exe = ffmpeg.get_ffmpeg_exe()

        # Try to decode first few frames without writing output
        cmd = [
            ffmpeg_exe,
            "-v", "error",      # show only errors
            "-i", path,         # input file
            "-t", "1",          # only probe a short duration
            "-f", "null", "-"   # discard output
        ]

        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        value = result.returncode == 0
        print(f"Media validation result for {path}: {value}")
        return value

    except Exception as e:
        print(f"Error occurred while validating media: {e}")
        return False
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)
