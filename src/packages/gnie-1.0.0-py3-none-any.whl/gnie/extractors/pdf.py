from langchain_community.document_loaders import PyMuPDFLoader
import fitz
import os
from typing import Literal
from typing import Union


def extract_content(
    file_path: str,
    engine: Literal["pymupdf"] = "pymupdf",
):
    if not isinstance(file_path, str):
        raise ValueError("File path must be in str format")
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File does not exist: {file_path}")

    if engine == "pymupdf":
        docs = _load_with_pymupdf(file_path)

    return docs


def _load_with_pymupdf(file_path: str):
    loader = PyMuPDFLoader(file_path)
    return loader.load()


def extract_image(file_path, image_folder):
    if image_folder is None:
        raise ValueError(
            "Image folder must be provide if you want to extract image from PDF."
        )
    doc = fitz.open(file_path)
    for page_index in range(len(doc)):
        page = doc.load_page(page_index)
        images = page.get_images(full=True)
        for image_index, img in enumerate(images):
            xref = img[0]
            pix = fitz.Pixmap(doc, xref)
            try:
                if pix.colorspace.n not in [1, 3]:  # Not grayscale or RGB
                    pix = fitz.Pixmap(fitz.csRGB, pix)
                pix.save(f"{image_folder}/page_{page_index}-image_{image_index}.png")
            except Exception:
                continue


async def extract_tables(path): ...


def is_pdf_protected(file_input: Union[str, bytes]) -> bool:
    """Check if a PDF file is password protected.

    Args:
        file_input: Either a file path (str) or PDF content as bytes

    Returns:
        bool: True if password protected, False otherwise

    Raises:
        FileNotFoundError: If file path doesn't exist (when input is str)
        RuntimeError: For other file access issues
    """
    try:
        if isinstance(file_input, str):
            if not os.path.exists(file_input):
                raise FileNotFoundError(f"File not found: {file_input}")
            doc = fitz.open(file_input)
        else:
            doc = fitz.open(stream=file_input, filetype="pdf")

        if doc.needs_pass:
            return True
        return False
    except Exception as e:
        raise RuntimeError(f"Error checking PDF protection: {str(e)}")
