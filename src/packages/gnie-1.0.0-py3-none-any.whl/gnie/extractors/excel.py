"""
file_utils.py

This module provides utilities for reading Excel files.
"""

import pandas as pd
from typing import Union


def read_excel(
    path: str, deep: bool = False, **kwargs
) -> Union[pd.ExcelFile, pd.DataFrame]:
    """
    Reads an Excel file and returns either a pandas ExcelFile object or a parsed DataFrame.

    Args:
        path (str): The full file path to the Excel file.
        deep (bool, optional):
            - If True, returns a pd.ExcelFile object for manual sheet parsing.
            - If False, returns a pd.DataFrame from the first sheet. Defaults to False.

    Returns:
        Union[pd.ExcelFile, pd.DataFrame]:
            An ExcelFile object or a DataFrame depending on the `deep` flag.

    Raises:
        FileNotFoundError: If the specified Excel file does not exist.
        ValueError: If the file format is unsupported or corrupted.

    Example:
        >>> # For manual sheet parsing
        >>> xls = read_excel("data.xlsx", deep=True)
        >>> df = xls.parse("Sheet1")

        >>> # For one-shot read
        >>> df = read_excel("data.xlsx",**kwargs)
    """
    try:
        if deep:
            return pd.ExcelFile(path, **kwargs)
        else:
            return pd.read_excel(path, **kwargs)
    except FileNotFoundError as e:
        raise FileNotFoundError(f"Excel file not found at path: {path}") from e
    except ValueError as e:
        raise ValueError(f"Failed to read Excel file: {e}") from e
