import os
import base64
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

from langchain_openai import AzureChatOpenAI
from langchain.schema import Document
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE
from PIL import Image
from io import BytesIO

from gnie.extractors.image import extract_image_data

# ================== Shape Extraction ==================


def table_to_markdown(table):
    try:
        rows = list(table.rows)
        if not rows:
            return "* table*"
        header = [cell.text.strip() for cell in rows[0].cells]
        markdown = "| " + " | ".join(header) + " |\n"
        markdown += "| " + " | ".join(["---"] * len(header)) + " |\n"
        for row in rows[1:]:
            row_data = [cell.text.strip() for cell in row.cells]
            markdown += "| " + " | ".join(row_data) + " |\n"
        return markdown
    except Exception as e:
        raise ValueError(f"Error parsing table: {e}")


def is_large_image(shape, min_width=1.0, min_height=1.0):
    return (
        shape.shape_type == MSO_SHAPE_TYPE.PICTURE
        and shape.width.inches >= min_width
        and shape.height.inches >= min_height
    )


def extract_text_from_shape(shape):
    lines = []
    if not shape.has_text_frame:
        return lines
    for para in shape.text_frame.paragraphs:
        text = "".join(run.text for run in para.runs).strip()
        if text:
            lines.append(text)
    return lines


def extract_shape_content(shape):
    md_lines = []
    image_blobs = []

    if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
        for subshape in shape.shapes:
            sub_md, sub_images = extract_shape_content(subshape)
            md_lines.extend(sub_md)
            image_blobs.extend(sub_images)

    elif shape.has_text_frame:
        md_lines.extend(extract_text_from_shape(shape))

    elif shape.has_table:
        try:
            md_lines.append(table_to_markdown(shape.table))
        except Exception:
            pass

    elif is_large_image(shape):
        if hasattr(shape, "image"):
            image_blobs.append(shape.image.blob)

    return md_lines, image_blobs


# ================== Slide Extraction ==================


def extract_slide_content(slide, client, extract_images: bool, prompt: str):
    md_lines = []
    image_blobs = []
    token_usage = {"prompt_tokens": 0, "completion_tokens": 0}

    for shape in slide.shapes:
        shape_md, shape_images = extract_shape_content(shape)
        md_lines.extend(shape_md)
        image_blobs.extend(shape_images)

    if extract_images and image_blobs:
        image_base64_list = []
        token_usage = {"prompt_tokens": 0, "completion_tokens": 0}
        for blob in image_blobs:
            try:
                with Image.open(BytesIO(blob)) as img:
                    img.verify()
                image_base64_list.append(base64.b64encode(blob).decode("utf-8"))
            except Exception:
                continue

        try:
            image_description = extract_image_data(
                client,
                base64_data=image_base64_list,
                prompt=prompt,
            )
            description = image_description.content
            token_usage = {
                "prompt_tokens": image_description.usage_metadata.get(
                    "input_tokens", 0
                ),
                "completion_tokens": image_description.usage_metadata.get(
                    "output_tokens", 0
                ),
            }
        except Exception:
            description = "Some image in the slide is corrupted or malformed and cannot be loaded."
        md_lines.append(description)

    return "\n".join(md_lines), token_usage


def extract_slide_wrapper(args):
    file_path, slide_index, client, extract_images, prompt = args
    prs = Presentation(file_path)
    slide = prs.slides[slide_index]
    content, token_usage = extract_slide_content(slide, client, extract_images, prompt)
    return (
        Document(
            page_content=f"# Slide {slide_index + 1}\n{content}",
            metadata={"slide_number": slide_index + 1},
        ),
        token_usage,
    )


# ================== Entry Point ==================


def extract_data(
    file_path: str,
    client: Optional[AzureChatOpenAI] = None,
    extract_images: bool = True,
    prompt: Optional[str] = None,
):
    """
    Extracts slide content and optionally image data using an LLM.

    Args:
        file_path (str): Path to the .pptx file.
        client (Optional[AzureChatOpenAI]): Required if `extract_images` is True.
        extract_images (bool): Enable LLM-based image description.
        prompt (Optional[str]): Prompt for image analysis. Defaults to a general one.

    Returns:
        dict: {
            "documents": List of Document objects,
            "image_tokens": {
                "prompt_tokens": int,
                "completion_tokens": int,
                "total_tokens": int
            }
        }
    """
    if extract_images:
        if not isinstance(client, AzureChatOpenAI):
            raise ValueError(
                "When extract_images=True, a valid AzureChatOpenAI client must be provided."
            )
        if not prompt:
            prompt = """
                Describe the image and extract relevant data. If there is any table in the image extract the table as it is.
                Return the description of the image in markdown format. Don't specify Image number or image name in the description. 
                Just return the extracted data of the images in markdown format. Do not add anything else.
                """

    prs = Presentation(file_path)
    total_slides = len(prs.slides)
    
    with ThreadPoolExecutor(max_workers=min(10, os.cpu_count() or 1)) as executor:
        results = list(
            executor.map(
                extract_slide_wrapper,
                [
                    (file_path, i, client, extract_images, prompt)
                    for i in range(total_slides)
                ],
            )
        )

    documents = []
    total_prompt = 0
    total_completion = 0

    for doc, token_usage in results:
        documents.append(doc)
        total_prompt += token_usage.get("prompt_tokens", 0)
        total_completion += token_usage.get("completion_tokens", 0)

    return {
        "documents": documents,
        "image_tokens": {
            "input_token": total_prompt,
            "completion_token": total_completion,
            "total_token": total_prompt + total_completion,
        },
    }
