from typing import List, Dict, Any, Literal
from functools import partial
from concurrent.futures import ThreadPoolExecutor
import re
from gliner import GLiNER
from langchain.schema import Document
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import spacy

EntityMethod = Literal["use_model", "use_lda", "use_spacy"]


def transform_entity(value: str):
    value = str(value).replace("\n", " ").lower()
    value = re.sub(r"[^a-zA-Z\s-]", "", value)
    return value.strip()


def _use_spacy(content: str, topic_k=5):
    entities = []
    nlp = spacy.load("en_core_web_sm")
    doc = nlp(content)
    entities.extend([chunk.text for chunk in doc.noun_chunks])
    entities.extend(entity.text for entity in doc.ents)
    entities = list(map(transform_entity, entities))
    return list(set(entities))


def _use_lda(content: str, topic_k=5):
    """Extract topic words using LDA."""
    if not content or not content.strip():
        return []

    words = content.split()
    chunks = [" ".join(words[i : i + 300]) for i in range(0, len(words), 300)]

    vectorizer = CountVectorizer(stop_words="english")
    try:
        X = vectorizer.fit_transform(chunks)
        if X.shape[1] == 0:
            return []
    except ValueError:
        return []
    lda = LatentDirichletAllocation(
        n_components=5, learning_method="online", random_state=42
    )
    lda.fit(X)
    terms = vectorizer.get_feature_names_out()
    return [transform_entity(terms[i]) for i in lda.components_[0].argsort()[-topic_k:]]


def _use_model(content: str, labels: List[str]) -> List[str]:
    """
    Predict entities from content using the GLiNER model and given label suggestions.
    """
    if not labels:
        raise ValueError(
            "labels/entites are empty. Please run use_model with use_lda method"
        )
    model = GLiNER.from_pretrained("urchade/gliner_medium-v2.1", use_fast=False)
    predicted_entities = model.predict_entities(content, labels, threshold=0.75)
    return [transform_entity(entity["text"]) for entity in predicted_entities]


def _fetch_doc_entity(
    doc: Document,
    methods: List[EntityMethod],
    topic_k: int = 10,
) -> List[str]:
    """
    Extracts entities from document content using spaCy, LDA, and optionally GLiNER.
    """

    entities = []

    if "use_spacy" in methods:
        entities.extend(_use_spacy(doc.page_content, topic_k))

    if "use_lda" in methods:
        entities.extend(_use_lda(doc.page_content, topic_k))

    if "use_model" in methods:
        entities.extend(_use_model(doc.page_content, entities))

    doc.metadata["entities"] = sorted(set(e for e in entities if e))
    return doc


def extract_entities_from_docs(
    docs: List[Document],
    methods: List[EntityMethod] = ["use_lda"],
    topic_k: int = 5,
) -> List[Dict[str, Any]]:
    """
    Extracts entities from a list of documents using specified entity extraction methods in parallel.

    This function takes a list of LangChain `Document` objects and extracts entities from each document using
    one or more extraction methods. It utilizes multithreading to process documents in parallel for faster performance.

    Args:
        docs (List[Document]): A list of LangChain `Document` objects from which to extract entities.
        methods (List[EntityMethod], optional): A list of entity extraction methods to use.
                                                Default is `["use_spacy"]`.
        topic_k (int, optional): Number of top topics or keywords to extract if applicable. Default is 5.

    Returns:
        List[Dict[str, Any]]: A list of dictionaries, each representing the extracted entities and associated metadata
                              for a document.

    Notes:
        - The function uses a `ThreadPoolExecutor` with up to 10 threads.
        - Each document is processed independently using `_fetch_doc_entity`,
          which must support the given `methods` and `topic_k` arguments.

    Returns an empty list if the input `docs` list is empty.
    """

    if not docs:
        return []
    results = []

    fetch_fn = partial(_fetch_doc_entity, topic_k=topic_k, methods=methods)
    with ThreadPoolExecutor(max_workers=10) as executor:
        entity = list(executor.map(fetch_fn, docs))
        results.extend(entity)

    return results
