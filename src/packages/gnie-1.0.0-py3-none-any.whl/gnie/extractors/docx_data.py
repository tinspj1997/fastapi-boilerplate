import os
import base64

from PIL import Image
from io import BytesIO
from typing import List, Optional, Tuple, Union
from concurrent.futures import Future, ThreadPoolExecutor

from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx import Document as DocxDocument

from langchain.schema import Document
from langchain_openai import AzureChatOpenAI
from langchain_core.language_models.chat_models import BaseChatModel


from gnie.extractors.image import extract_image_data

# ---- Config ----
MIN_WIDTH = 50
MIN_HEIGHT = 50
MAX_WORKERS = min(10, os.cpu_count() or 4)

# ---- Helpers ----


def table_to_markdown(table: Table) -> str:
    """Convert a docx Table object to markdown format string.

    Args:
        table: A docx Table object to convert

    Returns:
        str: Markdown formatted string representation of the table.
            Returns empty string if table conversion fails.
    """
    try:
        rows = table.rows
        if not rows:
            return ""
        headers = [cell.text.strip() for cell in rows[0].cells]
        markdown = "| " + " | ".join(headers) + " |"
        markdown += "\n" + "| " + " | ".join(["---"] * len(headers)) + " |"
        for row in rows[1:]:
            values = [cell.text.strip() for cell in row.cells]
            markdown += "\n| " + " | ".join(values) + " |"
        return markdown
    except Exception:
        return ""


def extract_image_from_paragraph(p: Paragraph) -> Union[bytes, None]:
    """Extract the first embedded image bytes from a paragraph (inline or floating).

    Args:
        p: A docx Paragraph object to extract image from

    Returns:
        bytes: Binary data of the extracted image if found
        None: If no image is found or extraction fails
    """
    try:
        for run in p.runs:
            for elem in run._element.iter():
                if elem.tag.endswith("blip"):
                    embed_rid = elem.get(qn("r:embed"))
                    if embed_rid:
                        rel = p.part.related_parts.get(embed_rid)
                        if rel:
                            return rel.blob
        return None
    except Exception:
        return None


def analyze_image(
    image_bytes: bytes, llm_client: BaseChatModel, prompt: str
) -> Union[dict, None]:
    """Analyze image content using LLM and return description + usage stats."""
    try:
        image = Image.open(BytesIO(image_bytes))
        if image.width < MIN_WIDTH or image.height < MIN_HEIGHT:
            return None

        b64_data = base64.b64encode(image_bytes).decode("utf-8")
        result = extract_image_data(llm_client, base64_data=[b64_data], prompt=prompt)
        return {
            "content": result.content,
            "prompt_tokens": result.usage_metadata.get("input_tokens", 0),
            "completion_tokens": result.usage_metadata.get("output_tokens", 0),
        }
    except Exception:
        return None


# --- Helper: Parse docx body ---
def parse_docx_body(
    doc: DocxDocument,
    llm_client: Optional[BaseChatModel],
    extract_images: bool,
    prompt: str,
    executor: ThreadPoolExecutor,
) -> Tuple[List[Union[str, Future]], int, int]:
    """Parse the body of a docx document and extract text, tables and images.

    Args:
        doc: DocxDocument object to parse
        llm_client: Optional language model client for image analysis
        extract_images: Whether to extract and analyze images
        prompt: Prompt template for image analysis
        executor: ThreadPoolExecutor for parallel image processing

    Returns:
        Tuple containing:
        - List of extracted content chunks (text strings and Futures for image analysis)
        - Total prompt tokens used
        - Total completion tokens used
    """
    ordered_chunks: List[Union[str, Future]] = []
    total_prompt_tokens = 0
    total_completion_tokens = 0

    for child in doc.element.body.iterchildren():
        try:
            if child.tag.endswith("p"):
                para = Paragraph(child, doc)
                image_bytes = extract_image_from_paragraph(para)

                if extract_images and image_bytes:
                    future = executor.submit(
                        analyze_image, image_bytes, llm_client, prompt
                    )
                    ordered_chunks.append(future)
                elif para.text and para.text.strip():
                    ordered_chunks.append(para.text.strip())

            elif child.tag.endswith("tbl"):
                table = Table(child, doc)
                markdown = table_to_markdown(table)
                if markdown:
                    ordered_chunks.append(markdown)

        except Exception:
            continue

    return ordered_chunks, total_prompt_tokens, total_completion_tokens


# --- Helper: Process futures ---
def process_futures(
    ordered_chunks: List[Union[str, Future]],
) -> Tuple[List[str], int, int]:
    """Process a list of text chunks and futures, resolving image analysis results."""
    final_output = []
    total_prompt_tokens = 0
    total_completion_tokens = 0

    for chunk in ordered_chunks:
        if isinstance(chunk, Future):
            try:
                result = chunk.result()
                if result and result.get("content"):
                    final_output.append(f"### Image\n{result['content']}")
                    total_prompt_tokens += result.get("prompt_tokens", 0)
                    total_completion_tokens += result.get("completion_tokens", 0)
            except Exception:
                continue
        else:
            final_output.append(chunk)

    return final_output, total_prompt_tokens, total_completion_tokens


# --- Main Function ---
def extract_data(
    docx_path: str,
    llm_client: Optional[BaseChatModel] = None,
    extract_images: bool = True,
    prompt: str = None,
) -> Document:
    """Extract text, tables and images from a DOCX file.

    Args:
        docx_path: Path to the DOCX file
        llm_client: Optional language model client for image analysis
        extract_images: Whether to extract and analyze images
        prompt: Custom prompt template for image analysis. If not provided, a default prompt will be used.

    Returns:
        A dictionary containing the extracted content and metadata.
        The 'documents' key contains a list of Document objects, each with 'page_content' and 'metadata'.
        The 'tokens' key contains token usage information.

    Raises:
        FileNotFoundError: If docx_path does not exist
        ValueError: If llm_client is missing when extract_images is True
        TypeError: If llm_client is not AzureChatOpenAI when extract_images is True
        RuntimeError: If extraction fails
    """
    if not os.path.exists(docx_path):
        raise FileNotFoundError(f"File not found: {docx_path}")

    if extract_images:
        if not llm_client:
            raise ValueError(
                "LLM client and prompt must be provided when extract_images is True."
            )
        if not isinstance(llm_client, AzureChatOpenAI):
            raise TypeError(
                "llm_client must be an instance of AzureChatOpenAI when extract_images is True."
            )

    try:
        doc = DocxDocument(docx_path)
        if not prompt:
            prompt = """
                Describe the image and extract relevant data. If there is any table in the image extract the table as it is.
                Return the description of the image in markdown format. Don't specify Image number or image name in the description. 
                Just return the extracted data of the images in markdown format. Do not add anything else.
                """

        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            ordered_chunks, _, _ = parse_docx_body(
                doc, llm_client, extract_images, prompt, executor
            )
            final_output, total_prompt_tokens, total_completion_tokens = (
                process_futures(ordered_chunks)
            )

        metadata = {
            "source": os.path.basename(docx_path),
            "size": os.path.getsize(docx_path),
        }

        result = {
            "documents": [
                Document(
                    page_content="\n\n".join(final_output),
                    metadata=metadata,
                )
            ],
            "image_tokens": {
                "input_token": total_prompt_tokens,
                "completion_token": total_completion_tokens,
                "total_token": total_prompt_tokens + total_completion_tokens,
            },
        }
        return result

    except Exception as e:
        raise RuntimeError(f"Failed to extract data from docx: {e}")
