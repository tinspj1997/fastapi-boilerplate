from charset_normalizer import from_bytes
from typing import List, Optional, Dict, Any
from langchain.schema import Document
from pathlib import Path


def detect_encoding(
    file_path: str, sample_size: int = 4096, fallback: str = "utf-8"
) -> str:
    """
    Detects the encoding of the file based on a sample of its bytes.
    Falls back to 'utf-8' if detection fails.
    """
    try:
        with open(file_path, "rb") as f:
            sample = f.read(sample_size)
            result = from_bytes(sample).best()
            if result and result.encoding:
                return result.encoding
            else:
                return fallback
    except FileNotFoundError:
        raise
    except Exception:
        return fallback


def extract(
    file_path: str, metadata: Optional[Dict[str, Any]] = None
) -> List[Document]:
    """
    Reads the entire log file as a single string, using detected encoding.
    """
    try:
        encoding = detect_encoding(file_path)
        # Convert to Path object
        path = Path(file_path).absolute()

        # Prepare metadata
        default_metadata = {
            "source": str(path),
            "size_bytes": path.stat().st_size,
            "last_modified": str(path.stat().st_mtime),
        }
        merged_metadata = {**default_metadata, **(metadata or {})}

        with open(file_path, "r", encoding=encoding, errors="replace") as f:
            text = f.read()

        return [Document(page_content=text, metadata=merged_metadata)]
    except FileNotFoundError:
        raise FileNotFoundError(f"[Error] File not found: {file_path}")
    except UnicodeDecodeError:
        raise UnicodeDecodeError(
            f"[Error] Cannot decode file with encoding: {encoding}"
        )
    except Exception as e:
        raise RuntimeError(f"[Error] Failed to extract content: {e}")
