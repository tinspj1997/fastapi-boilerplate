import base64
from typing import Any, Dict
import io
import math
from PIL import Image

from langchain_openai import AzureChatOpenAI
import openai


def extract_image_data(
    client: AzureChatOpenAI,
    image_path: str = None,
    base64_data: list[str] = None,
    prompt: str = "Describe the image and extract relevant data.",
) -> Dict[str, Any]:
    """
    Extracts data from the given image using GPT-4 Vision.

    Args:
        client (OpenAI): LangChain OpenAI client instance.
        image_path (str): Path to the image file.
        base64_data (list): list of base64 content multiple images.
        prompt (str): Prompt to guide the extraction.

    Returns:
        Dict[str, Any]: Extracted data as a dictionary.
    """
    try:
        
        content_list = [{"type": "text", "text": prompt}]

        if base64_data:
            for img_b64 in base64_data:
                content_list.append(
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"},
                    }
                )

        elif image_path:
            # Open the image and base64 encode it
            with open(image_path, "rb") as img_file:
                image_bytes = img_file.read()
                image_b64 = base64.b64encode(image_bytes).decode("utf-8")
            content_list.append(
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_b64}","detail": "high"},
                }
            )
        else:
            raise ValueError("Either image_path or base64 must be provided.")

        # Prepare the message for GPT-4 Vision
        messages = [{"role": "user", "content": content_list}]

        # Call the OpenAI client
        response = client.invoke(input=messages)

        # Extract and return the response content
        return response
    except (openai.APIConnectionError, openai.BadRequestError) as e:
        raise e
    except Exception as e:
        raise e

def calculate_image_tokens(image_data: str = None, image_path: str = None) -> int:
    """
    Calculate tokens for an image based on OpenAI's vision model pricing.
    
    Image tokens = (width/512) * (height/512) * 170 + 85
    - Base cost: 85 tokens
    - Additional: 170 tokens per 512x512 tile
    """
    try:
        if image_data:
            # Decode base64 image
            image_bytes = base64.b64decode(image_data)
            image = Image.open(io.BytesIO(image_bytes))
        elif image_path:
            image = Image.open(image_path)
        else:
            raise ValueError("Either image_data or image_path must be provided")
        
        width, height = image.size
        
        # Calculate number of 512x512 tiles
        width_tiles = math.ceil(width / 512)
        height_tiles = math.ceil(height / 512)
        
        # Base cost + tile cost
        image_tokens = 85 + (width_tiles * height_tiles * 170)
        
        return image_tokens
        
    except Exception as e:
        # Fallback to average estimate if image processing fails
        raise e
