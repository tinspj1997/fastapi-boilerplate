import sqlalchemy
from sqlalchemy import create_engine, text
from typing import Optional, Dict, List
from dataclasses import dataclass
from functools import singledispatchmethod
import os
import oracledb


@dataclass(slots=True)
class DatabaseConnector:
    """
    A flexible database connector supporting multiple database types.
    Currently supports: Oracle, MS SQL, PostgreSQL, MySQL
    """

    # Define fields - required fields first, then optional with defaults
    db_type: str
    username: str
    password: str
    host: str = None
    port: str = None
    database: str = None
    wallet_path: str = None
    connection_string: str = None
    lib_dir: str = None
    engine: Optional["sqlalchemy.engine.Engine"] = None

    def __post_init__(self):
        """Handle post-initialization setup after dataclass-generated __init__"""
        # Build connection string if not provided
        if not self.connection_string and self.db_type:
            if self.db_type in ["oracle", "oracle_wallet"]:
                oracledb.init_oracle_client(lib_dir=rf"{self.lib_dir}")
            self.connection_string = self._build_connection_string()
        self.engine = create_engine(self.connection_string)

    def check_connection(self) -> bool:
        """
        Check if the database connection is established.

        Returns:
            bool: True if connection is established, False otherwise.
        """
        try:
            with self.engine.connect() as conn:
                connection_query = text("SELECT 1")
                if self.db_type in ["oracle", "oracle_wallet"]:
                    connection_query = text("SELECT 1 FROM DUAL")
                conn.execute(connection_query)
            return True
        except Exception as e:
            print(e)
            return False

    def _build_connection_string(self) -> str:
        """
        Build connection string from instance attributes

        Returns:
            str: Formatted connection string
        """
        if not all([self.username, self.password, self.database]):
            raise ValueError(
                "Missing connection parameters - need username, password, host, port, and database"
            )

        if self.db_type == "postgresql":
            return f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
        elif self.db_type == "mysql":
            return f"mysql+pymysql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"
        elif self.db_type == "mssql":
            return f"mssql+pyodbc://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}?driver=ODBC+Driver+17+for+SQL+Server"
        elif self.db_type == "oracle":
            return f"oracle+cx_oracle://{self.username}:{self.password}@{self.host}:{self.port}/?service_name={self.database}"
        elif self.db_type == "oracle_wallet":
            full_path = os.path.abspath(self.wallet_path)
            os.environ["TNS_ADMIN"] = rf"{full_path}"
            return f"oracle+cx_oracle://{self.username}:{self.password}@{self.database}"
        else:
            raise ValueError(f"Unsupported database type: {self.db_type}")

    def fetch_tables(self, check_min_rows: bool = False) -> List[str]:
        """
        Get list of tables that contain data (rows > 0)

        Returns:
            List[str]: List of table names with data
        """
        if not self.engine:
            raise ConnectionError("No database connection established")

        inspector = sqlalchemy.inspect(self.engine)
        tables = inspector.get_table_names()
        if not check_min_rows:
            return tables

        tables_with_data = []
        with self.engine.connect() as conn:
            for table in tables:
                # Use text() to safely execute SQL
                result = conn.execute(
                    text(f"SELECT COUNT(*) FROM {table}"), {}
                ).scalar()
                if result > 0:
                    tables_with_data.append(table)

        return tables_with_data

    def _fetch_columns(self, inspector: sqlalchemy.Inspector, table_name: str) -> Dict:
        return [
            {"name": col["name"], "type": str(col["type"])}
            for col in inspector.get_columns(table_name)
        ]

    def _fetch_primary_keys(
        self, inspector: sqlalchemy.Inspector, table_name: str
    ) -> Dict:
        pk = inspector.get_pk_constraint(table_name)
        if pk and pk["constrained_columns"]:
            return pk["constrained_columns"]
        return []

    def _fetch_foreign_keys(
        self, inspector: sqlalchemy.Inspector, table_name: str
    ) -> Dict:
        fks = inspector.get_foreign_keys(table_name)
        if not fks:
            return []
        return [
            {
                "referred_table": fk["referred_table"],
                "referred_columns": fk["referred_columns"],
                "constrained_columns": fk["constrained_columns"],
            }
            for fk in fks
        ]

    def _fetch_unique_constraints(
        self, inspector: sqlalchemy.Inspector, table_name: str
    ) -> Dict:
        unique = inspector.get_unique_constraints(table_name)
        if not unique:
            return []
        return [{"name": u["name"], "columns": u["column_names"]} for u in unique]

    def _fetch_indexes(self, inspector: sqlalchemy.Inspector, table_name: str) -> Dict:
        indexes = inspector.get_indexes(table_name)
        if not indexes:
            return []
        return [
            {
                "name": idx["name"],
                "columns": idx["column_names"],
                "unique": idx["unique"],
            }
            for idx in indexes
        ]

    def _fetch_schema(self, table_name: str) -> Dict:
        if not self.engine:
            raise ConnectionError("No database connection established")
        # Inspect table columns
        inspector = sqlalchemy.inspect(self.engine)
        schema_data = dict()
        schema_data["columns"] = self._fetch_columns(inspector, table_name)
        schema_data["primary_keys"] = self._fetch_primary_keys(inspector, table_name)
        schema_data["foreign_keys"] = self._fetch_foreign_keys(inspector, table_name)
        schema_data["unique"] = self._fetch_unique_constraints(inspector, table_name)
        schema_data["indexes"] = self._fetch_indexes(inspector, table_name)
        return schema_data

    @singledispatchmethod
    def get_schema(self, table_name) -> Dict:
        raise NotImplementedError(f"Cannot process type {type(table_name)}")

    @get_schema.register
    def _(self, table_name: str) -> Dict:
        schema_data = self._fetch_schema(table_name)
        return schema_data

    @get_schema.register
    def _(self, table_name: list) -> Dict:
        schema_data = dict()
        schema_data["tables"] = [self._fetch_schema(table) for table in table_name]
        return schema_data
