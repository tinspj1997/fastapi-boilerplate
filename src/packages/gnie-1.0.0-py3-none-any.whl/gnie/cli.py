import argparse
from importlib.metadata import version


def main():
    """Entry point for the GNIE Core AI Toolkit command line interface.

    Handles command line arguments and executes corresponding actions.
    Currently supports:
    - --version: Displays version information including build number

    Example usage:
        python -m gnie --version
    """
    parser = argparse.ArgumentParser(description="GNIE Core AI Toolkit")
    parser.add_argument(
        "--version", action="store_true", help="Show version information"
    )
    args = parser.parse_args()

    if args.version:
        version_details = (
            f"""Gnie core version {version('gnie')}\nBuild Number 18112025"""
        )
        print(version_details)


if __name__ == "__main__":
    main()
